<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;
use Elementor\Core\Schemes\Typography;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Icons;

class ENNOVAImageHotspot extends \Elementor\Widget_Base {

	private $ennova_hotspot_content = 'ennova-hotspot-content';
	private $ennova_hotspot_item = 'ennova-hotspot-item';
	private $ennova_hotspot_tooltip = 'ennova-hotspot-tooltip';


	public function get_name() {
		return 'ennova-image-hotspot';
	}

	public function get_title() {
		return __( 'Image Hotspot', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-hotspot';
	}

	public function get_style_depends() {
		return [
			'ennova-styles-css',
		];
	}

	public function get_script_depends() {
		return [
			'',
		];
	}

	public function get_keywords() {
		return ['image hotspot',
				'product tag price', 
				'tags', 
				'toplips ',
				'hotspot',
				'ennova addons',
				'enn',
		];
	}
	protected function register_controls() { 
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'tabs_hotspot_item' );

		$repeater->start_controls_tab(
			'hotspot_item_content_tab',
			[
				'label' => esc_html__( 'Content', 'ennova-addons' ),
			]
		);
		$slug = 'hotspot_item';

		$repeater->add_control(
			'hotspot_item_icon', 
			[
				'label' => __('Choose Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fas fa-plus', 'library' => 'brands',
				], 
			]
		);

		$repeater->add_control(
			'hotspot_item_custom_color',
			[
				'label' => esc_html__( 'Custom Color', 'ennova-addons' ),
				'type' => Controls_Manager::SWITCHER,
			]
		);

		$repeater->add_control(
			'hotspot_item_custom_text_color',
			[
				'label' => esc_html__( 'Text Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .'.$this->ennova_hotspot_content.' a' => 'color: {{VALUE}}',
				],
				'condition' => [
					'hotspot_item_custom_color' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'hotspot_item_custom_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0036FF',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .'.$this->ennova_hotspot_content.' a' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .'.$this->ennova_hotspot_content.'::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'hotspot_item_custom_color' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'hotspot_item_tooltip',
			[
				'label' => esc_html__( 'Tooltip', 'ennova-addons' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'tooltip_text',
			[
				'label' => '',
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'Tooltip Content',
				'condition' => [
					$slug.'_tooltip' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'hotspot_item_link', 
			[
				'label' => __(' Link', 'ennova-addons') , 
				'type' => Controls_Manager::URL, 
				'placeholder' => __('Enter URL', 'ennova-addons') , 
				'show_external' => true, 
				'default' => [
					'url' => '#', 'is_external' => true, 'nofollow' => true, 
				], 
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'hotspot_item_position_tab',
			[
				'label' => esc_html__( 'Position', 'ennova-addons' ),
			]
		);

		$repeater->add_control(
			'hotspot_item_horizontal',
			[
				'type' => Controls_Manager::SLIDER,
				'label' => esc_html__( 'Horizontal Position (%)', 'ennova-addons' ),
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					]
				],
				'default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.'.$this->ennova_hotspot_item => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$repeater->add_control(
			'hotspot_item_vertical',
			[
				'type' => Controls_Manager::SLIDER,
				'label' => esc_html__( 'Vertical Position (%)', 'ennova-addons' ),
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					]
				],
				'default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.'.$this->ennova_hotspot_item => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'hotspot_items',
			[
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'tooltip_text' => 'Tooltip Content',
						'hotspot_item_horizontal' => [
							'unit' => '%',
							'size' => 20,
						],
						'hotspot_item_vertical' => [
							'unit' => '%',
							'size' => 40,
						],
					],
					[
						'tooltip_text' => 'Tooltip Content',
						'hotspot_item_horizontal' => [
							'unit' => '%',
							'size' => 60,
						],
						'hotspot_item_vertical' => [
							'unit' => '%',
							'size' => 20,
						],
					],
					
				],
				'title_field' => '{{{ tooltip_text }}}',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_tooltips',
			[
				'label' => esc_html__( 'Tooltips Settings', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'show_tooltip',
			[
				'label'       => esc_html__( 'Show Tooltips', 'ennova-addons' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'by_default',
				'options'     => [
					'by_default' => esc_html__( 'Default', 'ennova-addons' ),
					'by_click'   => esc_html__( 'Click', 'ennova-addons' ),
					'by_hover'   => esc_html__( 'Hover', 'ennova-addons' ),
				],
			]
		);
		
		$this->add_responsive_control(
            'tooltip_align',
            [
                'label' => esc_html__( 'Alignment', 'ennova-addons' ),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => false,
                'default' => 'center',
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'ennova-addons' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'ennova-addons' ),
                        'icon' => 'eicon-h-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'ennova-addons' ),
                        'icon' => 'eicon-h-align-right',
                    ]
                ],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'text-align: {{VALUE}}',
				],
            ]
        );

		$this->add_responsive_control(
			'tooltip_width',
			[
				'label' => esc_html__( 'Width', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'tooltip_triangle',
			[
				'label' => esc_html__( 'Triangle', 'ennova-addons' ),
				'type' => Controls_Manager::SWITCHER,				
				'default' => 'yes',
			]
		);

		$this->add_control(
			'tooltip_triangle_size',
			[
				'type' => Controls_Manager::SLIDER,
				'label' => esc_html__( 'Size', 'ennova-addons' ),
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip.'::before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					
				],
				'condition' => [
					'tooltip_triangle' => 'yes',
				],
			]
		);

		$this->add_control(
			'tooltip_spacing',
			[
				'type' => Controls_Manager::SLIDER,
				'label' => esc_html__( 'Spacing', 'ennova-addons' ),
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// styles

		$this->start_controls_section(
			'section_style_hotspots',
			[
				'label' => esc_html__( 'Hotspots', 'ennova-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a' => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->ennova_hotspot_content.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a ' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_width',
			[
				'label' => esc_html__( 'Box Size', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_content.' a' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .'.$this->ennova_hotspot_content.' a',
			]
		);

		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'ennova-addons' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}}  .'.$this->ennova_hotspot_content.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}}  .'.$this->ennova_hotspot_content.'::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'icon_box_shadow',
				'selector' => '{{WRAPPER}} .'.$this->ennova_hotspot_content.' a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_tooltips',
			[
				'label' => esc_html__( 'Tooltips', 'ennova-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'tooltip_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip.' p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tooltip_bg_color',
			[
				'type' => Controls_Manager::COLOR,
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'tooltip_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->ennova_hotspot_tooltip,
			]
		);
		
		create_border_radius_control(
			$this,
			[
				'key'       => 'tooltip_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'tooltip_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->ennova_hotspot_tooltip => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'tooltip_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->ennova_hotspot_tooltip,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$hotspot_items = $settings['hotspot_items'];

		$show_tooltip = $settings['show_tooltip'];
		$image_url = $settings['card_image']['url'];

		?>

		<div class="enn-image-hotspots" tigger="<?php echo esc_attr($show_tooltip); ?>">
			<div class="enn-hotspot-image">
				<img src="<?php echo esc_url($image_url) ?>" class="img-cover" >
			</div>
			<div class="enn-hotspot-item-container">
				<?php
				if (isset($hotspot_items) && !empty($hotspot_items))
				{
					foreach ($hotspot_items as $key => $item)
					{
					$target = $item['hotspot_item_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $item['hotspot_item_link']['nofollow'] ? ' rel="nofollow"' : ''; 
					?>
				<div class="enn-hotspot-item elementor-repeater-item-<?php echo( $item['_id'] ) ?> <?php echo esc_attr($this->ennova_hotspot_item) ?>">
					<div class="enn-hotspot-content <?php echo esc_attr($this->ennova_hotspot_content) ?>">
						<a href="<?php echo esc_url($item['hotspot_item_link']['url']) ?>"<?php echo $target; ?><?php echo $nofollow; ?>>
							<?php \Elementor\Icons_Manager::render_icon($item['hotspot_item_icon'], ['aria-hidden' => 'true']); ?>
						</a>
					</div>
					<?php if ( 'yes' === $item['hotspot_item_tooltip'] && '' !== $item['tooltip_text'] ) : ?>
						<div class="enn-hotspot-tooltip <?php echo esc_attr($this->ennova_hotspot_tooltip) ?>">
							<p><?php echo esc_attr($item['tooltip_text']); ?></p>
						</div>						
					<?php endif; ?>	
				</div>
				<?php
					}
				}
				?>
			</div>
		</div>
	<?php
	}
}
