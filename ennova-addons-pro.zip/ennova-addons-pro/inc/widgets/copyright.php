<?php namespace EnnovaAddons;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

    class ENNOVACopyright extends Widget_Base {

        protected $copyright_index = 1;

        public function __construct( $data = array(), $args = null ) {
            parent::__construct( $data, $args );
        }
    
        public function get_name() {
            return 'ennova-copyright';
        }
    
        public function get_title() {
            return __( 'Copyright', 'ennova-addons' );
        }
    
        public function get_icon() {
            return 'enn-icon eicon-alert';
        }
    
        public function get_categories() {
            return array( 'wc-hf-element' );
        }

        public function get_keywords() {
            return ['copyright',
                    'header footer', 
                    'ennova eddons',
                    'enn',
            ];
        }
        
        protected function register_controls() {
    
            $this->start_controls_section(
                'section_title',
                array(
                    'label' => __( 'Copyright', 'ennova-addons' ),
                )
            );
    
            $this->add_control(
                'copyright',
                array(
                    'label'   => __( 'Copyright Text', 'ennova-addons' ),
                    'type'    => Controls_Manager::TEXTAREA,
                    'dynamic' => array(
                        'active' => true,
                    ),
                    'default' => __( 'Copyright © [ennova_year] [ennova_site_tile] | All Rights Reserved. Designed by [ennova_site_tile].', 'ennova-addons' ),
                )
            );
    
            $this->add_responsive_control(
                'align',
                array(
                    'label'     => __( 'Alignment', 'ennova-addons' ),
                    'type'      => Controls_Manager::CHOOSE,
                    'options'   => array(
                        'left'   => array(
                            'title' => __( 'Left', 'ennova-addons' ),
                            'icon'  => 'eicon-text-align-left',
                        ),
                        'center' => array(
                            'title' => __( 'Center', 'ennova-addons' ),
                            'icon'  => 'eicon-text-align-center',
                        ),
                        'right'  => array(
                            'title' => __( 'Right', 'ennova-addons' ),
                            'icon'  => 'eicon-text-align-right',
                        ),
                    ),
                    'selectors' => array(
                        '{{WRAPPER}} .enn-copyright-wrapper' => 'text-align: {{VALUE}};',
                    ),
                )
            );

            $this->end_controls_section();

            $this->start_controls_section(
                'section_style_copyright',
                array(
                    'label' => __( 'Copyright Text', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
    
            $this->add_control(
                'text_color',
                array(
                    'label'     => __( 'Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        // Stronger selector to avoid section style from overwriting.
                        '{{WRAPPER}} .enn-copyright-wrapper' => 'color: {{VALUE}};',
                    ),
                )
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'     => 'caption_typography',
                    'selector' => '{{WRAPPER}} .enn-copyright-wrapper',
                )
            );
    
            $this->end_controls_section();

            $this->start_controls_section(
                'section_style_site_title',
                array(
                    'label' => __( 'Site Title', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
    
            $this->add_control(
                'site_title_color',
                array(
                    'label'     => __( 'Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        // Stronger selector to avoid section style from overwriting.
                        '{{WRAPPER}} .enn-copyright-wrapper a' => 'color: {{VALUE}};',
                    ),
                )
            );
            $this->add_control(
                'site_title_hover_color',
                array(
                    'label'     => __( 'Hover Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        // Stronger selector to avoid section style from overwriting.
                        '{{WRAPPER}} .enn-copyright-wrapper a:hover' => 'color: {{VALUE}};',
                    ),
                )
            );
    
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'site_title_typography',
                    'label'     => __( 'Typography', 'ennova-addons' ), 
                    'selector' => '{{WRAPPER}} .enn-copyright-wrapper a',
                )
            );
    
            $this->end_controls_section();

        }
    
        protected function render() {

        $settings             = $this->get_settings_for_display();
		$copy_right= do_shortcode( shortcode_unautop( $settings['copyright'] ) );
		?>
		<div class="enn-copyright-wrapper">
			<div class="enn-main-wrapper">
				<span>
					<?php
						echo wp_kses(
							$copy_right,
							array(
								'a' => array(
									'class' => array(),
									'href'  => array(),
									'id'    => array(),
								),
							)
						);
					?>
				</span>
			</div>
		</div>
		<?php

        }
    
        
    }