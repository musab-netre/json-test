<?php
namespace EnnovaAddons;

	use Elementor\Controls_Manager;
	use Elementor\Core\Schemes\Color;
	use Elementor\Core\Schemes\Typography;
	use Elementor\Group_Control_Typography;
	use Elementor\Group_Control_Image_Size;
	use Elementor\Widget_Base;
	use Elementor\Repeater;
	use Elementor\Utils;
	use Elementor\Group_Control_Border;

	/**
	 * Slider Widget.
	 */
class ENNOVASlider extends Widget_Base {

	/** Widget Name */
	public function get_name() {
		return 'ennova-slider-widget';
	}

	/** Widget Title */
	public function get_title() {
		return __( 'Slider', 'ennova-addons' );
	}

	/** Icon */
	public function get_icon() {
		return 'enn-icon eicon-slider-full-screen';
	}

	/** Category */
	public function get_categories() {
		return [ 'wc-element' ];
	}

	/** Dependencies */
	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}


	protected function render() {


		$settings   = $this->get_settings_for_display();
		$element_id = 'ennova_slider_' . $this->get_id();

		$slide_to_show               = isset( $settings['slide_to_show'] ) && $settings['slide_to_show'] ? $settings['slide_to_show'] : 1;
		$slide_to_show_tablet        = isset( $settings['slide_to_show_tablet'] ) && $settings['slide_to_show_tablet'] ? $settings['slide_to_show_tablet'] : 1;
		$slide_to_show_mobile        = isset( $settings['slide_to_show_mobile'] ) && $settings['slide_to_show_mobile'] ? $settings['slide_to_show_mobile'] : 1;
		$slides_to_scroll            = isset( $settings['slides_to_scroll'] ) && $settings['slides_to_scroll'] ? $settings['slides_to_scroll'] : 1;
		$slides_to_scroll_mobile     = isset( $settings['slides_to_scroll_mobile'] ) && $settings['slides_to_scroll_mobile'] ? $settings['slides_to_scroll_mobile'] : 1;
		$slides_to_scroll_tablet     = isset( $settings['slides_to_scroll_tablet'] ) && $settings['slides_to_scroll_tablet'] ? $settings['slides_to_scroll_tablet'] : 1;
		$slides_space_between        = isset( $settings['slides_space_between'] ) && $settings['slides_space_between'] ? $settings['slides_space_between'] : 10;
		$slides_space_between_mobile = isset( $settings['slides_space_between_mobile'] ) && $settings['slides_space_between_mobile'] ? $settings['slides_space_between_mobile'] : 2;
		$slides_space_between_tablet = isset( $settings['slides_space_between_tablet'] ) && $settings['slides_space_between_tablet'] ? $settings['slides_space_between_tablet'] : 5;
		$dot_clickable               = isset( $settings['dot_clickable'] ) ? $settings['dot_clickable'] : true;

		$enable_overlay = isset( $settings['enable_overlay'] ) ? $settings['enable_overlay'] : true;

		$slide_height = isset( $settings['slide_height'] ) ? $settings['slide_height'] : 'auto';

		$autoplay       = false;
		$autoplay_speed = 2000;

		if ( array_key_exists( 'autoplay', $settings ) && $settings['autoplay'] === 'yes' ) {
			$autoplay = true;
			if ( array_key_exists( 'autoplay_speed', $settings ) ) {
				$autoplay_speed = $settings['autoplay_speed'];
			}
		}

		$transition_between_slides = 1000;
		$loop                      = false;
		$mousewheel                = false;
		$keyboard_control          = false;

		if ( isset( $settings['transition_between_slides'] ) && ! empty( $settings['transition_between_slides'] ) ) {
			$transition_between_slides = $settings['transition_between_slides'];
		}

		if ( isset( $settings['loop'] ) && ! empty( $settings['loop'] ) && $settings['loop'] === 'yes' ) {
			$loop = true;
		}
		if ( isset( $settings['mousewheel'] ) && ! empty( $settings['mousewheel'] ) && $settings['mousewheel'] === 'yes' ) {
			$mousewheel = true;
		}
		if ( isset( $settings['keyboard_control'] ) && ! empty( $settings['keyboard_control'] ) && $settings['keyboard_control'] === 'yes' ) {
			$keyboard_control = true;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'ennova-outer-wrapper' );
		$this->add_render_attribute( 'wrapper', 'data-wid', $this->get_id() );
		$swiper_div_tabs = false;
		require ENNOVA_PATH . 'inc/templates/style-1/widget-slider-template.php';
	}

	// phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
	protected function register_controls() {
		// slide
		$this->start_controls_section(
			'content',
			[
				'label' => __( 'Slider', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'ennova-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Slide Sub 1', 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'ennova-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Slide 1', 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'content',
			[
				'label'       => __( 'Description', 'ennova-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Default description', 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
			]
		);

		$repeater->add_control(
			'btn_text',
			[
				'label'       => __( 'Button Text', 'ennova-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'VIEW MORE', 'ennova-addons' ),
				'placeholder' => __( 'Set Button Label text.', 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_link',
			[
				'label'         => __( 'Link', 'ennova-addons' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);

		$this->add_control(
			'slides',
			[
				'label'       => __( 'Slides', 'ennova-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'   => __( 'Slide #1', 'ennova-addons' ),
						'content' => __( 'Slide Content.', 'ennova-addons' ),
					],
					[
						'title'   => __( 'Slide #2', 'ennova-addons' ),
						'content' => __( 'Slide Content.', 'ennova-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
		// slide ends

		$this->start_controls_section(
			'slider_configuration',
			[
				'label' => __( 'Slider Settings', 'ennova-addons' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slide_height',
			[
				'label'   => __( 'Slide Height ', 'ennova-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => [
					'auto'   => __( 'Auto', 'ennova-addons' ),
					'full'   => __( 'Full', 'ennova-addons' ),
					'custom' => __( 'Custom', 'ennova-addons' ),
				],
			]
		);

		$this->add_responsive_control(
			'custom_slide_height',
			[
				'label'           => __( 'Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'condition'       => [
					'slide_height' => 'custom',
				],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 550,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 450,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 420,
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .ennova-slide.custom' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slide_to_show',
				'label'       => 'Slides to Show',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_to_scroll',
				'label'       => 'Slides to Scroll',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_space_between',
				'label'       => 'Slides Space Between',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 10,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_navigation_arrow',
				'label'     => 'Show Navigation Arrow',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'dot_clickable',
				'label'     => 'Dot Clickable',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'autoplay',
				'label'     => 'AutoPlay',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'autoplay_speed',
				'label'       => 'AutoPlay Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3000,
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		create_number(
			$this,
			[
				'key'         => 'transition_between_slides',
				'label'       => 'Slide Switch Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1000,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'loop',
				'label'     => 'Loop',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'mousewheel',
				'label'     => 'Mouse on Wheel',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'keyboard_control',
				'label'     => 'Keyboard Control',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'display_dots',
				'label'     => 'Show Dots',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'show_scroll_bar',
				'label'     => 'Show Scroll Bar',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slide_style',
			[
				'label' => __( 'Slider Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_styles_heading',
			[
				'label' => __( 'Slider Image', 'ennova-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'slider_image',
				'exclude' => [ 'custom' ],
				'include' => [],
				'default' => 'large',
			]
		);

		$this->add_control(
			'slide_img_position',
			[
				'label'     => __( 'Image Position', 'ennova-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'center center',
				'options'   => [
					'top left'      => __( 'Top Left', 'ennova-addons' ),
					'top center'    => __( 'Top Center', 'ennova-addons' ),
					'top right'     => __( 'Top Right', 'ennova-addons' ),
					'center left'   => __( 'Center Left', 'ennova-addons' ),
					'center center' => __( 'Center Center', 'ennova-addons' ),
					'center right'  => __( 'Center Right', 'ennova-addons' ),
					'bottom left'   => __( 'Bottom Left', 'ennova-addons' ),
					'bottom center' => __( 'Bottom Center', 'ennova-addons' ),
					'bottom right'  => __( 'Bottom Right', 'ennova-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-container .ennova-slide' => 'background-position: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'slide_img_size',
			[
				'label'     => __( 'Image Size', 'ennova-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cover',
				'options'   => [
					'auto'       => __( 'Auto', 'ennova-addons' ),
					'cover'      => __( 'Cover', 'ennova-addons' ),
					'contain'    => __( 'Contain', 'ennova-addons' ),
					'initial'    => __( 'Initial', 'ennova-addons' ),
					'inherit'    => __( 'Inherit', 'ennova-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-container .ennova-slide' => 'background-size: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'slide_img_repeat',
			[
				'label'     => __( 'Image Background Repeat', 'ennova-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'no-repeat',
				'options'   => [
					'repeat'    => __( 'repeat', 'ennova-addons' ),
					'repeat-x'  => __( 'Repeat X', 'ennova-addons' ),
					'repeat-y'  => __( 'Repeat Y', 'ennova-addons' ),
					'no-repeat' => __( 'No Repeat', 'ennova-addons' ),
					'space'     => __( 'Space', 'ennova-addons' ),
					'round'     => __( 'Round', 'ennova-addons' ),
					'initial'   => __( 'Initial', 'ennova-addons' ),
					'inherit'   => __( 'Inherit', 'ennova-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-container .ennova-slide' => 'background-repeat: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'overlay_styles_heading',
			[
				'label'     => __( 'Overlay', 'ennova-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'enable_overlay',
			[
				'label'        => __( 'Enable Overlay', 'ennova-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'ennova-addons' ),
				'label_off'    => __( 'No', 'ennova-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'label'     => __( 'Overlay Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'enable_overlay' => 'yes',
				],
				'separator' => 'after',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'caption_content_styles',
			[
				'label' => __( 'Caption Content', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'caption_width',
			[
				'label'           => __( 'Caption Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 490,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 490,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 450,
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'caption_text_align',
			[
				'label'     => __( 'Caption Text Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'caption_position',
			[
				'label'        => __( 'Caption Position', 'ennova-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'None', 'ennova-addons' ),
				'label_on'     => __( 'Custom', 'ennova-addons' ),
				'return_value' => 'yes',
			]
		);
		$this->start_popover();
		$this->add_responsive_control(
			'caption_offset_y',
			[
				'label'      => __( 'Vertical', 'ennova-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => -10,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'position: absolute; top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'caption_position' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'caption_offset_x',
			[
				'label'      => __( 'Horizontal', 'ennova-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => -10,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'position: absolute; left: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'caption_position' => 'yes',
				],
			]
		);

		$this->end_popover();

		$this->start_controls_tabs( 'caption_styles_tabs' );
		$this->start_controls_tab(
			'caption_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'background-color: {{VALUE}};',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'caption_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide .ennova-slide-content',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_item_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_item_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_item_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide .ennova-slide-content',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'caption_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'caption_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		); 
		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_item_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_item_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_item_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide .ennova-slide-content:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'subtitle_styles',
			[
				'label' => __( 'Subtitle', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'caption_subtitle_styles_tabs' );
		$this->start_controls_tab(
			'caption_subtitle_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_subtitle_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'caption_subtitle_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_subtitle_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		); 

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_subtitle_item_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_subtitle_item_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_subtitle_item_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-subtitle',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'caption_subtitle_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography_hover',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_subtitle_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'caption_subtitle_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_subtitle_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
 
		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_subtitle_item_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_subtitle_item_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_subtitle_item_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-subtitle',
			]
		);
		
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'title_styles',
			[
				'label' => __( 'Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'caption_title_styles_tabs' );
		$this->start_controls_tab(
			'caption_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_title_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'caption_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_title_item_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_title_item_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_title_item_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-title span',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'caption_title_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography_hover',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span',
			]
		);

		$this->add_control(
			'title_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_title_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span' => 'background-color: {{VALUE}};',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'caption_title_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_title_item_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_title_item_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_title_item_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-title span',
			]
		); 

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// here ends

		$this->start_controls_section(
			'description_styles',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// here starts
		$this->start_controls_tabs( 'caption_content_styles_tabs' );
		$this->start_controls_tab(
			'caption_content_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_content_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span' => 'background-color: {{VALUE}};',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'caption_content_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_content_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_content_item_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_content_item_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_content_item_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-description span',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'caption_content_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography_hover',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span',
			]
		);

		$this->add_control(
			'content_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span' => 'color: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'caption_content_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span' => 'background-color: {{VALUE}};',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'caption_content_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'caption_content_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_content_item_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'caption_content_item_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		create_box_shadow_control(
			$this,
			[
				'key'      => 'caption_content_item_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content:hover .ennova-slide-description span',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// here ends

		$this->start_controls_section(
			'readmore_style',
			[
				'label' => __( 'Button', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'readmore_style_tabs'
		);

		$this->start_controls_tab(
			'readmore_normal_tab',
			[
				'label' => __( 'Normal', 'ennova-pro' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'readmore_typography',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn',
			]
		);

		$this->add_control(
			'readmore_bgcolor',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'readmore_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'readmore_border',
				'label'    => __( 'Border', 'ennova-addons' ),
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn',
			]
		);

		$this->add_control(
			'readmore_border_radius',
			[
				'label'      => __( 'Border Radius', 'ennova-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'readmore_padding',
			[
				'label'      => __( 'Padding', 'ennova-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'readmore_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_box_shadow_control(
			$this,
			[
				'key'      => 'readmore_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'readmore_hover_tab',
			[
				'label' => __( 'Hover/Active', 'ennova-pro' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'readmore_typography_hover',
				'label'    => __( 'Typography', 'ennova-addons' ),
				'scheme'   => Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover',
			]
		);

		$this->add_control(
			'readmore_bgcolor_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'readmore_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'readmore_border_hover',
				'label'    => __( 'Border', 'ennova-addons' ),
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover',
			]
		);

		$this->add_control(
			'readmore_border_radius_hover',
			[
				'label'      => __( 'Border Radius', 'ennova-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'readmore_padding_hover',
			[
				'label'      => __( 'Padding', 'ennova-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'readmore_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'readmore_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .ennova-slide-content .ennova-slide-btn:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		//  Navigation styles
		create_navigation_style( $this, [] );
		//  Navigation styles ends
	}
}



