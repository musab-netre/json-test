<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;

class ENNOVAFilterGalley extends \Elementor\Widget_Base {

	private $gallery_card_class = 'ennova-gallery-card'; 
	private $gallery_card_inner_class = 'ennova-gallery-inner-card';
	private $gallery_card_content_class = 'ennova-gallery-content-card';
	private $gallery_card_image_class = 'ennova-gallery-card-image';
	private $gallery_card_heading_class = 'ennova-gallery-card-heading';
	private $gallery_card_icon_class = 'ennova-gallery-card-icon';
	private $gallery_card_description_class = 'ennova-gallery-card-subtitle';

	public function get_name() {
		return 'ennova-filter-gallery';
	}

	public function get_title() {
		return __( 'Filter Gallery', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-gallery-masonry';
	}

	public function get_style_depends() {
		return [
			'filter-gallery',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-filter-gallery',
		];
	}

	public function get_keywords() {
		return [
			'filter gallery',
			'gallery', 
			'filter', 
			'filterable gallery',
			'dynamic gallery',
			'ennova addons',
			'enn',
		];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'filter_gallery_settings',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_design',
			[
				'label'       => esc_html__( 'gallery Layout Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Style from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'card',
				'options'     => [
					'card'      => esc_html__( 'Card ', 'ennova-addons' ),
					'overlay' => esc_html__( 'Overlay', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'template_card_style',
			[
				'label'       => esc_html__( 'Filter Gallery Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
				],
				'condition' => [
                    'template_design' => ['card'],
                ],
			]
		);

		$this->add_control(
			'template_overlay_style',
			[
				'label'       => esc_html__( 'Filter Gallery Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_6',
				'options'     => [
					'layout_6'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_9'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_10'     => esc_html__( 'Layout 5', 'ennova-addons' ),
				],
				'condition' => [
                    'template_design' => ['overlay'],
                ],
			]
		);

		$this->add_control(
			'btn1_icon',
			[
				'label' => __( 'Lightbox Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-link',
					'library' => 'solid',
				],

			]
		);
		
		$this->add_control(
			'btn2_icon',
			[
				'label' => __( 'Link Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-eye',
					'library' => 'solid',
				],

			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_buttons',
			[
				'label' => __( 'Show Buttons', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'filter_gallery_grid_column_count',
				'label'       => 'Grid Column Count',
				'placeholder' => '3',
				'min'         => 1,
				'default'     => '3',
				'selectors'   => [
					'{{WRAPPER}} .ennova-fg-projects ' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				],
			]
		); 

		$this->add_responsive_control(
			'filter_gallery_grid_column_gap',
			[
				'label'           => __( 'Grid Column Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} .ennova-fg-projects' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			'filter_gallery_grid_row_gap',
			[
				'label'           => __( 'Grid Row Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} .ennova-fg-projects' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'filter_gallery_menu_section',
			[
				'label' => __( 'Filterable Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_filter_menu',
			[
				'label' => __( 'Show Filter', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'menu_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);


		$this->add_control(
			'menus',
			[
				'label' => __( 'Menu List', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'menu_title' => __( 'All', 'ennova-addons' ),
					],
					[
						'menu_title' => __( 'Gallery Name', 'ennova-addons' ),
					],
					[
						'menu_title' => __( 'Gallery Name', 'ennova-addons' ),
					],
				],
				'title_field' => '{{{ menu_title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filter_gallery_content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		); 

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'content_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		); 

		$repeater->add_control(
			'filter_name', [
				'label' => __( 'Gallery Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'All' , 'ennova-addons' ),
				'placeholder' => 'Enter menu name',
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'filter_title', [
				'label' => __( 'Gallery Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title' , 'ennova-addons' ),
				'placeholder' => 'Enter title',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'filter_description', [
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => __( 'Aenean ut turpis blandit eros convallis ', 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
			]
		);

		$repeater->add_control(
			'filter_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 

		$this->add_control(
			'filter_gallery_content_list',
			[
				'label' => __( 'Content List', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'content_image' => get_placeholder_image_src(),
						'filter_name' => 'All',
						'filter_title' => 'Gallery Item Name',
						'filter_description' => 'Aenean ut turpis blandit eros convallis',
						'filter_link' => '', 
					],
					[
						'content_image' => get_placeholder_image_src(),
						'filter_name' => 'All',
						'filter_title' => 'Gallery Item Name',
						'filter_description' => 'Aenean ut turpis blandit eros convallis',
						'filter_link' => '', 
					],
					[
						'content_image' => get_placeholder_image_src(),
						'filter_name' => 'All',
						'filter_title' => 'Gallery Item Name',
						'filter_description' => 'Aenean ut turpis blandit eros convallis',
						'filter_link' => '', 
					],
				],
				'title_field' => '{{{ filter_title }}}',
			]
		);


		$this->end_controls_section();



		// styles

		$this->start_controls_section(
			'filter_gallery_menu_style',
			[
				'label' => __( 'Menu Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'filter_gallery_menu_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filters' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'menu_style_tabs' );

		$this->start_controls_tab(
			'filter_gallery_menu_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'filter_gallery_menu_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'filter_gallery_menu_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'filter_gallery_menu_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .ennova-fg-filter',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'menu_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-fg-filter',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
			'filter_gallery_menu_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'filter_gallery_menu_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'filter_gallery_menu_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'filter_gallery_menu_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .ennova-fg-filter:hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'filter_gallery_menu_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-fg-filter:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'filter_gallery_menu_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_tab();

		$this->start_controls_tab(
			'filter_gallery_style_active',
			[
				'label' => __( 'Active', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'filter_gallery_color_active',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter.active' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'filter_gallery_color_bg_active',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter.active' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		create_color_control(
			$this,
			[
				'key'       => 'filter_gallery_active_border_color',
				'label'     => 'Border Color',
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter.active' => 'border-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_gallery_active_color_hover',
			[
				'label'     => __( 'Hover Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter.active:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'filter_gallery_active_color_bg_hover',
			[
				'label'     => __( 'Hover Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ennova-fg-filter.active:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		create_color_control(
			$this,
			[
				'key'       => 'filter_gallery_active_border_color_hover',
				'label'     => ' Hover Border Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-fg-filter.active:hover' => 'border-color: {{VALUE}};',
				],
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();


		//gallery Box Settings
		$this->start_controls_section(
			'gallery_box_settings',
			[
				'label' => __( 'Box Settings ', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE, 
			]
		);
		
		$slug = 'gallery_box';

		$this->start_controls_tabs( $slug.'_tabs' );

		

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_class.'' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->gallery_card_class.':before' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		//gallery Content Settings
		$this->start_controls_section(
			'gallery_content_settings',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE, 
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_content_class.'' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_content_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_content_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class.':hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->gallery_card_content_class.':before' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_content_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_content_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_content_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();


		//gallery Image Settings
		$this->start_controls_section(
			'image_settings',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'bg_opacity_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Overlay', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->gallery_card_image_class.'::before',
			]
		);

		$this->add_responsive_control(
			'bg_overlay_opacity',
			[
				'label' => esc_html__( 'Opacity', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_image_class.'::before' => 'opacity: {{SIZE}};',
				]
			]
		);

		$this->start_controls_tabs( 'card_image_tabs' );

		$this->start_controls_tab(
			'card_heading_image_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
	
		$this->add_responsive_control(
			'image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_image_class.' ' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_image_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio_six .'.$this->gallery_card_image_class.'::before' => 'width: calc( {{SIZE}}{{UNIT}} - 10%);',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_image_class.' ' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_image_class.'::before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio_six .'.$this->gallery_card_image_class.'::before' => 'height: calc( {{SIZE}}{{UNIT}} - 10%);',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'image_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_image_class.' img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_image_class.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_image_class.'::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .portfolio_nine .'.$this->gallery_card_image_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_image_class.' img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_image_class.'::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_image_class.' img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_image_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_responsive_control(
			'image_width_hover',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' ' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.'::before' => 'width:  {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_class.'portfolio_six:hover .'.$this->gallery_card_image_class.'::before' => 'width: calc( {{SIZE}}{{UNIT}} - 10%);',
				],
			]
		);

		$this->add_responsive_control(
			'image_height_hover',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' '  => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.'::before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_class.'portfolio_six:hover .'.$this->gallery_card_image_class.'::before' => 'height: calc( {{SIZE}}{{UNIT}} - 10%);',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'image_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' img' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' img'  =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' img'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_image_class.' img' ,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();
		
		//gallery Icon Settings
		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Icon Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'card_icon_tabs' );

		$this->start_controls_tab(
			'card_heading_icon_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_icon_bg_color',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_icon_class.' a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_icon_class.' a i' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->gallery_card_icon_class.' a svg' => 'fill: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'icon_width',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_icon_class. ' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_icon_class . ' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_icon_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_icon_bg_color_hover',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_card_style' => ['layout_3', 'layout_4'],
				]
			]
		);

		$this->add_control(
			'card_heading_icon_before_bg_color_hover',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_card_style!' => ['layout_3', 'layout_4'],
				]
			]
		);

		$this->add_control(
			'card_heading_icon_color_hover',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_width_hover',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size_hover',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover i' =>  'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:before' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_icon_class.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_icon_class.' a:hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		//gallery Title Settings
		$this->start_controls_section(
			'gallery_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_tabs' );

		$this->start_controls_tab(
			'card_heading_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_heading_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_heading_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_title_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_heading_class.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_heading_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_heading_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_heading_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();

		//gallery Subtitle Settings
		$this->start_controls_section(
			'gallery_description',
			[
				'label' => __( 'Description ', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class => 'text-align: {{VALUE}};',
					
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_subtitle_tabs' );

		$this->start_controls_tab(
			'card_heading_description_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_description_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->gallery_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_description_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_description_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_description_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_description_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_description_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_class.':hover .'.$this->gallery_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_description_class.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->gallery_card_description_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->gallery_card_description_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->gallery_card_description_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section(); 

	}

	protected function render() {
		$settings = $this->get_settings_for_display(); 
		$show_title = $settings['show_title']; 
		$show_icon = $settings['show_buttons'];
		$show_subtitle = $settings['show_description'];

		
		$card_icon = $settings['btn1_icon'];
		$card_two_icon = $settings['btn2_icon'];

		if ( $settings['menus'] ) { ?>
			<div class="ennova-fg-filters">
				<?php 
				foreach (  $settings['menus'] as $key => $item ) { 
					 ?>
					<span class="ennova-fg-filter <?php if($key == 0) { echo 'active';} ?>" data-filter="<?php echo esc_attr($item['menu_title']) ?>"><?php echo esc_html($item['menu_title']) ?></span>
				<?php } ?>
    		</div>
		<?php
		}
		if ( $settings['filter_gallery_content_list'] ) { ?>
			<div class="ennova-fg-projects"> 

			<?php foreach (  $settings['filter_gallery_content_list'] as $item ) {
				
				$title = $item['filter_title'];
				$subtitle = $item['filter_description']; 
				$image_url = $item['content_image']['url']; 
				$link = $item['filter_link']['url'];
				$target = $item['filter_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $item['filter_link']['nofollow'] ? ' rel="nofollow"' : ''; ?>
				<div class="ennova-fg-project" data-filter="<?php echo esc_attr($item['filter_name']) ?>">
				<?php 
				$template_card_style = $settings['template_card_style'];
				$template_overlay_style = $settings['template_overlay_style'];
				$template_path = ENNOVA_PATH . 'inc/templates/gallery-items/';

				switch ($template_card_style) {
					case 'layout_1':
						require $template_path. 'layout-1.php';
						break;
					case 'layout_2':
						require $template_path. 'layout-2.php';
						break;
					case 'layout_3':
						require $template_path. 'layout-3.php';
						break;
					case 'layout_4':
						require $template_path. 'layout-4.php';
						break;
					case 'layout_5':
						require $template_path. 'layout-5.php';
						break;
				}

				switch ($template_overlay_style) {
					case 'layout_6':
						require $template_path. 'layout-6.php';
						break;
					case 'layout_7':
						require $template_path. 'layout-7.php';
						break;
					case 'layout_8':
						require $template_path. 'layout-8.php';
						break;
					case 'layout_9':
						require $template_path. 'layout-9.php';
						break;
					case 'layout_10':
						require $template_path. 'layout-10.php';
						break;
				}
				?>	

				</div>
			<?php } ?>
    		</div>
		<?php
		}
	}
}