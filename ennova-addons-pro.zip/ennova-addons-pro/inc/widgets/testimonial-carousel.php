<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Border;

class ENNOVATestimonialCarousel extends \Elementor\Widget_Base {

	private $testimonial_card_class = 'ennova-testimonial-card';
	private $testimonial_card_inner_class = 'ennova-testimonial-inner-card';
	private $testimonial_card_content_class = 'ennova-testimonial-content-card';
	private $testimonial_card_image_class = 'ennova-testimonial-card-image';
	private $testimonial_card_heading_class = 'ennova-testimonial-card-heading';
	private $testimonial_card_icon_class = 'ennova-testimonial-card-icon';
	private $testimonial_card_description_class = 'ennova-testimonial-card-description';
	private $testimonial_card_name_class = 'ennova-testimonial-card-name';
	private $testimonial_card_designation_class = 'ennova-testimonial-card-designation';

	public function get_name() {
		return 'ennova-testimonial-carousel';
	}

	public function get_title() {
		return __( 'Testimonial Carousel', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-testimonial-carousel'; 
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
				'testimonial carousel',
				'reviews',
				'carousel',
				'business reviews', 
				'client',
				'client reviews',
				'our client says',
				'enn',
				'ennova addons'
		];
	}
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 8', 'ennova-addons' ),
					'layout_9'      => esc_html__( 'Layout 9', 'ennova-addons' ),
					'layout_10'      => esc_html__( 'Layout 10', 'ennova-addons' ),
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'template_style', 
			[
				'label' => esc_html__('Template Style', 'ennova-addons') , 
				'type' => \Elementor\Controls_Manager::HIDDEN,
				'default' => 'traditional',
			]
		);

		$repeater->add_control(
			'testimonial_star_style',
			[
				'label' => esc_html__( 'Star Icons', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 5,
				'step' => .5,
				'default' => 4,
			]
		);

		$title ='Professional Team';
		$repeater->add_control(
			'card_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( $title , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'card_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fa fa-quote-right',
					'library' => 'solid',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_4',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_10',
						],
					],
				],
			], 
		);

		$description = 'Aenean ut turpis blandit eros convallis congue sit amet a libero. Mauris sed tempor felis. ';
		$repeater->add_control(
			'card_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => __( $description, 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
			]
		);
		$repeater->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		);

		$name = 'John Doe';
		$repeater->add_control(
			'card_name', [
				'label' => __( 'Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( $name , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$designation = 'Designer'; 
		$repeater->add_control(
			'card_designation',
			[
				'label' => __( 'Designation', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT, 
				'default' => __( $designation, 'ennova-addons' ),
				'placeholder' => __( 'Type your designation here', 'ennova-addons' ),
			]
		); 
		$repeater->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'testimonial_card',
			[
				'label' => __( 'Card', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testimonial_star_style' => '4.5',
						'card_title' => __($title, 'ennova-addons'),
						'card_icon'  => 'fa fa-quote-right',
						'card_description' => __($description, 'ennova-addons'),
						'card_name' => __($name, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
						'card_link' => __('#', 'ennova-addons'),
					],
					[
						'testimonial_star_style' => '4',
						'card_title' => __($title, 'ennova-addons'),
						'card_icon'  => 'fa fa-quote-right',
						'card_description' => __($description, 'ennova-addons'),
						'card_name' => __($name, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
						'card_link' => __('#', 'ennova-addons'),
					],
					[
						'testimonial_star_style' => '5',
						'card_title' => __($title, 'ennova-addons'),
						'card_icon'  => 'fa fa-quote-right',
						'card_description' => __($description, 'ennova-addons'),
						'card_name' => __($name, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
						'card_link' => __('#', 'ennova-addons'),
					],
					[
						'testimonial_star_style' => '4.5',
						'card_title' => __($title, 'ennova-addons'),
						'card_icon'  => 'fa fa-quote-right',
						'card_description' => __($description, 'ennova-addons'),
						'card_name' => __($name, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
						'card_link' => __('#', 'ennova-addons'),
					],
				],
				'title_field' => '{{{ card_title }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		); 
		
		$this->add_control(
			'show_icon',
			[
				'label' => __( 'Show Quote', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						]
					],
				],
			]
		);
		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_image',
			[
				'label' => __( 'Show Image', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_name',
			[
				'label' => __( 'Show Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_designation',
			[
				'label' => __( 'Show Designation', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_star',
			[
				'label' => __( 'Show Star', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider',
			[
				'label' => __( 'Slider Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slide_to_show',
				'label'       => 'Slides to Show',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_to_scroll',
				'label'       => 'Slides to Scroll',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_space_between',
				'label'       => 'Slides Space Between',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 10,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_navigation_arrow',
				'label'     => 'Show Navigation Arrow',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'dot_clickable',
				'label'     => 'Dot Clickable',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'autoplay',
				'label'     => 'AutoPlay',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'autoplay_speed',
				'label'       => 'AutoPlay Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3000,
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		create_number(
			$this,
			[
				'key'         => 'transition_between_slides',
				'label'       => 'Slide Switch Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1000,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'loop',
				'label'     => 'Loop',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'mousewheel',
				'label'     => 'Mouse on Wheel',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'keyboard_control',
				'label'     => 'Keyboard Control',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'display_dots',
				'label'     => 'Show Dots',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'show_scroll_bar',
				'label'     => 'Show Scroll Bar',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);


		$this->end_controls_section();

		$this->card_styles();

		//  Navigation styles
			create_navigation_style( $this, [] );
		//  Navigation styles ends
	}


	protected function render() {
		$settings = $this->get_settings_for_display(); 
		$template_style = $settings['template_style'];

		$show_description = $settings['show_description'];
		$show_image = $settings['show_image'];
		$show_star = $settings['show_star'];
		$show_icon = $settings['show_icon'];
		$show_title = $settings['show_title'];
		$show_designation = $settings['show_designation'];
		$show_name = $settings['show_name'];

		$swiper_container_class = 'swiper swiper-container swiper-' . $this->get_id();

		$template_path = ENNOVA_PATH . 'inc/templates/testimonial/';

		$element_id                  = 'ennova_slider_' . $this->get_id();
		$slide_to_show               = isset( $settings['slide_to_show'] ) && $settings['slide_to_show'] ? $settings['slide_to_show'] : 3;
		$slide_to_show_tablet        = isset( $settings['slide_to_show_tablet'] ) && $settings['slide_to_show_tablet'] ? $settings['slide_to_show_tablet'] : 2;
		$slide_to_show_mobile        = isset( $settings['slide_to_show_mobile'] ) && $settings['slide_to_show_mobile'] ? $settings['slide_to_show_mobile'] : 1;
		$slides_to_scroll            = isset( $settings['slides_to_scroll'] ) && $settings['slides_to_scroll'] ? $settings['slides_to_scroll'] : 3;
		$slides_to_scroll_mobile     = isset( $settings['slides_to_scroll_mobile'] ) && $settings['slides_to_scroll_mobile'] ? $settings['slides_to_scroll_mobile'] : 2;
		$slides_to_scroll_tablet     = isset( $settings['slides_to_scroll_tablet'] ) && $settings['slides_to_scroll_tablet'] ? $settings['slides_to_scroll_tablet'] : 1;
		$slides_space_between        = isset( $settings['slides_space_between'] ) && $settings['slides_space_between'] ? $settings['slides_space_between'] : 10;
		$slides_space_between_mobile = isset( $settings['slides_space_between_mobile'] ) && $settings['slides_space_between_mobile'] ? $settings['slides_space_between_mobile'] : 2;
		$slides_space_between_tablet = isset( $settings['slides_space_between_tablet'] ) && $settings['slides_space_between_tablet'] ? $settings['slides_space_between_tablet'] : 5;
		$display_title_absolute = isset( $settings['display_title_absolute'] ) && $settings['display_title_absolute'] ? $settings['display_title_absolute'] : 'no';
		$dot_clickable               = isset( $settings['dot_clickable'] ) ? $settings['dot_clickable'] : true;
		$title = '';
		if ( isset( $settings['title'] ) && ! empty( $settings['title'] ) ) {
			$title = $settings['title'];
		}

		$autoplay       = false;
		$autoplay_speed = 2000;

		if ( array_key_exists( 'autoplay', $settings ) && $settings['autoplay'] === 'yes' ) {
			$autoplay = true;
			if ( array_key_exists( 'autoplay_speed', $settings ) ) {
				$autoplay_speed = $settings['autoplay_speed'];
			}
		}

		$transition_between_slides = 1000;
		$loop                      = false;
		$mousewheel                = false;
		$keyboard_control          = false;

		if ( isset( $settings['transition_between_slides'] ) && ! empty( $settings['transition_between_slides'] ) ) {
			$transition_between_slides = $settings['transition_between_slides'];
		}

		if ( isset( $settings['loop'] ) && ! empty( $settings['loop'] ) && $settings['loop'] === 'yes' ) {
			$loop = true;
		}
		if ( isset( $settings['mousewheel'] ) && ! empty( $settings['mousewheel'] ) && $settings['mousewheel'] === 'yes' ) {
			$mousewheel = true;
		}
		if ( isset( $settings['keyboard_control'] ) && ! empty( $settings['keyboard_control'] ) && $settings['keyboard_control'] === 'yes' ) {
			$keyboard_control = true;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'ennova-outer-wrapper' );
		$this->add_render_attribute( 'wrapper', 'data-wid', $this->get_id() );
		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . '>';
		echo '<div
        		class="ennova_slider_wrapper "
        		id="' . esc_attr( $element_id ) . '"
        		data-slide-to-show="' . esc_html( $slide_to_show ) . '"
				data-slide-to-show-mobile="' . esc_html( $slide_to_show_mobile ) . '"
				data-slide-to-show-tablet="' . esc_html( $slide_to_show_tablet ) . '"
        		data-slides-to-scroll="' . esc_html( $slides_to_scroll ) . '"
				data-slides-to-scroll-mobile="' . esc_html( $slides_to_scroll_mobile ) . '"
				data-slides-to-scroll-tablet="' . esc_html( $slides_to_scroll_tablet ) . '"
        		data-slides-space-between="' . esc_html( $slides_space_between ) . '"
				data-slides-space-between-mobile="' . esc_html( $slides_space_between_mobile ) . '"
				data-slides-space-between-tablet="' . esc_html( $slides_space_between_tablet ) . '"
				data-autoplay="' . esc_html( $autoplay ) . '"
				data-autoplay-speed="' . esc_html( $autoplay_speed ) . '"
				data-transition_between_slides="' . esc_html( $transition_between_slides ) . '"
				data-loop="' . esc_html( $loop ) . '"
				data-mousewheel="' . esc_html( $mousewheel ) . '"
				data-keyboard_control="' . esc_html( $keyboard_control ) . '"
				data-clickable="' . esc_html( $dot_clickable ) . '"
        	>';

				?>
		<!-- Slider main container -->
		<div class="<?php echo esc_html( $swiper_container_class ); ?>">
			<!-- Additional required wrapper -->
			<div class="swiper-wrapper">
				<?php foreach($settings['testimonial_card'] as $card) {
					$testimonial_star = $card['testimonial_star_style'];
					$rating = $testimonial_star;
					$round_next_rating = round($rating);
					$round_prev_rating = floor($rating);
					$title = $card['card_title'];
					$description = $card['card_description']; 
					$name = $card['card_name']; 
					$designation = $card['card_designation']; 
					$image_url = $card['card_image']['url'];
					$card_icon = $card['card_icon'];
					$link = $card['card_link']['url'];
					$target = $card['card_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $card['card_link']['nofollow'] ? ' rel="nofollow"' : '';
				?>
				<div class="swiper-slide ennova-swiper-slide-testimonial <?php echo 'ennova-tabs-'.$this->get_id() ?>">
				<?php switch ($template_style) {
					case 'layout_1':
					require $template_path. 'layout-1.php';
					break;
					case 'layout_2':
					require $template_path. 'layout-2.php';
					break;
					case 'layout_3':
					require $template_path. 'layout-3.php';
					break;
					case 'layout_4':
					require $template_path. 'layout-4.php';
					break;
					case 'layout_5':
					require $template_path. 'layout-5.php';
					break;
					case 'layout_6':
					require $template_path. 'layout-6.php';
					break;
					case 'layout_7':
					require $template_path. 'layout-7.php';
					break;
					case 'layout_8':
					require $template_path. 'layout-8.php';
					break;
					case 'layout_9':
					require $template_path. 'layout-9.php';
					break;
					case 'layout_10':
					require $template_path. 'layout-10.php';
					break;
					default:
					require $template_path. 'layout-1.php';
					break;
				} ?>
			</div> 
		<?php } ?>
	</div> 
	<!-- end swiper-wrapper -->
	<?php
		if (
				$settings['display_dots'] === 'yes'
			) {
			?>
			<!-- If we need pagination -->
			<div class="swiper-pagination"></div>
			<?php
		}
		?>
		<?php
		if (
				$settings['show_navigation_arrow'] === 'yes'
			) {
			?>
			<!-- If we need navigation buttons -->
			<div class="swiper-button-prev"></div>
			<div class="swiper-button-next"></div>
			<?php
		}
		?>
		<?php
		if (
				$settings['show_scroll_bar'] === 'yes'
			) {
			?>
			<!-- If we need scrollbar -->
			<div class="swiper-scrollbar"></div>
			<?php
		}
		?>
	</div>
	<!-- end swiper-container -->
	<?php
			echo "</div>";
			echo "</div>";
	}

	function card_styles() {

		//STYLE
		//Testimonial Box Settings
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => __( 'Testimonial Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style!' => ['layout_5', 'layout_7']
				]
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover' => 'background-color: {{VALUE}}',
				],
			
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();

		//Testimonial Inner Box Settings
		$this->start_controls_section(
			'testimonial_inner_settings',
			[
				'label' => __( 'Testimonial Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_5', 'layout_7']
				]
			]
		);

		$this->start_controls_tabs( 'card_inner_tabs' );

		$this->start_controls_tab(
			'card_inner_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_inner_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_inner_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->testimonial_card_inner_class.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_inner_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_inner_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_inner_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_inner_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_inner_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_inner_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_inner_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_inner_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_inner_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_inner_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_inner_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_inner_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class.'::before' => 'background-color: {{VALUE}}',
				],
			
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_inner_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_inner_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_inner_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_inner_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_inner_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_inner_class,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();

		//Testimonial Content Box Settings
		$this->start_controls_section(
			'testimonial_content_settings',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_7']
				]
			]
		);

		$this->start_controls_tabs( 'card_content_tabs' );

		$this->start_controls_tab(
			'card_content_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_content_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_content_class => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_content_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_content_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_content_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_content_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_content_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_content_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_content_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_content_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_content_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_content_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_content_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_content_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class => 'background-color: {{VALUE}}',
				],
			
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_content_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_content_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_content_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_content_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_content_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_content_class,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		//Testimonial Quote Settings
		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Quote Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_4',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_10',
						],
					],
				],
				'condition' => [ 
					'show_icon' => 'yes',
				],
			]
		);

        $this->start_controls_tabs( 'card_quote_tabs' );

		$this->start_controls_tab(
			'card_quote_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_quote_color',
			[
				'label'     => __( ' Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_icon_class.' .testi-icon ' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_quote_bg_color',
			[
				'label'     => __( ' Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_icon_class.' .testi-icon ' => 'background-color: {{VALUE}}',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_1',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
					],
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( ' Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'quote_width',
			[
				'label'           => __( ' Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => ' ',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'card_quote_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => ' Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_quote_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_quote_color_hover',
			[
				'label'     => __( ' Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_quote_bg_color_hover',
			[
				'label'     => __( ' Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon ' => 'background-color: {{VALUE}}',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_1',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
					],
				],
			]
		);
		$this->add_responsive_control(
			'icon_size_hover',
			[
				'label'           => __( ' Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon i' =>  'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'quote_width_hover',
			[
				'label'           => __( ' Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon' =>  'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon' =>  'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_quote_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin_hover',
				'label'     => ' Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		); 

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		//Testimonial Star Settings
		$this->start_controls_section(
			'star_settings',
			[
				'label' => __( 'Star Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_star' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'card_star_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class => 'text-align: {{VALUE}};',
				],
			]
		);
        $this->start_controls_tabs( 'card_star_tabs' );

		$this->start_controls_tab(
			'card_star_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_star_color',
			[
				'label'     => __( 'Star Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_icon_class.' .testi-star' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'star_size',
			[
				'label'           => __( 'Star Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-star' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_star_margin',
				'label'     => 'Star Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_icon_class.' .testi-star i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_star_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_star_color_hover',
			[
				'label'     => __( 'Star Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-star' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'star_size_hover',
			[
				'label'           => __( 'Star Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-star' =>  'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_star_margin_hover',
				'label'     => 'Star Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_icon_class.' .testi-star i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		//Testimonial Title Settings
		$this->start_controls_section(
			'testimonial_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_title' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->start_controls_tabs( 'card_heading_tabs' );

		$this->start_controls_tab(
			'card_heading_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_heading_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_heading_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_heading_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_title_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}   .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}   .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_heading_class,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section(); 
		

		//Testimonial Description Settings
		$this->start_controls_section(
			'testimonial_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE, 
				'condition' => [ 
					'show_description' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'card_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_description_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_description_tabs' );

		$this->start_controls_tab(
			'card_heading_description_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_description_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_description_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_description_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_description_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_description_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_description_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_description_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_description_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_description_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class.'' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_description_class,
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		//Testimonial Image Settings
		$this->start_controls_section(
			'image_settings',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_image' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'card_heading_image_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_image_class => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .testimonial_three .'.$this->testimonial_card_inner_class => 'justify-content: {{VALUE}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_5',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_8',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_9',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_10',
						],
					],
				],
			]
		);

        $this->start_controls_tabs( 'card_image_tabs' );

		$this->start_controls_tab(
			'card_heading_image_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'image_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_image_class.' img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_image_class.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_image_class.' img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_image_class.' ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_image_class.' img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_image_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'image_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' img' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' img'  =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_width_hover',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			'image_height_hover',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' img'  => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' '  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_image_class.' img' ,
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		//Testimonial Name Settings
		$this->start_controls_section(
			'name_settings',
			[
				'label' => __( 'Name Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_name' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			' card_name_alignment',
			[
				'label'     => __( 'Content Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_content_class => 'justify-content: {{VALUE}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_1',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_3',
						],
					],
				],
			]
		);
		$this->add_responsive_control(
			'card_name_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_name_class => 'text-align: {{VALUE}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						],
					],
				],
			]
		);
		$this->start_controls_tabs( 'card_name_tabs' );
		
		$this->start_controls_tab(
			'card_name_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]	
		);
		$this->add_control(
			'card_name_title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_name_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_name_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_name_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_name_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_name_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_name_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_name_title_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_name_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_name_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_name_class
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_name_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_name_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		//Testimonial Designation Settings
		$this->start_controls_section(
			'designation_settings',
			[
				'label' => __( 'Designation Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_designation' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'card_designation_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_designation_class => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->start_controls_tabs( 'card_designation_tabs' );
		
		$this->start_controls_tab(
			'card_designation_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]	
		);
		$this->add_control(
			'card_designation_title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_designation_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_designation_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->testimonial_card_designation_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_designation_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_designation_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_designation_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_designation_title_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_designation_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_designation_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_designation_class
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_designation_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->testimonial_card_class.':hover .'.$this->testimonial_card_designation_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();
	}
}