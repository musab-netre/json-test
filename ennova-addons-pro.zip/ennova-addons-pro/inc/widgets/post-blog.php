<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use ElementorPro\Modules\Posts\Widgets\Posts_Base;
use Elementor\Group_Control_Background;
use WP_Query;

class ENNOVAPostBlog extends \Elementor\Widget_Base {

	private $blog_card_class = 'ennova-blog-card';
	private $blog_inner = 'ennova-blog-card-inner';
	private $blog_category = 'ennova-blog-card-category';
	private $blog_img = 'ennova-blog-card-image';
	private $blog_title = 'ennova-blog-card-title';
	private $blog_desc = 'ennova-blog-card-description';
	private $blog_meta = 'ennova-blog-card-meta';
	private $blog_btn = 'ennova-blog-card-button';

	public function get_name() {
		return 'ennova-post-blog';
	}

	public function get_title() {
		return __( 'Blog Post', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-blog-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-posts-grid';
	}

	public function get_style_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_keywords() {
		return [
			'post blog',
			'news',
			'post',
			'blog',
			'enn',
			'ennova addons',
		];
	}
	
	protected function register_controls() {
		$this->start_controls_section(
			'item_configuration',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'blog_design',
			[
				'label'       => esc_html__( 'Blog Post Layout', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'card',
				'options'     => [
					'card'      => esc_html__( 'Card', 'ennova-addons' ),
					'over'      => esc_html__( 'Overlay', 'ennova-addons' ), 
				],
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ), 
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
				],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'post_author',
				'label'       => 'Authors',
				'placeholder' => 'Choose Author to Include',
				'options'     => ennova_get_all_authors(),
				'multiple'    => true,
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'post_category',
				'label'       => 'Categories',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_categories(),
				'multiple'    => true,
			]
		);
		$this->add_control(
			'category_style',
			[
				'label'       => esc_html__( 'Categories Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'one',
				'options'     => [
					'one'      => esc_html__( 'Style 1', 'ennova-addons' ),
					'two'      => esc_html__( 'Style 2', 'ennova-addons' ),
					'three'      => esc_html__( 'Style 3', 'ennova-addons' ),
					'four'      => esc_html__( 'Style 4', 'ennova-addons' ), 
					'five'      => esc_html__( 'Style 5', 'ennova-addons' ), 
 
				],
			]
		);
		create_select2(
			$this,
			[
				'key'         => 'post_tags',
				'label'       => 'Tags',
				'placeholder' => 'Choose Tag to Include',
				'options'     => ennova_get_tags(),
				'multiple'    => true,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'number_of_posts',
				'label'       => 'Number of Posts',
				'placeholder' => 'Default is 6',
				'min'         => 1,
				'default'     => 6,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'post_count_per_row',
				'label'       => 'Post Count Per Row',
				'placeholder' => '3',
				'min'         => 1,
				'max'         => 6,
				'default'     => '',
				'selectors'       => [
					'{{WRAPPER}} .enn-blog-grid' =>  'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				], 
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'title_length',
				'label'       => 'Title Length',
				'placeholder' => '10',
				'min'         => 0,
				'default'     => 10,
				'description' => 'Enter 0 to hide Title',
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'excerpt_length',
				'label'       => 'Excerpt Length',
				'placeholder' => '20',
				'min'         => 0,
				'default'     => 20,
				'description' => 'Enter 0 to hide Excerpt',
				'condition'   => [
					'blog_design' => 'card',
					'template_style!' => 'layout_5',
				],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'order_by',
				'label'       => 'Order By',
				'placeholder' => 'Order By',
				'options'     => [
					'none' => 'None',
					'ID' => 'ID',
					'author' => 'Author',
					'title' => 'Title',
					'name' => 'Name',
					'type' => 'Type',
					'date' => 'Date',
					'modified' => 'Modified',
					'parent' => 'Parent',
					'rand' => 'Random',
					'comment_count' => 'Comment_count',
				],
				'multiple'    => false,
			]
		);
		create_select2(
			$this,
			[
				'key'         => 'order',
				'label'       => 'Order',
				'placeholder' => 'Order',
				'options'     => [
					'ASC' => 'Ascending',
					'DESC' => 'Descending'
				],
				'multiple'    => false,
			]
		);

		create_slider_control(
			$this,
			[
				'key'             => 'column_space_between',
				'label'           => 'Column Space',
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .enn-blog-grid' => 'grid-column-gap :{{SIZE}}{{UNIT}};',
				], 
			]
		);

		create_slider_control(
			$this,
			[
				'key'             => 'row_space_between',
				'label'           => 'Row Space', 
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .enn-blog-grid' => 'grid-row-gap :{{SIZE}}{{UNIT}};',
				], 
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_image_size_control(
			$this,
			[
				'name'      => 'thumbnail_size',
				'default'   => 'large'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_date',
				'label'     => 'Show Date',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);
		
		create_switcher(
			$this,
			[
				'key'       => 'show_author',
				'label'     => 'Show Author',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_comments',
				'label'     => 'Show Comments',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_category',
				'label'     => 'Show Category',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_title',
				'label'     => 'Show Title',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_read_more',
				'label'     => 'Show Read More',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes',
				'condition'   => [
					'blog_design' => 'card',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition'   => [
					'blog_design' => 'card'
				],
			]
		);

		$this->add_control(
			'card_link_text', [
				'label' => __( 'Button Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Read More' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'link_button_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => ['value' => 'fa fa-arrow-right', 'library' => 'brands',],
			]
		);

		$this->add_control(
			'link_button_position',
			[
				'label'       => esc_html__( 'Icon Position', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'after',
				'options'     => [
					'before'      => esc_html__( 'Before', 'ennova-addons' ),
					'after'      => esc_html__( 'After', 'ennova-addons' ),
				]
			]
		);
		$this->add_responsive_control(
			'link_button_space_before',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_btn.' i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'link_button_position',
							'operator' => '===',
							'value'    => 'before',
						]
					],
				],
			]
		);

		$this->add_responsive_control(
			'link_button_space_after',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_btn.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'link_button_position',
							'operator' => '===',
							'value'    => 'after',
						]
					],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'pagination',
			[
				'label' => __( 'Pagination Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT, 
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'pagination_type',
				'label'       => 'Pagination',
				'placeholder' => 'Choose pagination to include',
				'options'     => [
					'none' => 'None',
					'numbers' => 'Numbers',
					'previous/next' => 'Previous/Next',
					'numbers+previous/next' => 'Numbers + Previous/Next',
				],
				'default' => 'numbers',
				'multiple'    => false,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_all_number',
				'label'     => 'Show All Number',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes',
				'condition'   => [
					'pagination_type' => ['numbers','numbers+previous/next']
				],
			]
		);

		create_alignment(
			$this,
			[
				'key'       => 'pagination_align',
				'label'     => 'Alignment',
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .navigation' => 'justify-content: {{VALUE}}',
				],
				'condition'   => [
					'pagination_type!' => 'none',
				],
			]
		); 

		$this->end_controls_section();
		
		//STYLE
		$this->start_controls_section(
			'blog_style',
			[
				'label' => __( 'Blog Post Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'blog_box';

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_card_class => 'background-color: {{VALUE}}',
				], 
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding',
				'label'     => 'Inner Content Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_inner.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .six .'.$this->blog_category.'' => 'padding: 0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_bg_hover_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_card_class.':hover' => 'background-color: {{VALUE}}',
				], 
			]
		);
		 
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding_hover',
				'label'     => 'Inner Content Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_inner.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .six .'.$this->blog_inner.':hover .'.$this->blog_category.'' => 'padding: 0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_card_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();


		$this->start_controls_section(
			'image_style',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'blog_image';

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => $slug.'_opacity_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Overlay', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  =>  '{{WRAPPER}} .'.$this->blog_card_class.' .lg:after', 
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_1',
						],
						[
							'name'     => 'blog_design',
							'operator' => '!==',
							'value'    => 'card',
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => $slug.'_opacity_six_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Overlay', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  =>  
					'{{WRAPPER}} .six .'.$this->blog_inner.':after',
				'condition'   => [
					'blog_design!' => 'card',
					'template_style' => 'layout_1',
				],
			]
		);

		$this->add_responsive_control(
			$slug.'_overlay_opacity',
			[
				'label' => esc_html__( 'Opacity', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .'.$this->blog_card_class.' .lg:after' => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .'.$this->blog_card_class.'.six .'.$this->blog_inner.':after' => 'opacity: {{SIZE}};',
				],
				'condition'   => [
					'blog_design!' => 'card'
				],
			]
		);
	
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.' ' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.' ' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_img.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_img.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);
		
		$this->add_responsive_control(
			$slug.'_hover_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_hover_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_img.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_img.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Blog Category
		$this->start_controls_section(
			'blog_category_settings',
			[
				'label' => __( 'Category Settings ', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,   
				
			]
		);
		
		$slug = 'blog_category';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_align',
				'label'     => 'Alignment',
				'options'   => [
					'start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a',
			]
		);

		
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_category.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			$slug.'_color_bg_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a:hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_category.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'title_html_tag',
				'label'       => 'Title HTML Tag',
				'placeholder' => 'Choose Tag to Include',
				'options'     => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
				],
				'default' => 'h4',
				'multiple'    => false,
			]
		);

		$slug = 'blog_title';

		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_title.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title,
			]
		); 
		
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_title,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.' a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_title.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 

		$this->add_control(
			$slug.'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
				'condition'   => [
					'template_style' => 'layout_2'
				]
			]
		);

		$this->add_responsive_control(
			$slug.'_seperator_height',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_title.':after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'template_style' => ['layout_2']
				]
			]
		);

		$this->add_control(
			$slug.'_seperator_color',
			[
				'label'     => __( 'Seperator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':after' => 'background-color: {{VALUE}}',
				],
				'condition'   => [
					'template_style' => 'layout_2'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'metas_style',
			[
				'label' => __( 'Metas Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'metas';

		create_alignment(
			$this,
			[
				'key'       => $slug.'_align',
				'label'     => 'Alignment',
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta => 'justify-content: {{VALUE}}',
				],
			]
		);
		
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a i' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_meta.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_hover_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a:hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_meta.' a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			$slug.'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
				'condition'   => [
					'template_style' => ['layout_2', 'layout_3']
				]
			]
		);

		$this->add_responsive_control(
			$slug.'_seperator_height',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_meta => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'template_style' => ['layout_2', 'layout_3']
				]
			]
		);

		$this->add_control(
			$slug.'_seperator_color',
			[
				'label'     => __( 'Seperator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta => 'border-top-color: {{VALUE}}; border-bottom-color: {{VALUE}}',
				],
				'condition'   => [
					'template_style' => ['layout_2', 'layout_3']
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'excerpt_style',
			[
				'label' => __( 'Excerpt Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'blog_design' => 'card'
				]
			]
		);

		$slug = 'excerpt';

		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.'' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_desc.'',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_desc,
			]
		);
		
		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_desc,
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class.' .'.$this->blog_desc.':hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_desc.':hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_desc.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_desc.':hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			$slug.'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
				'condition'   => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_responsive_control(
			$slug.'_seperator_height',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_desc => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_control(
			$slug.'_seperator_color',
			[
				'label'     => __( 'Seperator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_desc => 'border-bottom-color: {{VALUE}}',
				],
				'condition'   => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'blog_design' => 'card'
				],
			]
		);

		$slug = 'button'; 

		create_alignment(
			$this,
			[
				'key'       => $slug.'_text_align',
				'label'     => 'Alignment',
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => ' ',
				'selectors' => [
					'{{WRAPPER}} .enn-more-link' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.'' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.'' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_btn.'',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_btn.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_btn.'',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.':hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.':hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_btn.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_btn.':hover',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_btn.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_btn.':hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'pagination_style',
			[
				'label' => __( 'Pagination Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'pagination';
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers:hover',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_active_style',
			[
				'label' => __( 'Active', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_background_color',
				'label'     => 'Active Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_color',
				'label'     => 'Active Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_background_color_hover',
				'label'     => 'Active Hover Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_color_hover',
				'label'     => 'Active Hover Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_border_color_hover',
				'label'     => 'Active Hover Border Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current:hover' => 'border-color: {{VALUE}};',
				],
			]
		);	

		create_color_control(
			$this,
			[
				'key'       => $slug.'active_border_color',
				'label'     => 'Active Border Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li span.page-numbers.current' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$template_style = $settings['template_style'];
		$category_style = $settings['category_style'];
		
		$blog_design = $settings['blog_design'];

		$show_author = $settings['show_author'];
		$show_date = $settings['show_date'];
		$show_comments = $settings['show_comments'];
		$show_category = $settings['show_category'];
		$show_title = $settings['show_title'];
		$show_read_more = $settings['show_read_more'];
		$show_all_number = $settings['show_all_number'] == 'yes' ? true : false;

		$title_html_tag = $settings['title_html_tag'];

		$excerpt_length = $settings['excerpt_length'];
		$title_length = $settings['title_length'];
		$post_count_per_row = $settings['post_count_per_row'];
		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1; 

		$link_text = $settings['card_link_text']; 
		$link_button_icon = $settings['link_button_icon'];
		$link_button_position = $settings['link_button_position'];

		$args = array(
			'posts_per_page' => 5,
			'orderby' => 'ID',
			'order' => 'DESC',
			'post_type' => 'post',
			'post_status' => 'publish',
			'paged' => $paged
		);

		if ( isset( $settings['post_category'] ) && is_array( $settings['post_category'] ) && ! empty( $settings['post_category'] ) ) {
			$args['cat'] = implode(',',  $settings['post_category']);
		}

		if ( isset( $settings['post_author'] ) && is_array( $settings['post_author'] ) && ! empty( $settings['post_author'] ) ) {
			$args['author'] = implode(',',  $settings['post_author']);
		}

		if ( isset( $settings['post_tags'] ) && is_array( $settings['post_tags'] ) && ! empty( $settings['post_tags'] ) ) {
			$args['tag'] = implode(',', $settings['post_tags'] );
		}

		if ( isset( $settings['order_by'] ) && ! empty( $settings['order_by'] ) ) {
			$args['orderby'] = $settings['order_by'];
		}

		if ( isset( $settings['order'] ) && ! empty( $settings['order'] ) ) {
			$args['order'] = $settings['order'];
		}

		if ( isset( $settings['number_of_posts'] ) && ! empty( $settings['number_of_posts'] ) ) {
			$args['posts_per_page'] = $settings['number_of_posts'];
		}

		$wp_query = new WP_Query( $args );

		?>
		<div class="enn-blog-grid">
			<?php
				if ( $wp_query->have_posts() ) :
					while ( $wp_query->have_posts() ) : $wp_query->the_post();
						$thumbnail_id = get_post_thumbnail_id();
						$thumbnail_size_key = 'thumbnail_size';
						$comments_count = get_comments_number();
						$categories_names = [];
						$categories = get_the_category();

						if ( count($categories) > 0 ) {
							foreach($categories as $category ) {
								$category = (array) $category;
								$categories_names[] = $category['name'];
							}
						}

						$params = [ 
							'settings' => $settings, 
							'excerpt_length' => $excerpt_length,
							'title_length' => $title_length,
							'thumbnail_id' => $thumbnail_id,
							'thumbnail_size_key' => $thumbnail_size_key,
							'categories' => $categories,
							'comments_count' => $comments_count,
							
						];
						$template_path = ENNOVA_PATH . 'inc/templates/post-blog/';
				
						switch ($template_style) {
							case 'layout_1':
								require $template_path. 'layout-1.php';
								break;
							case 'layout_2':
								require $template_path. 'layout-2.php';
								break;
							case 'layout_3':
								require $template_path. 'layout-3.php';
								break;
							case 'layout_4':
								require $template_path. 'layout-4.php';
								break; 
							case 'layout_5':
								require $template_path. 'layout-5.php';
								break; 
							default:
								require $template_path. 'layout-1.php';
								break;
						}
					endwhile;
					?>
			<?php
			endif;
		?>
		</div>
		<?php
			$pagination_type = $settings['pagination_type'];
			if ( $pagination_type !== 'none' ) {
				if ( $pagination_type === 'numbers+previous/next' ) {
					$this->ennova_pagi_number_pre_next( $wp_query );
				} else if ( $pagination_type === 'previous/next' ) {
					$this->ennova_pagi_previous_next( $wp_query );
				} else {
					$this->ennova_numeric_posts_pagination( $wp_query , $show_all_number);
				}
			}
		?>
		<?php
			wp_reset_postdata();
		?>
		<?php
	}

	function ennova_pagi_previous_next( $wp_query ) {

		if( $wp_query->max_num_pages <= 1 )
			return;

		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
		$max   = intval( $wp_query->max_num_pages );

		/** Add current page to the array */
		if ( $paged >= 1 )
			$links[] = $paged;

		/** Add the pages around the current page to the array */
		if ( $paged >= 3 ) {
			$links[] = $paged - 1;
			$links[] = $paged - 2;
		}

		if ( ( $paged + 2 ) <= $max ) {
			$links[] = $paged + 2;
			$links[] = $paged + 1;
		}

		echo '<div class="ennova-navigation navigation ennova-pagi-p-n"><ul>' . "\n";
		echo "<li><a href='". get_previous_posts_page_link() ."' class='page-numbers ennova-pagi-pre-btn'>Previous</a></li>";
		echo "<li><a href='". get_next_posts_page_link() ."' class='page-numbers'>Next</a></li>";
		echo '</ul></div>' . "\n";

	}

	function ennova_pagi_number_pre_next( $wp_query, $show_all = false ) {
		$big = 999999999; // need an unlikely integer
		echo '<div class=" ennova-navigation navigation">' . "\n";
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var('paged') ),
			'total' => $wp_query->max_num_pages,
			'show_all' =>  $show_all,
			'type'       => 'list',
			'mid_size'   => 1,
		) );
		echo '</div>' . "\n";
	}

	function ennova_numeric_posts_pagination( $wp_query , $show_all = false  ) {
		$big = 999999999; // need an unlikely integer
		echo '<div class="ennova-navigation navigation">' . "\n";
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var('paged') ),
			'total' => $wp_query->max_num_pages,
			'show_all' => $show_all,
			'type'       => 'list',
			'mid_size'   => 1,
			'prev_next'  => false,
		) );
		echo '</div>' . "\n";
	}
	function ennova_numeric_posts_pagination1( $wp_query , $show_all ) {
		if( $wp_query->max_num_pages <= 1 )
			return;

		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
		$max   = intval( $wp_query->max_num_pages );

		/** Add current page to the array */
		if ( $paged >= 1 )
			$links[] = $paged;

		/** Add the pages around the current page to the array */
		if ( $paged >= 3 ) {
			$links[] = $paged - 1;
			$links[] = $paged - 2;
		}

		if ( ( $paged + 2 ) <= $max ) {
			$links[] = $paged + 2;
			$links[] = $paged + 1;
		}

		echo '<div class="ennova-navigation navigation"><ul>' . "\n";

		/** Previous Post Link */
		if ( get_previous_posts_link() )
			printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

		/** Link to first page, plus ellipses if necessary */
		if ( ! in_array( 1, $links ) ) {
			$class = 1 == $paged ? ' class="active"' : '';

			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

			if ( ! in_array( 2, $links ) )
				echo '<li>…</li>';
		}

		/** Link to current page, plus 2 pages in either direction if necessary */
		sort( $links );
		foreach ( (array) $links as $link ) {
			$class = $paged == $link ? ' class="active"' : '';
			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
		}

		/** Link to last page, plus ellipses if necessary */
		if ( ! in_array( $max, $links ) ) {
			if ( ! in_array( $max - 1, $links ) )
				echo '<li>…</li>' . "\n";

			$class = $paged == $max ? ' class="active"' : '';
			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
		}

		/** Next Post Link */
		if ( get_next_posts_link() )
			printf( '<li>%s</li>' . "\n", get_next_posts_link() );

		echo '</ul></div>' . "\n";

	}
}