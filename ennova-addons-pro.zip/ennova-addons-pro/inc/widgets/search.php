<?php namespace EnnovaAddons;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Border;

class ENNOVASearch extends Widget_Base {

    private $search_submit_class = 'ennova-search-submit';
    private $search_submit_class_hover = 'ennova-search-submit:hover';

    public function __construct( $data = array(), $args = null ) {
        parent::__construct( $data, $args );
    }

    public function get_name() {
        return 'ennova-search';
    }

    public function get_title() {
        return __( 'Search', 'ennova-addons' );
    }

    public function get_icon() {
        return 'enn-icon eaicon eicon-site-search';
    }

    public function get_categories() {
        return array( 'wc-hf-element' );
    }

    public function get_style_depends() {
        return [
            'jquery-auto-complete-css',
            'ennova-styles-css',
        ];

    }

    public function get_script_depends() {
        return ['ennova-search-js'];

    }
    
    public function get_keywords() {
        return [
            'search ',
            'ennova addons',
            'enn',
            'find',
            'header footer',
        ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_general_fields',
            [
                'label' => __( 'Search Box', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'        => __( 'Layout', 'ennova-addons' ),
                'type'         => Controls_Manager::SELECT,
                'default'      => 'text_title',
                'options'      => [
                    'icon'      => __( 'Icon', 'ennova-addons' ),
                    'text_title'      => __( 'Input Box With Text', 'ennova-addons' ),
                    'icon_text' => __( 'Input Box With Icon', 'ennova-addons' ),
                ],
                'prefix_class' => 'ennova-search-layout-',
                'render_type'  => 'template',
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label'     => __( 'Placeholder', 'ennova-addons' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Type Here & Search', 'ennova-addons' ) . '...',
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'search_width',
            [
                'label'           => __( 'Width', 'ennova-addons' ),
                'type'            => Controls_Manager::SLIDER,
                'size_units'      => [ 'px', '%' ],
                'range'           => [
                    'px' => [
                        'min' => 0,
                        'max' => 1200,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices'         => [ 'desktop', 'tablet', 'mobile' ],
                'desktop_default' => [
                    'size' =>'' ,
                    'unit' => '%',
                ],
                'tablet_default'  => [
                    'size' => '',
                    'unit' => '%',
                ],
                'mobile_default'  => [
                    'size' => '',
                    'unit' => '%',
                ],
                'selectors'       => [
                    '{{WRAPPER}} .ennova_search_container' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ],
        );

        $this->add_responsive_control(
            'search_height',
            [
                'label'           => __( 'Height', 'ennova-addons' ),
                'type'            => Controls_Manager::SLIDER,
                'size_units'      => [ 'px', '%' ],
                'range'           => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices'         => [ 'desktop', 'tablet', 'mobile' ],
                'desktop_default' => [
                    'size' => '',
                    'unit' => '%',
                ],
                'tablet_default'  => [
                    'size' => '',
                    'unit' => '%',
                ],
                'mobile_default'  => [
                    'size' => '',
                    'unit' => '%',
                ],
                'selectors'       => [
                    '{{WRAPPER}} .ennova_search_container' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_text_title',
            [
                'label'     => __( 'Button Title', 'ennova-addons' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Search', 'ennova-addons' ) . '...',
                'label_block' => true,
                'conditions' => [
                    'relation' => 'and',
                    'terms'    => [
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon',
                        ],
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon_text',
                        ],
                    ],
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_input_style',
            [
                'label' => __( 'Input', 'ennova-addons' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'input_typography',
                'selector' => '{{WRAPPER}} input[type="search"].ennova_search_input,{{WRAPPER}} .ennova-search-icon-toggle',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
            ]
        );

        $this->add_responsive_control(
            'input_icon_size',
            [
                'label'              => __( 'Width', 'ennova-addons' ),
                'type'               => Controls_Manager::SLIDER,
                'default'            => [
                    'size' => 250,
                ],
                'range'              => [
                    'px' => [
                        'min' => 0,
                        'max' => 1500,
                    ],
                ],
                'selectors'          => [
                    '{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle input[type=search]' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition'          => [
                    'layout' => 'icon',
                ],
                'frontend_available' => true,
            ]
        );

        $this->start_controls_tabs( 'tabs_input_colors' );

        $this->start_controls_tab(
            'tab_input_normal',
            [
                'label'     => __( 'Normal', 'ennova-addons' ),
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_text_color',
            [
                'label'     => __( 'Text Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_TEXT,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_input' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_placeholder_color',
            [
                'label'     => __( 'Placeholder Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_input::placeholder' => 'color: {{VALUE}}',
                ], 
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_background_color',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_input, {{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .ennova-search-icon-toggle .ennova_search_input' => 'background-color: transparent;',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'input_box_shadow',
                'selector'  =>'{{WRAPPER}} .ennova_search_container,{{WRAPPER}} .ennova_search_input',
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_style',
            [
                'label'       => __( 'Border Style', 'ennova-addons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'none',
                'label_block' => false,
                'options'     => [
                    'none'   => __( 'None', 'ennova-addons' ),
                    'solid'  => __( 'Solid', 'ennova-addons' ),
                    'double' => __( 'Double', 'ennova-addons' ),
                    'dotted' => __( 'Dotted', 'ennova-addons' ),
                    'dashed' => __( 'Dashed', 'ennova-addons' ),
                ],
                'selectors'   => [
                    '{{WRAPPER}} .ennova_search_container ,{{WRAPPER}} .ennova-search-icon-toggle .ennova_search_input,{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-style: {{VALUE}};',
                ],
                'condition'   => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label'     => __( 'Border Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'border_style!' => 'none',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_container, {{WRAPPER}} .ennova-search-icon-toggle .ennova_search_input,{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_width',
            [
                'label'      => __( 'Border Width', 'ennova-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'default'    => [
                    'top'    => '',
                    'bottom' => '',
                    'left'   => '',
                    'right'  => '',
                    'unit'   => 'px',
                ],
                'condition'  => [
                    'border_style!' => 'none',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ennova_search_container, {{WRAPPER}} .ennova-search-icon-toggle .ennova_search_input,{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'  => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_radius',
            [
                'label'     => __( 'Border Radius', 'ennova-addons' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_container, {{WRAPPER}} .ennova-search-icon-toggle .ennova_search_input,{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-radius: {{SIZE}}{{UNIT}}',
                ],
                'separator' => 'before',
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_input_focus',
            [
                'label'     => __( 'Focus', 'ennova-addons' ),
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_text_color_focus',
            [
                'label'     => __( 'Text Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_input:focus,
                    {{WRAPPER}} .ennova-search-wrapper input[type=search]:focus' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_placeholder_hover_color',
            [
                'label'     => __( 'Placeholder Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_TEXT,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_input:focus::placeholder' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_background_color_focus',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_input:focus,
                    {{WRAPPER}}.ennova-search-layout-icon .ennova-search-icon-toggle .ennova_search_input' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'           => 'input_box_shadow_focus',
                'selector'       =>
                '{{WRAPPER}} .ennova-search-wrapper.ennova-input-focus .ennova_search_container,
                    {{WRAPPER}} .ennova-search-wrapper.ennova-input-focus input.ennova_search_input',
                'fields_options' => [
                    'box_shadow_type' => [
                        'separator' => 'default',
                    ],
                ],
                'condition'      => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_border_color_focus',
            [
                'label'     => __( 'Border Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_container,
                        {{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'icon_text_color_focus',
            [
                'label'     => __( 'Text Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_input:focus' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'layout' => 'icon',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_text_background_color_focus',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ededed',
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_input:focus' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'layout' => 'icon',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'           => 'icon_box_shadow_focus',
                'selector'       =>
                '{{WRAPPER}} .ennova-search-wrapper.ennova-input-focus .ennova_search_container,
                    {{WRAPPER}} .ennova-search-wrapper.ennova-input-focus input.ennova_search_input',
                'fields_options' => [
                    'box_shadow_type' => [
                        'separator' => 'default',
                    ],
                ],
                'condition'      => [
                    'layout' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'input_border_style',
            [
                'label'       => __( 'Border Style', 'ennova-addons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'none',
                'label_block' => false,
                'options'     => [
                    'none'   => __( 'None', 'ennova-addons' ),
                    'solid'  => __( 'Solid', 'ennova-addons' ),
                    'double' => __( 'Double', 'ennova-addons' ),
                    'dotted' => __( 'Dotted', 'ennova-addons' ),
                    'dashed' => __( 'Dashed', 'ennova-addons' ),
                ],
                'selectors'   => [
                    '{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-style: {{VALUE}};',
                ],
                'condition'      => [
                    'layout' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'input_border_color',
            [
                'label'     => __( 'Border Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'input_border_style!' => 'none',
                    'layout' => 'icon',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova_search_container,
                        {{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'input_border_width',
            [
                'label'      => __( 'Border Width', 'ennova-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'default'    => [
                    'top'    => '',
                    'bottom' => '',
                    'left'   => '',
                    'right'  => '',
                    'unit'   => 'px',
                ],
                'condition'  => [
                    'input_border_style!' => 'none',
                    'layout' => 'icon',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_focus_border_radius',
            [
                'label'     => __( 'Border Radius', 'ennova-addons' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'default'   => [
                    'size' => 3,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ennova-input-focus .ennova-search-icon-toggle .ennova_search_input' => 'border-radius: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'layout' => 'icon',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_button_style',
            [
                'label'     => __( 'Button', 'ennova-addons' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'relation' => 'and',
                    'terms'    => [
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon',
                        ]
                    ],
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_button_colors' );

        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __( 'Normal', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'button_icon_color',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} button.ennova-search-submit' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'           => 'button_background',
                'label'          => __( 'Background', 'ennova-addons' ),
                'types'          => [ 'classic', 'gradient' ],
                'exclude'        => [ 'image' ],
                'selector'       => '{{WRAPPER}} .ennova-search-submit',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color'      => [
                        'default' => '#000000',
                    ],
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_style',
            [
                'label'       => __( 'Border Style', 'ennova-addons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'none',
                'label_block' => false,
                'options'     => [
                    'none'   => __( 'None', 'ennova-addons' ),
                    'solid'  => __( 'Solid', 'ennova-addons' ),
                    'double' => __( 'Double', 'ennova-addons' ),
                    'dotted' => __( 'Dotted', 'ennova-addons' ),
                    'dashed' => __( 'Dashed', 'ennova-addons' ),
                ],
                'selectors'   => [
                    '{{WRAPPER}} .'.$this->search_submit_class => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label'     => __( 'Border Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'button_border_style!' => 'none',
                ],
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_width',
            [
                'label'      => __( 'Border Width', 'ennova-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'default'    => [
                    'top'    => '',
                    'bottom' => '',
                    'left'   => '',
                    'right'  => '',
                    'unit'   => 'px',
                ],
                'condition'  => [
                    'button_border_style!' => 'none',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .'.$this->search_submit_class => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        create_border_radius_control(
            $this,
            [
                'key'       => 'button_border_radius',
                'label'     => 'Border Radius',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        create_dimensions_control(
            $this,
            [
                'key'       => 'button_padding',
                'label'     => 'Padding',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        create_box_shadow_control(
            $this,
            [
                'key'      => 'button_box_shadow',
                'label'    => 'Box Shadow',
                'selector' => '{{WRAPPER}}  .'.$this->search_submit_class,
            ]
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __( 'Hover', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'button_text_color_hover',
            [
                'label'     => __( ' Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-submit:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color_hover',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-submit:hover' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'button_background_color_hover!' => '',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'button_background_hover',
                'label'     => __( 'Background', 'ennova-addons' ),
                'types'     => [ 'classic', 'gradient' ],
                'exclude'   => [ 'image' ],
                'selector'  => '{{WRAPPER}} .ennova-search-submit:hover',
                'condition' => [
                    'button_background_color_hover' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_style_hover',
            [
                'label'       => __( 'Border Style', 'ennova-addons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'none',
                'label_block' => false,
                'options'     => [
                    'none'   => __( 'None', 'ennova-addons' ),
                    'solid'  => __( 'Solid', 'ennova-addons' ),
                    'double' => __( 'Double', 'ennova-addons' ),
                    'dotted' => __( 'Dotted', 'ennova-addons' ),
                    'dashed' => __( 'Dashed', 'ennova-addons' ),
                ],
                'selectors'   => [
                    '{{WRAPPER}} .'.$this->search_submit_class_hover => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color_hover',
            [
                'label'     => __( 'Border Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'button_border_style_hover!' => 'none',
                ],
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class_hover => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_width_hover',
            [
                'label'      => __( 'Border Width', 'ennova-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'default'    => [
                    'top'    => '',
                    'bottom' => '',
                    'left'   => '',
                    'right'  => '',
                    'unit'   => 'px',
                ],
                'condition'  => [
                    'button_border_style_hover!' => 'none',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .'.$this->search_submit_class_hover => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        create_border_radius_control(
            $this,
            [
                'key'       => 'button_border_radius_hover',
                'label'     => 'Border Radius',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class_hover => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        create_dimensions_control(
            $this,
            [
                'key'       => 'button_padding_hover',
                'label'     => 'Padding',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->search_submit_class_hover => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        create_box_shadow_control(
            $this,
            [
                'key'      => 'button_box_shadow_hover',
                'label'    => 'Box Shadow',
                'selector' => '{{WRAPPER}}  .'.$this->search_submit_class_hover,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'icon_size',
            [
                'label'              => __( 'Icon Size', 'ennova-addons' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'            => [
                    'size' => '16',
                    'unit' => 'px',
                ],
                'selectors'          => [
                    '{{WRAPPER}} .ennova-search-submit' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'relation' => 'and',
                    'terms'    => [
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon',
                        ],
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'text_title',
                        ]
                    ],
                ],
                'separator'          => 'before',
                'render_type'        => 'template',
                'frontend_available' => true,
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_text_typography',
                'label' => __( 'Typography', 'ennova-addons' ),
                'selector' => '{{WRAPPER}} .title_btn',
                'conditions' => [
                    'relation' => 'and',
                    'terms'    => [
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon',
                        ],
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon_text',
                        ]
                    ],
                ],
            ]
        );
        $this->add_responsive_control(
            'button_width',
            [
                'label'              => __( 'Width', 'ennova-addons' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'max'  => 500,
                        'step' => 5,
                    ],
                ],
                'selectors'          => [
                    '{{WRAPPER}} .ennova_search_container .ennova-search-submit' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .ennova-close-icon-yes button#clear_with_button' => 'right: {{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'relation' => 'and',
                    'terms'    => [
                        [
                            'name'     => 'layout',
                            'operator' => '!==',
                            'value'    => 'icon',
                        ]
                    ],
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_toggle_style',
            [
                'label'     => __( 'Icon', 'ennova-addons' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout' => 'icon',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_toggle_color' );

        $this->start_controls_tab(
            'tab_toggle_normal',
            [
                'label' => __( 'Normal', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'toggle_color',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-icon-toggle i' => 'color: {{VALUE}}; border-color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'toggle_background_color',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-icon-toggle a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_toggle_hover',
            [
                'label' => __( 'Hover', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'toggle_color_hover',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-icon-toggle i:hover' => 'color: {{VALUE}}; border-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'toggle_background_color_hover',
            [
                'label'     => __( 'Background Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ennova-search-icon-toggle a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'toggle_icon_size',
            [
                'label'              => __( 'Icon Size', 'ennova-addons' ),
                'type'               => Controls_Manager::SLIDER,
                'default'            => [
                    'size' => 15,
                ],
                'selectors'          => [
                    '{{WRAPPER}} .ennova-search-icon-toggle input[type=search]' => 'padding: 0 calc( {{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .ennova-search-icon-toggle i.fa-search:before' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ennova-search-icon-toggle i.fa-search, {{WRAPPER}} .ennova-search-icon-toggle' => 'width: {{SIZE}}{{UNIT}};',

                ],
                'condition'          => [
                    'layout' => 'icon',
                ],
                'separator'          => 'before',
                'render_type'        => 'template',
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_close_icon',
            [
                'label'     => __( 'Close Icon', 'ennova-addons' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout!' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'close_icon_size',
            [
                'label'              => __( 'Size', 'ennova-addons' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default'            => [
                    'size' => '20',
                    'unit' => 'px',
                ],
                'selectors'          => [
                    '{{WRAPPER}} .ennova_search_container button#clear i:before,
                    {{WRAPPER}} .ennova-search-icon-toggle button#clear i:before,
                {{WRAPPER}} .ennova_search_container button#clear-with-button i:before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'frontend_available' => true,

            ]
        );

        $this->start_controls_tabs( 'close_icon_normal' );

        $this->start_controls_tab(
            'normal_close_button',
            [
                'label' => __( 'Normal', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_TEXT,
                ],
                'default'   => '#7a7a7a',
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_container button#clear-with-button,
                    {{WRAPPER}} .ennova_search_container button#clear,
                    {{WRAPPER}} .ennova-search-icon-toggle button#clear' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'hover_close_icon',
            [
                'label' => __( 'Hover', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'hover_close_icon_text',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ennova_search_container button#clear-with-button:hover,
                    {{WRAPPER}} .ennova_search_container button#clear:hover,
                    {{WRAPPER}} .ennova-search-icon-toggle button#clear:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render() {
    
    $settings = $this->get_settings_for_display();

    $this->add_render_attribute(
        'input',
        [
            'placeholder' => $settings['placeholder'],
            'class'       => 'ennova_search_input',
            'type'        => 'search',
            'name'        => 's',
            'title'       => __( 'Search', 'ennova-addons' ),
            'value'       => get_search_query(),
        ]
    );

    $this->add_render_attribute(
        'container',
        [
            'class' => [ 'ennova_search_container' ],
            'role'  => 'tablist',
        ]
    ); ?>

    <form class="ennova-search-wrapper" role="search" action="<?php echo home_url(); ?>" method="get">
        <?php if ( 'icon' === $settings['layout'] ) { ?>
        <div class = "ennova-search-icon-toggle search-box">
            <input <?php echo $this->get_render_attribute_string( 'input' ); ?>>
            <a class="search-btn" type="submit">
            <i class="fas fa-search"></i>
            </a>
        </div>
        <?php } else { ?>
        <div <?php echo wp_kses_post( $this->get_render_attribute_string( 'container' ) ); ?>>
            <?php if ( 'text_title' === $settings['layout'] ) { ?>
                <input <?php echo $this->get_render_attribute_string( 'input' ); ?>>
                    <button id="clear-with-button" type="reset">
                    <i class="fas fa-times"></i>
                    </button>
                    <button class="ennova-search-submit title_btn" type="submit">
                    <?php echo $button_text_title = $settings['button_text_title'];?>
                </button>
            <?php } else { ?>
                <input <?php echo $this->get_render_attribute_string( 'input' ); ?>>
                <button id="clear-with-button" type="reset">
                    <i class="fas fa-times"></i>
                </button>
                <button class="ennova-search-submit" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            <?php } ?>
        </div>
    <?php } ?>
    </form>
    <?php
    }   
}