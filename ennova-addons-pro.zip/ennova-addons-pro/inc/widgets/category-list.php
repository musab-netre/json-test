<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

class ENNOVACategoryList extends \Elementor\Widget_Base {
	
	private $category_list_class = 'ennova-category-list-card';
	private $category_item = 'ennova-category-list-item';
	private $item_count = 'ennova-category-list-count';
	private $item_title = 'ennova-category-list-title';

	public function get_name() {
		return 'ennova-category-list';
	}

	public function get_title() {
		return __( 'Blog Post Category List', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-blog-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-bullet-list';
	}

	public function get_style_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_keywords() {
		return ['category list',
				'blog', 
				'post',
				'enn',
				'ennova addons',
		];
	}

	protected function register_controls() { 
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		create_select2(
			$this,
			[
				'key'         => 'post_category',
				'label'       => 'Add Categories',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_categories(),
				'multiple'    => true,
			]
		);


		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_count',
			[
				'label' => __( 'Show Count', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_responsive_control(
			'category_item_height',
			[
				'label'           => __( 'Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				], 
				'selectors'       => [
					'{{WRAPPER}} .'.$this->category_item => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'category_item_bg_color',
			[
				'label'     => __( 'Overlay Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'description' =>  __( 'Color Opacity to Show Image', 'ennova-addons' ),
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.'::before' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

		// styles
		$this->start_controls_section(
			'category_item_style',
			[
				'label' => __( 'Category Item', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'category_item';
		
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_title_color',
			[
				'label'     => __( 'Title Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->item_title => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_title_typography',
				'label'    => 'Title Typography',
				'selector' => '{{WRAPPER}} .'.$this->item_title,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->category_item,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->category_item,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_title_hover_color',
			[
				'label'     => __( 'Title Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_title => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_title_hover_typography',
				'label'    => 'Title Typography',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_title,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hovor' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};', 
				],
			]
		);


		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover',
			]
		);


		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// count
		$this->start_controls_section(
			'count_style',
			[
				'label' => __( 'Category Count', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'category_item_count';

		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->item_count => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->item_count => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->item_count,
			]
		);

		$this->add_responsive_control(
			$slug.'_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->item_count => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->item_count,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->item_count => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->item_count => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->item_count,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);
		$this->add_control(
			$slug.'_hover_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_hover_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_hover_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'',
			]
		);
		$this->add_responsive_control(
			$slug.'_hover_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
 
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->category_item.':hover .'.$this->item_count.'',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$show_title = $settings['show_title']; 
		$show_count = $settings['show_count']; 
		
		$taxonomy     = $settings['post_category'];
		$includeCat = $settings['post_category'];
			?>
			<div class="enn-category-widget custom-cate-list">
   			 <ul class="list-unstyled">
     			<?php					
 					$taxonomy = 'category'; 
						if(!empty($includeCat)) {
							foreach($includeCat as $catID) { 
								$term = get_term( $catID, $taxonomy ); 
								$image_id = get_term_meta ( $catID, 'category-image-id', true );
								$image_url = wp_get_attachment_image_src ( $image_id, 'full' ) == '' ? ELEMENTOR_ASSETS_URL . 'images/placeholder.png' : wp_get_attachment_image_src ( $image_id, 'full' )[0];
								?>
								<li>
									<a class="<?php echo esc_attr($this->category_item)?>" href="<?php echo get_category_link($catID); ?>" style="background-image: url('<?php echo esc_url($image_url); ?>');">
										<?php if ( $settings['show_title'] === 'yes' ) { ?> 
										<span class="ennova-cat-title <?php echo esc_attr($this->item_title)?>"><?php echo esc_html($term->name); ?> </span> <?php } ?>
										<?php if ( $settings['show_count'] === 'yes' ) { ?> 
										<span class="badge <?php echo esc_attr($this->item_count)?>"><?php echo esc_html($term->count); ?></span> <?php } ?>
									</a>
								</li>
							<?php } ?>
						<?php } ?> 

    			</ul>
  			</div>
			<?php
		}
}