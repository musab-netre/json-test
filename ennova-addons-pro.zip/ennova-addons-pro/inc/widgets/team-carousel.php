<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

class ENNOVATeamCarousel extends \Elementor\Widget_Base {
	
	private $class_name = 'ENNOVATeamCarousel';

	private $team_card_class = 'ennova-team-carousel';
	private $team_card_inner_class = 'ennova-team-inner-carousel';
	private $team_card_image_class = 'ennova-team-carousel-image';
	private $team_card_top_content_class = 'ennova-team-top-content-carousel';
	private $team_card_bottom_content_class = 'ennova-team-bottom-content-carousel';
	private $team_card_heading_class = 'ennova-team-carousel-heading';
	private $team_card_icon_class = 'ennova-team-carousel-icon';
	private $team_card_designation_class = 'ennova-team-carousel-designation';

	public function get_name() {
		return 'ennova-team-carousel';
	}

	public function get_title() {
		return __( 'Team Carousel', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-slider-3d'; 
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'team item carousel',
			'team member carousel', 
			'team members carousel', 
			'team carousel',
			'team slider',
			'member carousel',
			'member slider',
			'our team',
			'person',
			'enn',
			'enn team',
			'ennova addons'
		];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 8', 'ennova-addons' ),
					'layout_9'      => esc_html__( 'Layout 9', 'ennova-addons' ),
					'layout_10'      => esc_html__( 'Layout 10', 'ennova-addons' ),
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		);

		$title = 'John Doe';
		$repeater->add_control(
			'card_title', [
				'label' => __( 'Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( $title , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$designation = 'Designer';
		$repeater->add_control(
			'card_designation',
			[
				'label' => __( 'Designation', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'rows' => 10,
				'default' => __( $designation, 'ennova-addons' ),
				'placeholder' => __( 'Type your designation here', 'ennova-addons' ),
			]
		);
		
		// Social Icon One
		$repeater->add_control(
			'social_icon_one', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fab fa-facebook-f', 'library' => 'brands',
				], 
			]
		);

		$repeater->add_control(
			'social_link_one',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 
		// Social Icon Two
		$repeater->add_control(
			'social_icon_two', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fab fa-telegram-plane', 'library' => 'brands',
				], 
			]
		);

		$repeater->add_control(
			'social_link_two',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 
		// Social Icon Three
		$repeater->add_control(
			'social_icon_three', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fab fa-instagram', 'library' => 'brands',
				], 
			]
		);

		$repeater->add_control(
			'social_link_three',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 
		// Social Icon Four
		$repeater->add_control(
			'social_icon_four', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fab fa-twitter', 'library' => 'brands',
				], 
			]
		);

		$repeater->add_control(
			'social_link_four',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 

		// Social Icon Five
		$repeater->add_control(
			'social_icon_five', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS, 
			]
		);

		$repeater->add_control(
			'social_link_five',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 
		// Social Icon Six
		$repeater->add_control(
			'social_icon_six', 
			[
				'label' => __('Social Icon', 'ennova-addons') , 
				'type' => Controls_Manager::ICONS,  
			]
		);

		$repeater->add_control(
			'social_link_six',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		); 
		$this->add_control(
			'card',
			[
				'label' => __( 'Team Items', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'card_title' => __($title, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
					],
					[
						'card_title' => __($title, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
					],
					[
						'card_title' => __($title, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
					],
					[
						'card_title' => __($title, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
					],
					[
						'card_title' => __($title, 'ennova-addons'),
						'card_designation' => __($designation, 'ennova-addons'),
					],
				],
				'title_field' => '{{{ card_title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_image',
			[
				'label' => __( 'Show Image', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_designation',
			[
				'label' => __( 'Show Designation', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_icon',
			[
				'label' => __( 'Show Social Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider',
			[
				'label' => __( 'Slider Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slide_to_show',
				'label'       => 'Slides to Show',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_to_scroll',
				'label'       => 'Slides to Scroll',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'slides_space_between',
				'label'       => 'Slides Space Between',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 10,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_navigation_arrow',
				'label'     => 'Show Navigation Arrow',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'dot_clickable',
				'label'     => 'Dot Clickable',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'autoplay',
				'label'     => 'AutoPlay',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'autoplay_speed',
				'label'       => 'AutoPlay Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3000,
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		create_number(
			$this,
			[
				'key'         => 'transition_between_slides',
				'label'       => 'Slide Switch Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1000,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'loop',
				'label'     => 'Loop',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'mousewheel',
				'label'     => 'Mouse on Wheel',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'keyboard_control',
				'label'     => 'Keyboard Control',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'display_dots',
				'label'     => 'Show Dots',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'show_scroll_bar',
				'label'     => 'Show Scroll Bar',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);


		$this->end_controls_section();

		$this->card_styles();

		//  Navigation styles
			create_navigation_style( $this, [] );
		//  Navigation styles ends
	}

	function card_styles() {
		
		// STYLE
		$this->start_controls_section(
			'box_settings',
			[
				'label' => __( 'Box Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'box_tabs' );

		$this->start_controls_tab(
			'box_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			'box_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class => 'background-color: {{VALUE}}', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'box_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'box_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'box_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'box_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'box_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'box_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);
		$this->add_control(
			'box_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ 
					'{{WRAPPER}}  .'.$this->team_card_class.':hover  ' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'box_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover ',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'box_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'box_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'box_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'box_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_class.':hover', 
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'team_settings',
			[
				'label' => __( 'Team Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_separator',
			[
				'label'     => __( 'Separator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class.'::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_responsive_control(
			'card_separator_width',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_responsive_control(
			'card_separator_height',
			[
				'label'           => __( 'Separator Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class.'::before' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class.'::after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style!' => ['layout_1']
				]
			]
		);

		$this->add_control(
			'card_bg_before_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style' => ['layout_1']
				]
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_bottom_content_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_bottom_content_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_separator_hover',
			[
				'label'     => __( 'Separator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class.'::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_responsive_control(
			'card_separator_width_hover',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_responsive_control(
			'card_separator_height_hover',
			[
				'label'           => __( 'Separator Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class.'::before' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_4']
				]
			]
		);

		$this->add_control(
			'card_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class.'::after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style!' => ['layout_1']
				]
			]
		);

		$this->add_control(
			'card_bg_before_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_bottom_content_class.'::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style' => ['layout_1']
				]
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_class.':hover .'.$this->team_card_bottom_content_class,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'image_settings',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'card_image_tabs' );

		$this->start_controls_tab(
			'card_heading_image_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'bg_opacity_color',
				'label'     => __( 'Background Overlay', 'ennova-addons' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->team_card_top_content_class.' .top_img::before',
				'condition' => [
					'template_style!' => ['layout_2', 'layout_4', 'layout_5', 'layout_6', 'layout_7', 'layout_9', 'layout_10']
				],
			]
		);

		$this->add_responsive_control(
			'bg_overlay_opacity',
			[
				'label' => esc_html__( 'Opacity', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.5,
				],
				'range' => [
					'px' => [
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_top_content_class.' .top_img::before' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'template_style!' => ['layout_2', 'layout_4', 'layout_5', 'layout_6', 'layout_7', 'layout_9', 'layout_10']
				],
			]
		);


		create_border_control(
			$this,
			[
				'name'     => 'image_border_type',
				'label'    => 'Border Type',
				'selector' => '
				{{WRAPPER}} .'.$this->team_card_image_class.' img, 
				{{WRAPPER}} .team_seven .'.$this->team_card_image_class.':after',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_image_class.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_top_content_class.' .top_img::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_top_content_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_class.' .'.$this->team_card_image_class.' img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_image_class.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_top_content_class.'::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_image_class.' img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_image_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'bg_opacity_color_hover',
				'label'     => __( 'Background Overlay', 'ennova-addons' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_top_content_class.' .top_img::before',
				'condition' => [
					'template_style' => ['layout_2', 'layout_5', 'layout_7', 'layout_8', 'layout_10']
				]
			]
		);

		$this->add_responsive_control(
			'bg_overlay_opacity_hover',
			[
				'label' => esc_html__( 'Opacity', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.5,
				],
				'range' => [
					'px' => [
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover .'.$this->team_card_top_content_class.' .top_img::before' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'template_style' => ['layout_2', 'layout_5', 'layout_7', 'layout_8', 'layout_10']
				]
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'image_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '
					{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img, 
					{{WRAPPER}} .team_seven:hover .'.$this->team_card_image_class.':after',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'image_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img'  =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_top_content_class.' .top_img::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_width_hover',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_top_content_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height_hover',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img'  => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_image_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_top_content_class.'::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'image_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_image_class.' img' ,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Icon Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_icon_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon' => 'justify-content: {{VALUE}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_1',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_8',
						],
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_10',
						]
					],
				],
			]
		);

        $this->start_controls_tabs( 'card_icon_tabs' );

		$this->start_controls_tab(
			'card_heading_icon_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			'card_heading_icon_bg_color',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_width',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '' ,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '' ,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_icon_class. ' .social-icon a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_icon_class . ' .social-icon a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_icon_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_icon_bg_color_hover',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .team_nine:hover .'.$this->team_card_icon_class.' .social-icon a' => 'background-color: {{VALUE}}',
				], 
			]
		);

		$this->add_control(
			'card_heading_icon_color_hover',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a:hover svg' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .team_nine:hover .'.$this->team_card_icon_class.' .social-icon a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .team_nine:hover .'.$this->team_card_icon_class.' .social-icon a svg' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_width_hover',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a:hover' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size_hover',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a:hover i' =>  'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a:hover svg' =>  'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a:hover' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_icon_class.' .social-icon a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->team_card_icon_class.' .social-icon a:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'team_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->start_controls_tabs( 'card_heading_tabs' );

		$this->start_controls_tab(
			'card_heading_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_heading_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_heading_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_heading_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_title_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);


		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover h3 ' => 'color: {{VALUE}}',
				], 
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}   .'.$this->team_card_class.':hover h3',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_class.':hover h3',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover h3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_class.':hover h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}   .'.$this->team_card_class.':hover h3',
			]
		);

		$this->end_controls_tab();  
		$this->end_controls_tabs(); 
		$this->end_controls_section();


		$this->start_controls_section(
			'team_designation',
			[
				'label' => __( 'Designation', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_designation_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_designation_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_designation_tabs' );

		$this->start_controls_tab(
			'card_heading_designation_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_designation_color',
			[
				'label'     => __( 'Designation Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->team_card_designation_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_designation_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_designation_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_designation_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_designation_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_designation_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_designation_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_designation_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_designation_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_designation_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_designation_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_designation_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->team_card_designation_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_designation_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_designation_color_hover',
			[
				'label'     => __( 'Designation Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_designation_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_designation_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_designation_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_designation_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_designation_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_designation_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}} .'.$this->team_card_class.':hover .'.$this->team_card_designation_class.'',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();  
		$this->end_controls_section(); 
	}

	protected function render() {
		$settings = $this->get_settings_for_display(); 

		$template_style = $settings['template_style'];

		$show_image = $settings['show_image'];
		$show_icon = $settings['show_icon'];
		$show_title = $settings['show_title'];
		$show_designation = $settings['show_designation'];

		$swiper_container_class = 'swiper swiper-container swiper-' . $this->get_id();

		$template_path = ENNOVA_PATH . 'inc/templates/team/';

		$element_id                  = 'ennova_slider_' . $this->get_id();
		$slide_to_show               = isset( $settings['slide_to_show'] ) && $settings['slide_to_show'] ? $settings['slide_to_show'] : 3;
		$slide_to_show_tablet        = isset( $settings['slide_to_show_tablet'] ) && $settings['slide_to_show_tablet'] ? $settings['slide_to_show_tablet'] : 2;
		$slide_to_show_mobile        = isset( $settings['slide_to_show_mobile'] ) && $settings['slide_to_show_mobile'] ? $settings['slide_to_show_mobile'] : 1;
		$slides_to_scroll            = isset( $settings['slides_to_scroll'] ) && $settings['slides_to_scroll'] ? $settings['slides_to_scroll'] : 3;
		$slides_to_scroll_mobile     = isset( $settings['slides_to_scroll_mobile'] ) && $settings['slides_to_scroll_mobile'] ? $settings['slides_to_scroll_mobile'] : 2;
		$slides_to_scroll_tablet     = isset( $settings['slides_to_scroll_tablet'] ) && $settings['slides_to_scroll_tablet'] ? $settings['slides_to_scroll_tablet'] : 1;
		$slides_space_between        = isset( $settings['slides_space_between'] ) && $settings['slides_space_between'] ? $settings['slides_space_between'] : 10;
		$slides_space_between_mobile = isset( $settings['slides_space_between_mobile'] ) && $settings['slides_space_between_mobile'] ? $settings['slides_space_between_mobile'] : 2;
		$slides_space_between_tablet = isset( $settings['slides_space_between_tablet'] ) && $settings['slides_space_between_tablet'] ? $settings['slides_space_between_tablet'] : 5;
		$display_title_absolute = isset( $settings['display_title_absolute'] ) && $settings['display_title_absolute'] ? $settings['display_title_absolute'] : 'no';
		$dot_clickable               = isset( $settings['dot_clickable'] ) ? $settings['dot_clickable'] : true;
		$title = '';
		if ( isset( $settings['title'] ) && ! empty( $settings['title'] ) ) {
			$title = $settings['title'];
		}

		$autoplay       = false;
		$autoplay_speed = 2000;

		if ( array_key_exists( 'autoplay', $settings ) && $settings['autoplay'] === 'yes' ) {
			$autoplay = true;
			if ( array_key_exists( 'autoplay_speed', $settings ) ) {
				$autoplay_speed = $settings['autoplay_speed'];
			}
		}

		$transition_between_slides = 1000;
		$loop                      = false;
		$mousewheel                = false;
		$keyboard_control          = false;

		if ( isset( $settings['transition_between_slides'] ) && ! empty( $settings['transition_between_slides'] ) ) {
			$transition_between_slides = $settings['transition_between_slides'];
		}

		if ( isset( $settings['loop'] ) && ! empty( $settings['loop'] ) && $settings['loop'] === 'yes' ) {
			$loop = true;
		}
		if ( isset( $settings['mousewheel'] ) && ! empty( $settings['mousewheel'] ) && $settings['mousewheel'] === 'yes' ) {
			$mousewheel = true;
		}
		if ( isset( $settings['keyboard_control'] ) && ! empty( $settings['keyboard_control'] ) && $settings['keyboard_control'] === 'yes' ) {
			$keyboard_control = true;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'ennova-outer-wrapper' );
		$this->add_render_attribute( 'wrapper', 'data-wid', $this->get_id() );
		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . '>';
		echo '<div
        		class="ennova_slider_wrapper "
        		id="' . esc_attr( $element_id ) . '"
        		data-slide-to-show="' . esc_html( $slide_to_show ) . '"
				data-slide-to-show-mobile="' . esc_html( $slide_to_show_mobile ) . '"
				data-slide-to-show-tablet="' . esc_html( $slide_to_show_tablet ) . '"
        		data-slides-to-scroll="' . esc_html( $slides_to_scroll ) . '"
				data-slides-to-scroll-mobile="' . esc_html( $slides_to_scroll_mobile ) . '"
				data-slides-to-scroll-tablet="' . esc_html( $slides_to_scroll_tablet ) . '"
        		data-slides-space-between="' . esc_html( $slides_space_between ) . '"
				data-slides-space-between-mobile="' . esc_html( $slides_space_between_mobile ) . '"
				data-slides-space-between-tablet="' . esc_html( $slides_space_between_tablet ) . '"
				data-autoplay="' . esc_html( $autoplay ) . '"
				data-autoplay-speed="' . esc_html( $autoplay_speed ) . '"
				data-transition_between_slides="' . esc_html( $transition_between_slides ) . '"
				data-loop="' . esc_html( $loop ) . '"
				data-mousewheel="' . esc_html( $mousewheel ) . '"
				data-keyboard_control="' . esc_html( $keyboard_control ) . '"
				data-clickable="' . esc_html( $dot_clickable ) . '"
        	>';

				?>
		<!-- Slider main container -->
		<div class="<?php echo esc_html( $swiper_container_class ); ?>">
			<!-- Additional required wrapper -->
			<div class="swiper-wrapper">
				<?php foreach($settings['card'] as $card) {
					$title = $card['card_title'];
					//$subtitle = $card['card_subtitle'];
					$designation = $card['card_designation'];
					//$link_text = $card['card_link_text'];
					$image_url = $card['card_image']['url'];
					
					// Social Icon One
					$icon_one = $card['social_icon_one'];
					$link_one = $card['social_link_one']['url'];
					$target_one = $card['social_link_one']['is_external'] ? ' target="_blank"' : '';
					$nofollow_one = $card['social_link_one']['nofollow'] ? ' rel="nofollow"' : ''; 

					// Social Icon Two
					$icon_two = $card['social_icon_two'];
					$link_two = $card['social_link_two']['url'];
					$target_two = $card['social_link_two']['is_external'] ? ' target="_blank"' : '';
					$nofollow_two = $card['social_link_two']['nofollow'] ? ' rel="nofollow"' : ''; 
										
					// Social Icon Three
					$icon_three = $card['social_icon_three'];
					$link_three = $card['social_link_three']['url'];
					$target_three = $card['social_link_three']['is_external'] ? ' target="_blank"' : '';
					$nofollow_three = $card['social_link_three']['nofollow'] ? ' rel="nofollow"' : ''; 
										
					// Social Icon Four
					$icon_four = $card['social_icon_four'];
					$link_four = $card['social_link_four']['url'];
					$target_four = $card['social_link_four']['is_external'] ? ' target="_blank"' : '';
					$nofollow_four = $card['social_link_four']['nofollow'] ? ' rel="nofollow"' : ''; 
										
					// Social Icon Five
					$icon_five = $card['social_icon_five'];
					$link_five = $card['social_link_five']['url'];
					$target_five = $card['social_link_five']['is_external'] ? ' target="_blank"' : '';
					$nofollow_five = $card['social_link_five']['nofollow'] ? ' rel="nofollow"' : ''; 
										
					// Social Icon Six
					$icon_six = $card['social_icon_six'];
					$link_six = $card['social_link_six']['url'];
					$target_six = $card['social_link_six']['is_external'] ? ' target="_blank"' : '';
					$nofollow_six = $card['social_link_six']['nofollow'] ? ' rel="nofollow"' : ''; 
					
					?>
				<div class="swiper-slide ennova-swiper-slide-service <?php echo 'ennova-tabs-'.$this->get_id() ?>">
				<?php switch ($template_style) {
					case 'layout_1':
					require $template_path. 'layout-1.php';
					break;
					case 'layout_2':
					require $template_path. 'layout-2.php';
					break;
					case 'layout_3':
					require $template_path. 'layout-3.php';
					break;
					case 'layout_4':
					require $template_path. 'layout-4.php';
					break;
					case 'layout_5':
					require $template_path. 'layout-5.php';
					break;
					case 'layout_6':
					require $template_path. 'layout-6.php';
					break;
					case 'layout_7':
					require $template_path. 'layout-7.php';
					break;
					case 'layout_8':
					require $template_path. 'layout-8.php';
					break;
					case 'layout_9':
					require $template_path. 'layout-9.php';
					break;
					case 'layout_10':
					require $template_path. 'layout-10.php';
					break;
					default:
					require $template_path. 'layout-1.php';
					break;
				} ?>
			</div> 
		<?php } ?>
	</div> 
	<!-- end swiper-wrapper -->
	<?php
					if (
						 $settings['display_dots'] === 'yes'
					 ) {
						?>
						<!-- If we need pagination -->
						<div class="swiper-pagination"></div>
						<?php
					}
					?>
					<?php
					if (
						 $settings['show_navigation_arrow'] === 'yes'
					 ) {
						?>
						<!-- If we need navigation buttons -->
						<div class="swiper-button-prev"></div>
						<div class="swiper-button-next"></div>
						<?php
					}
					?>
					<?php
					if (
						 $settings['show_scroll_bar'] === 'yes'
					 ) {
						?>
						<!-- If we need scrollbar -->
						<div class="swiper-scrollbar"></div>
						<?php
					}
					?>
	</div>
	<!-- end swiper-container -->
	<?php

			echo "</div>";
			echo "</div>";
	  }
}

