<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use ElementorPro\Modules\Posts\Widgets\Posts_Base;
use Elementor\Group_Control_Background;
use WP_Query;

class ENNOVAFeaturedBlog extends \Elementor\Widget_Base {

	private $blog_card_class = 'ennova-blog-feature-card';
	private $blog_inner = 'ennova-blog-feature-card-inner';
	private $blog_category = 'ennova-blog-feature-card-category';
	private $blog_img = 'ennova-blog-feature-card-image';
	private $blog_title = 'ennova-blog-feature-card-title';
	private $blog_desc = 'ennova-blog-feature-card-description';
	private $blog_meta = 'ennova-blog-feature-card-meta'; 
	
	private $small_blog_card_class = 'ennova-small-blog-feature-card';
	private $small_blog_inner = 'ennova-small-blog-feature-card-inner'; 
	private $small_blog_img = 'ennova-small-blog-feature-card-image';
	private $small_blog_title = 'ennova-small-blog-feature-card-title';
	private $small_blog_desc = 'ennova-small-blog-feature-card-description';
	private $small_blog_meta = 'ennova-small-blog-feature-card-meta'; 
	private $small_blog_date = 'ennova-small-blog-feature-card-meta-date'; 

	public function get_name() {
		return 'ennova-featured-post-blog';
	}

	public function get_title() {
		return __( 'Featured Blog Post', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-blog-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-posts-group';
	}

	public function get_style_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_keywords() {
		return [
				'featured post',
				'post blog',
				'news', 
				'blog', 
				'ennova eddons',
				'enn',
		];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'item_configuration',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'default',
				'options'     => [
					'default'      => esc_html__( 'Default', 'ennova-addons' ),
					'template_2' => esc_html__( 'Horizontal', 'ennova-addons' ),

				],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'post_author',
				'label'       => 'Authors',
				'placeholder' => 'Choose Author to Include',
				'options'     => ennova_get_all_authors(),
				'multiple'    => true,
			]
		);
		
		create_select2(
			$this,
			[
				'key'         => 'post_category',
				'label'       => 'Categories',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_categories(),
				'multiple'    => true,
			]
		);
	
		$this->add_control(
			'category_style',
			[
				'label'       => esc_html__( 'Categories Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'one',
				'options'     => [
					'one'      => esc_html__( 'Style 1', 'ennova-addons' ),
					'two'      => esc_html__( 'Style 2', 'ennova-addons' ),
					'three'      => esc_html__( 'Style 3', 'ennova-addons' ),
					'four'      => esc_html__( 'Style 4', 'ennova-addons' ), 
					'five'      => esc_html__( 'Style 5', 'ennova-addons' ), 
 
				],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'post_tags',
				'label'       => 'Tags',
				'placeholder' => 'Choose Tag to Include',
				'options'     => ennova_get_tags(),
				'multiple'    => true,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'number_of_posts',
				'label'       => 'Number of Posts',
				'placeholder' => 'Default is 3',
				'min'         => 1,
				'default'     => 3,
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'post_count_per_row',
				'label'       => 'Post Count Per Row',
				'placeholder' => 'Default is ',
				'min'         => 1,
				'default'     => '',
				'selectors'       => [
					'{{WRAPPER}} .enn-feature-small-blog' =>  'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				], 
				'condition' =>[
					'template_style' => 'template_2',
				],
			]
		);

		create_number_responsive_control(
			$this,
			[
				'key'         => 'title_length',
				'label'       => 'Title Length',
				'placeholder' => 'Default is 10',
				'min'         => 0,
				'default'     => 10,
				'description' => 'Enter 0 to hide Title',
			]
		);
		create_number_responsive_control(
			$this,
			[
				'key'         => 'excerpt_length',
				'label'       => 'Excerpt Length',
				'placeholder' => 'Default is 20',
				'min'         => 0,
				'default'     => 0,
				'description' => 'Enter 0 to hide Excerpt'
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'order_by',
				'label'       => 'Order By',
				'placeholder' => 'Order By',
				'options'     => [
					'none' => 'None',
					'ID' => 'ID',
					'author' => 'Author',
					'title' => 'Title',
					'name' => 'Name',
					'type' => 'Type',
					'date' => 'Date',
					'modified' => 'Modified',
					'parent' => 'Parent',
					'rand' => 'Random',
					'comment_count' => 'Comment_count',
				],
				'multiple'    => false,
			]
		);
		create_select2(
			$this,
			[
				'key'         => 'order',
				'label'       => 'Order',
				'placeholder' => 'Order',
				'options'     => [
					'ASC' => 'Ascending',
					'DESC' => 'Descending'
				],
				'multiple'    => false,
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'settings',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_image_size_control(
			$this,
			[
				'name'      => 'thumbnail_size',
				'default'   => 'large'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_date',
				'label'     => 'Show Date',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'show_author',
				'label'     => 'Show Author',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);
		create_switcher(
			$this,
			[
				'key'       => 'show_comments',
				'label'     => 'Show Comments',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		); 

		create_switcher(
			$this,
			[
				'key'       => 'show_category',
				'label'     => 'Show Category',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_title',
				'label'     => 'Show Title',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default' => 'yes'
			]
		);

		$this->end_controls_section();

		//STYLE		
		$this->start_controls_section(
			'image_style',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'blog_image';

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => $slug.'_opacity_six_color',
				'label'     => __( 'Background Overlay', 'ennova-addons' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
				'selector'  =>  
					'{{WRAPPER}} .six .'.$this->blog_inner.':after',
			]
		);

		$this->add_responsive_control(
			$slug.'_overlay_opacity',
			[
				'label' => esc_html__( 'Opacity', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'step' => 0.01,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .'.$this->blog_card_class.' .lg:after' => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .'.$this->blog_card_class.'.six .'.$this->blog_inner.':after' => 'opacity: {{SIZE}};',
				],
			]
		);
	
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.' ' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.' ' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_img.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding',
				'label'     => 'Inner Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_inner.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .six .'.$this->blog_category.'' => 'padding: 0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_img.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		
		$this->add_responsive_control(
			$slug.'_hover_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_hover_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_img.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding_hover',
				'label'     => 'Inner Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_inner.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .six .'.$this->blog_inner.':hover .'.$this->blog_category.'' => 'padding: 0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_img.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_img.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		
		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'title_html_tag',
				'label'       => 'Title HTML Tag',
				'placeholder' => 'Choose Tag to Include',
				'options'     => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
				],
				'default' => 'h4',
				'multiple'    => false,
			]
		);

		$slug = 'blog_title';

		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_title.' a' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title,
			]
		); 
		
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_title,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_card_class.':hover .'.$this->blog_title.' a' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title.':hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_title.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_title.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_title.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'metas_style',
			[
				'label' => __( 'Metas Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'metas';

		create_alignment(
			$this,
			[
				'key'       => $slug.'_align',
				'label'     => 'Alignment',
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta => 'justify-content: {{VALUE}}',
				],
			]
		);
		
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a i' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_meta.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_hover_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover i' => 'color: {{VALUE}};',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a:hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_meta.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_meta.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_meta.' a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		// Blog Category
		$this->start_controls_section(
			'blog_category_settings',
			[
				'label' => __( 'All Category Settings ', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,   
				
			]
		);

		$slug = 'blog_category';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_align',
				'label'     => 'Alignment',
				'options'   => [
					'start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a',
			]
		);


		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_category.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			$slug.'_color_bg_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->blog_category.' a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a:hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->blog_category.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->blog_category.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->blog_category.' a:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();


		// small blog post

        $this->start_controls_section(
			'small_blog_style',
			[
				'label' => __( 'Small Blog Post Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		); 
		
		$slug = 'small_blog_box';

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->small_blog_card_class => 'background-color: {{VALUE}}',
				], 
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding',
				'label'     => 'Inner Content Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_inner.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_bg_hover_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->small_blog_card_class.':hover' => 'background-color: {{VALUE}}',
				], 
			]
		);

		 
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding_hover',
				'label'     => 'Inner Content Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_inner.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_card_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();


		$this->start_controls_section(
			'small_image_style',
			[
				'label' => __( 'Small Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'small_blog_image';
	
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->small_blog_img.' ' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->small_blog_img.' ' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_img.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_img.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_img.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_img.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		
		$this->add_responsive_control(
			$slug.'_hover_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->small_blog_img.':hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_hover_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->small_blog_img.':hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_img.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_img.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_img.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_img.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'small_title_style',
			[
				'label' => __( 'Small Title Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'title_small_html_tag',
				'label'       => 'Title HTML Tag',
				'placeholder' => 'Choose Tag to Include',
				'options'     => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
				],
				'default' => 'h4',
				'multiple'    => false,
			]
		);

		$slug = 'small_blog_title';

		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->small_blog_title.' a' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_title,
			]
		); 
		
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_title,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_title,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_card_class.':hover .'.$this->small_blog_title.' a' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_title.':hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_title.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_title.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_title.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'small_metas_style',
			[
				'label' => __( 'Small Metas Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'small_metas';

		create_alignment(
			$this,
			[
				'key'       => $slug.'_align',
				'label'     => 'Alignment',
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta => 'justify-content: {{VALUE}}',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a i' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_meta.' a',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_meta.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_meta.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_icon_hover_color',
				'label'     => 'Icon Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a:hover i' => 'color: {{VALUE}};',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_meta.' a:hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_meta.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_meta.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_meta.' a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'small_metas_date_style',
			[
				'label' => __( 'Small Metas Date Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'small_metas_date'; 
		 
		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.' a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .'.$this->small_blog_date.' a span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->small_blog_date.'' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_day_typography',
				'label'    => 'Day Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.' a',
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_mounth_typography',
				'label'    => 'Month Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.' a span',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_date.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.' a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .'.$this->small_blog_date.' a:hover span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_hover_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->small_blog_date.':hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_day_hover_typography',
				'label'    => 'Day Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.':hover a',
			]
		);
		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_mounth_hover_typography',
				'label'    => 'Month Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.':hover a span',
			]
		);
 
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_date.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_date.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_date.':hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'small_excerpt_style',
			[
				'label' => __( 'Small Excerpt Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'excerpt_length!' => 0,
				]
			]
		);

		$slug = 'small_excerpt';

		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_style_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.'' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_desc.'',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_desc,
			]
		);
		
		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_desc,
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.':hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_desc.':hover',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->small_blog_desc.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->small_blog_desc.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_text_shadow_control(
			$this,
			[
				'key'      => $slug.'_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->small_blog_desc.':hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

	} 


	protected function render() {
		$settings = $this->get_settings_for_display();

		$template_style = $settings['template_style'];
		$category_style = $settings['category_style'];

		$show_author = $settings['show_author'];
		$show_date = $settings['show_date'];
		$show_comments = $settings['show_comments'];
		$show_category = $settings['show_category'];
		$show_title = $settings['show_title'];

		$title_html_tag = $settings['title_html_tag'];
		$excerpt_length = $settings['excerpt_length'];
		$title_length = $settings['title_length'];
		$post_count_per_row = $settings['post_count_per_row'];
		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1; 
	
		$args = array(
			'posts_per_page' => 5,
			'orderby' => 'ID',
			'order' => 'DESC',
			'post_type' => 'post',
			'post_status' => 'publish',
			'paged' => $paged
		);

		if ( isset( $settings['post_category'] ) && is_array( $settings['post_category'] ) && ! empty( $settings['post_category'] ) ) {
			$args['cat'] = implode(',',  $settings['post_category']);
		}

		if ( isset( $settings['post_author'] ) && is_array( $settings['post_author'] ) && ! empty( $settings['post_author'] ) ) {
			$args['author'] = implode(',',  $settings['post_author']);
		}

		if ( isset( $settings['post_tags'] ) && is_array( $settings['post_tags'] ) && ! empty( $settings['post_tags'] ) ) {
			$args['tag'] = implode(',', $settings['post_tags'] );
		}

		if ( isset( $settings['order_by'] ) && ! empty( $settings['order_by'] ) ) {
			$args['orderby'] = $settings['order_by'];
		}

		if ( isset( $settings['order'] ) && ! empty( $settings['order'] ) ) {
			$args['order'] = $settings['order'];
		}

		if ( isset( $settings['number_of_posts'] ) && ! empty( $settings['number_of_posts'] ) ) {
			$args['posts_per_page'] = $settings['number_of_posts'];
		}

		$wp_query = new WP_Query( $args );

		?>
	<div class="enn-featured-grid <?php if ( $template_style === 'template_2' ) { ?>horizontal<?php } else { ?>2 <?php } ?>" >
			<?php
				if ( $wp_query->have_posts() ) :
				$i=1;

				while ( $wp_query->have_posts() ) : $wp_query->the_post();
					$thumbnail_id = get_post_thumbnail_id();
					$thumbnail_size_key = 'thumbnail_size';
					$comments_count = get_comments_number();
					$categories_names = [];
					$categories = get_the_category();

				if ( count($categories) > 0 ) {
					foreach($categories as $category ) {
						$category = (array) $category;
						$categories_names[] = $category['name'];
					}
				}
				$params = [ 
					'settings' => $settings,
					'excerpt_length' => $excerpt_length,
					'title_length' => $title_length,
					'thumbnail_id' => $thumbnail_id,
					'thumbnail_size_key' => $thumbnail_size_key,
					'categories' => $categories,
					'comments_count' => $comments_count,
				];
					
			if($i == 1){  ?>						
		<div class="enn-blog-post enn-feature-blog enn-overlay six <?php echo esc_attr($this->blog_card_class) ;?>" id="<?php echo get_the_ID(); ?>">
				<?php
					$image_src = '';
					if ($thumbnail_id) {
						$image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src($thumbnail_id, $thumbnail_size_key, $params['settings']);
					}
					if ( $image_src === '' ) {
						?>
							<div class="enn-blog-post three lg enn-back-img bshre <?php echo esc_attr($this->blog_img) ;?>">
						<?php
					} else {
						$bg = "background-image: url(". esc_url($image_src) .");";
						?>
							<div class="enn-blog-post three lg enn-back-img bshre <?php echo esc_attr($this->blog_img) ;?>" style=" <?php echo $bg ?> ">
						<?php
					}
				?>
				<a href="<?php echo esc_url(get_permalink()); ?>" class="enn-link-div"></a>
				<article class="inner <?php echo esc_attr($this->blog_inner) ;?>">
					<div class="enn-blog-category <?php echo esc_attr($category_style);?> <?php echo esc_attr($this->blog_category) ;?>">
							<?php
								if ( count($params['categories']) > 0 && $show_category === 'yes') {
									foreach($params['categories'] as $category ) {
										$category = (array) $category;
										?>
											<a href="<?php echo  get_category_link( $category['term_id'] ) ?>"><?php echo esc_html($category['name']) ?></a>
										<?php
									}
								}
								?>
					</div>
					<?php
						if ( $show_title === 'yes' ) {
							// title_html_tag
							echo '<'.$title_html_tag.' class="title '.esc_attr($this->blog_title).'">';
							if ( $params['title_length'] > 0 ) {
								?>
									<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title(), $params['title_length'], '' ); ?></a>
								<?php
							}
							echo '</'.$title_html_tag.'>';
						}
					?>
					<div class="enn-blog-meta <?php echo esc_attr($this->blog_meta) ;?>">
						<?php
							if( $show_author === 'yes' ) {
								?>
									<span class="enn-author">
										<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' ));?>"><?php echo get_avatar(get_the_author_meta( 'ID') , 150); ?><?php the_author(); ?></a>
									</span>
								<?php
							}
						?>
						<?php
							if( $show_date === 'yes' ) {
								?>
									<span class="enn-blog-date">
										<a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j'));  ?>" class="entry-date"><i class="far fa-clock"></i>
											<?php
												the_time('F j, Y');
											?>
										</a>
									</span>
								<?php
							}
						?>
						<?php
							if ( $params['comments_count'] > 0 && $show_comments === 'yes') {
									$text = 'Comment';
									if ( $params['comments_count'] > 1 ) {
										$text = 'Comments';
									}
								?>
									<span class="enn-comments-link"> <a href="<?php comments_link(); ?>"><i class="far fa-comments"></i><?php echo get_comments_number(). ' ' ?></a> </span>
								<?php
							}
						?>
					</div>
				</article>
				</div>
		</div>
		<div class="enn-feature-small-blog">
				<?php } else { ?>
				<!-- blog post -->
				<div class="enn-small-post bshre one <?php echo esc_attr($this->small_blog_card_class) ;?>" id="<?php echo esc_attr($i); ?>">
			<?php 
				$image_src = '';
				if ($thumbnail_id) {
					$image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src($thumbnail_id, $thumbnail_size_key, $params['settings']);
				}
				if ( $image_src === '' ) {
					?>
						<div class="enn-img-small-post enn-back-img hlgr <?php echo esc_attr($this->small_blog_img) ;?>">
					<?php
				} else {
					$bg = "background-image: url(". esc_url($image_src) .");";
					?>
						<div class="enn-img-small-post enn-back-img hlgr <?php echo esc_attr($this->small_blog_img) ;?>" style=" <?php echo $bg ?> ">
					<?php
				}
			?> 
			<?php
				if( $show_date === 'yes' ) {
					?>
						<span class="enn-blog-date <?php echo esc_attr($this->small_blog_date) ;?>">
							<a href="<?php echo get_day_link(get_post_time(''), get_post_time('m'), get_post_time('j'));  ?>" class="entry-date">
								<?php
									the_time('j');
									echo '<span>'; the_time('F');echo'</span>'; 
								?>
							</a>
						</span>
					<?php
				}
			?>
			<a href="<?php echo esc_url(get_permalink()); ?>" class="enn-link-div"></a>
			</div>
			<article class="enn-small-post-content <?php echo esc_attr($this->small_blog_inner) ;?>">
			<div class="enn-blog-category <?php echo esc_attr($category_style);?> <?php echo esc_attr($this->blog_category) ;?>">
				<?php
					if ( count($params['categories']) > 0 && $show_category === 'yes') {
						foreach($params['categories'] as $category ) {
							$category = (array) $category;
							?>
								<a href="<?php echo  get_category_link( $category['term_id'] ) ?>"><?php echo esc_html($category['name']) ?></a>
							<?php
						}
					}
					?>
			</div>
			<?php
					if ( $show_title === 'yes' ) {
						// title_html_tag
						echo '<'.$title_html_tag.' class="title '.esc_attr($this->small_blog_title).'">';
						if ( $params['title_length'] > 0 ) {
							?>
								<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title(), $params['title_length'], '' ); ?></a>
							<?php
						}
						echo '</'.$title_html_tag.'>';
					}
				?>

				<div class="enn-blog-meta <?php echo esc_attr($this->small_blog_meta) ;?>">
					<?php
						if( $show_author === 'yes' ) {
							?>
								<span class="enn-author">
									<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_avatar(get_the_author_meta( 'ID') , 150); ?><?php the_author(); ?></a>
								</span>
							<?php
						}
					?>
					<?php
						if ( $params['comments_count'] > 0 && $show_comments === 'yes') {
								$text = 'Comment';
								if ( $params['comments_count'] > 1 ) {
									$text = 'Comments';
								}
							?>
								<span class="enn-comments-link"> <a href="<?php comments_link(); ?>"><i class="far fa-comments"></i><?php echo get_comments_number(). ' ' ?></a> </span>
							<?php
						}
					?>
				</div>

				<?php
					if ( $params['excerpt_length'] > 0 ) {
						?>
							<div class="discription <?php echo esc_attr($this->small_blog_desc) ;?>">
						<?php
						echo wp_trim_words( get_the_content(), $params['excerpt_length'], '' );
						?>
							</div>
						<?php
					}
				?>
			</article>
		</div>
			  <!-- /blog post -->
				<?php }
						$i++;
					endwhile;
					?>
	</div>
			<?php
			endif;
		?>
		<?php
			wp_reset_postdata();
		?>
		<?php
	}
}