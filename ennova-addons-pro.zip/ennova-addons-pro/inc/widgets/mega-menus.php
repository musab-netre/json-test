<?php

namespace EnnovaAddons; 

use Elementor\Controls_Stack;
use Elementor\Core\Schemes\Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Base;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow; 
use Elementor\Scheme_Color;
use Elementor\Utils;
use Elementor\Repeater;

    class ENNOVAMegaMenu extends Widget_Base {

        protected $nav_menu_index = 1;

        public function __construct( $data = array(), $args = null ) {
            parent::__construct( $data, $args );
            }
    
        public function get_name() {
            return 'ennova-mega-menu';
        }
    
        public function get_title() {
            return __( 'Mega Menus', 'ennova-addons' );
        }
    
        public function get_icon() {
            return 'enn-icon eicon-mega-menu';
        }
    
        public function get_categories() {
            return array( 'wc-hf-element' );
        }
    
        public function get_style_depends() {
            return [
                'ennova-styles-css',
                'sm-clean-css',
                'sm-core-css',
            ];
    
        }

        public function get_script_depends() {
            return [
                'jquery-smartmenus-js',
                'ennova-custom-js',
            ];
    
        }

        public function get_keywords() {
            return ['mega menus',
                    'menus', 
                    'ennova addons',
                    'enn',
            ];
        }
        
        protected function get_nav_menu_index() {
            return $this->nav_menu_index++;
        }
    
        private function get_available_menus() {
            $menus = wp_get_nav_menus();
    
            $options = array();
    
            foreach ( $menus as $menu ) {
                $options[ $menu->slug ] = $menu->name;
            }
    
            return $options;
        }
    
        protected function register_controls() {
    
            $this->start_controls_section(
                'section_menu',
                array(
                    'label' => __( 'Menu', 'ennova-addons' ),
                )
            );
    
            $menus = $this->get_available_menus();
    
            if ( ! empty( $menus ) ) {
                $this->add_control(
                    'menu',
                    array(
                        'label'       => __( 'Menu', 'ennova-addons' ),
                        'type'        => Controls_Manager::SELECT,
                        'options'     => $menus,
                        'default'     => array_keys( $menus )[0],
                        'description' => sprintf( __( 'To manage nav menus, navigate to <a href="%s" target="_blank">Menus admin</a>.', 'ennova-addons' ), admin_url( 'nav-menus.php' ) ),
                    )
                );
            } else {
                $this->add_control(
                    'menu',
                    array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => sprintf( __( '<strong>It seems no menus are created.</strong><br>Navigate to <a href="%s" target="_blank">Menus admin</a> and create one.', 'ennova-addons' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
                        'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                    )
                );
            }

            $this->add_control(
                'menu_type',
                array(
                    'label'       => __( 'Type', 'ennova-addons' ),
                    'type'        => Controls_Manager::SELECT,
                    'options'   => array(
                        'horizontal'    => 'Horizontal',
                        'vertical'    => 'Vertical',
                    ),
                    'default'     => 'horizontal',
                    'separator'   => 'after',)
            );

            $this->add_control(
                'menu_is_sticky',
                array(
                    'label'              => __( 'Sticky Menu', 'ennova-addons' ),
                    'type'               => Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Show', 'ennova-addons' ),
                    'label_off'    => __( 'Hide', 'ennova-addons' ),
                    'return_value' => 'yes',
                    'default'      => 'no', 
                    'condition'    => array(
                        'menu_type' => 'horizontal',
                    ),
                )
            );

            $this->end_controls_section();

            $this->start_controls_section(
                'section_layout',
                array(
                    'label' => __( 'Layout', 'ennova-addons' ),
                )
            );
    
            $this->add_control(
                'align_items',
                [
                    'label' => esc_html__( 'Menu Alignment', 'ennova-addons' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'default' => 'center', 
                    'options' => [
                        'flex-star' => [
                            'title' => esc_html__( 'Left', 'ennova-addons' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'ennova-addons' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'flex-end' => [
                            'title' => esc_html__( 'Right', 'ennova-addons' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav .ennova-collapse ' => 'justify-content:{{VALUE}};',
                    ],
                    'render_type' => 'template',
                ]
		    );
    
            $this->add_control(
                'animation_framed',
                array(
                    'label'     => __( 'Animation', 'ennova-addons' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'fade',
                    'options'   => array(
                        'fade'    => 'Fade',
                        'grow'    => 'Grow',
                        'shrink'  => 'Shrink',
                        'draw'    => 'Draw',
                        'corners' => 'Corners',
                    ),
                    'condition' => array(
                        'layout!' => 'dropdown',
                        'pointer' => 'framed',
                    ),
                )
            );
    
            $this->add_control(
                'animation_background',
                array(
                    'label'     => __( 'Animation', 'ennova-addons' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'fade',
                    'options'   => array(
                        'fade'                   => 'Fade',
                        'grow'                   => 'Grow',
                        'shrink'                 => 'Shrink',
                        'sweep-left'             => 'Sweep Left',
                        'sweep-right'            => 'Sweep Right',
                        'sweep-up'               => 'Sweep Up',
                        'sweep-down'             => 'Sweep Down',
                        'shutter-in-vertical'    => 'Shutter In Vertical',
                        'shutter-out-vertical'   => 'Shutter Out Vertical',
                        'shutter-in-horizontal'  => 'Shutter In Horizontal',
                        'shutter-out-horizontal' => 'Shutter Out Horizontal',
                    ),
                    'condition' => array(
                        'layout!' => 'dropdown',
                        'pointer' => 'background',
                    ),
                )
            );
    
            $this->add_control(
                'animation_text',
                array(
                    'label'     => __( 'Animation', 'ennova-addons' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'grow',
                    'options'   => array(
                        'grow'   => 'Grow',
                        'shrink' => 'Shrink',
                        'sink'   => 'Sink',
                        'float'  => 'Float',
                        'skew'   => 'Skew',
                        'rotate' => 'Rotate',
                    ),
                    'condition' => array(
                        'layout!' => 'dropdown',
                        'pointer' => 'text',
                    ),
                )
            );
    
            $this->add_control(
                'indicator_icon',
                [
                    'label'       => esc_html__( 'Submenu Indicator', 'ennova-addons' ),
                    'type'        => \Elementor\Controls_Manager::SELECT,
                    'default'     => '\f0d7',
                    'options'     => [
                    ''                          => esc_html__( 'None', 'ennova-addons' ),
                    '\f0d7'                     => esc_html__( 'Classic ', 'ennova-addons' ),
                    '\f107'                      => esc_html__( 'Angle ', 'ennova-addons' ),
                    '\f103'                      => esc_html__( 'Double Angle ', 'ennova-addons' ),
                    '\f078'                      => esc_html__( 'Chevron ', 'ennova-addons' ),
                    '\f067'                      => esc_html__( 'Plus ', 'ennova-addons' ),
                    ],
                    'selectors' =>[
                        '{{WRAPPER}} .sub-arrow-icon.fa-caret-down:before'=> 'content:"{{VALUE}}";' ],
                ]
            );
            $this->add_control(
                'heading_mobile_dropdown',
                array(
                    'label'     => __( 'Mobile Dropdown', 'ennova-addons' ),
                    'type'      => Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => array(
                        'layout!' => 'dropdown',
                    ),
                )
            );
    
            $this->add_control(
                'dropdown',
                array(
                    'label'        => __( 'Breakpoint', 'ennova-addons' ),
                    'type'         => Controls_Manager::SELECT,
                    'default'      => 'tablet',
                    'options'      => array(
                        'mobile' => __( 'Mobile (767px >)', 'ennova-addons' ),
                        'tablet' => __( 'Tablet (1023px >)', 'ennova-addons' ),
                    ),
                    'prefix_class' => 'elementor-nav-menu--dropdown-',
                    'condition'    => array(
                        'layout!' => 'dropdown',
                    ),
                )
            );
    
            $this->add_control(
                'full_width',
                array(
                    'label'              => __( 'Full Width', 'ennova-addons' ),
                    'type'               => Controls_Manager::SWITCHER,
                    'description'        => __( 'Stretch the dropdown of the menu to full width.', 'ennova-addons' ),
                    'prefix_class'       => 'ennova-mobile-menu-full-width ',
                    'render_type' => 'template',
                    // 'return_value'       => 'stretch',
                    // 'frontend_available' => true,
                )
            );
            
            $this->add_control(
				'heading_responsive',
				[
					'type'      => Controls_Manager::HEADING,
					'label'     => __( 'Responsive', 'ennova-addons' ),
					'separator' => 'before',
				]
			);

            $this->add_control(
                'toggle_responsive',
                [
                    'label'        => __( 'Breakpoint', 'ennova-addons' ),
                    'type'         => Controls_Manager::SELECT,
                    'default'      => 'tablet',
                    'options'      => [
                        'tablet' => __( 'Tablet (991px >)', 'ennova-addons' ),
                        'none'   => __( 'None', 'ennova-addons' ),
                    ],
                ]
            );
    
            $this->add_control(
                'toggle_align',
                array(
                    'label'                => __( 'Toggle Align', 'ennova-addons' ),
                    'type'                 => Controls_Manager::CHOOSE,
                    'default'              => 'center',
                    'options'              => array(
                        'left'   => array(
                            'title' => __( 'Left', 'ennova-addons' ),
                            'icon'  => 'eicon-h-align-left',
                        ),
                        'center' => array(
                            'title' => __( 'Center', 'ennova-addons' ),
                            'icon'  => 'eicon-h-align-center',
                        ),
                        'right'  => array(
                            'title' => __( 'Right', 'ennova-addons' ),
                            'icon'  => 'eicon-h-align-right',
                        ),
                    ),
                    'condition' => [
						'toggle_responsive!' => 'none',
					],
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav'=> 'justify-content:{{VALUE}};' ],
                )
            );
    
            $this->end_controls_section(); 

            $this->start_controls_section(
                'section_style_main_menu',
                array(
                    'label' => __( 'Main Menu', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
            $this->start_controls_tabs(
                'main_menu_tabs'
            );
            
            $this->start_controls_tab(
                'main_menu_normal_tab',
                [
                    'label' => esc_html__( 'Normal', 'ennova-addons' ),
                ]
            );
            $this->add_control(
                'main_menu_color',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav, .main-nav .mobile-nav' => 'background-color: {{VALUE}} !important',
                    ],
                )
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'main_menu_border',
                    'label' => esc_html__( 'Border', 'ennova-addons' ),
                    'selector' => '{{WRAPPER}} .main-nav',
                ]
            );
             
            $this->add_responsive_control(
                'main_menu_border_radius',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'main_menu_padding',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'main_menu_margin',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'main_menu_box_shadow',
                    'label'     => esc_html__( 'Box Shadow'),
                    'selector' => '{{WRAPPER}} .main-nav ',
                )
            );

            $this->end_controls_tab();
            $this->start_controls_tab(
                'main_menu_hover_tab',
                [
                    'label' => esc_html__( 'Hover', 'ennova-addons' ),
                ]
            );

            $this->add_control(
                'main_menu_color_hover',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav:hover' => 'background-color: {{VALUE}}',
                    ],
                )
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'main_menu_border_hover',
                    'label' => esc_html__( 'Border', 'ennova-addons' ),
                    'selector' => '{{WRAPPER}} .main-nav:hover',
                ]
            );
             
            $this->add_responsive_control(
                'main_menu_border_radius_hover',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'main_menu_padding_hover',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'main_menu_margin_hover',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'main_menu_box_shadow_hover',
                    'label'     => esc_html__( 'Box Shadow'),
                    'selector' => '{{WRAPPER}} .main-nav:hover ',
                )
            );
            $this->end_controls_tab();
            $this->end_controls_tabs();
            $this->end_controls_section(); 
            
            $this->start_controls_section(
                'menus_style',
                array(
                    'label' => __( 'Menus', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
            $this->add_responsive_control(
                'space_between',
                [
                    'label' => esc_html__( 'Space Between', 'ennova-addons' ),
                    'type' => Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'max' => 50,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} li.menu-item:not(:last-child)' => 'padding-bottom: calc({{SIZE}}{{UNIT}}/2)',
                    ],
                ]
            );
            $this->start_controls_tabs(
                'menus_tabs'
            );
            
            $this->start_controls_tab(
                'menus_normal_tab',
                [
                    'label' => esc_html__( 'Normal', 'ennova-addons' ),
                ]
            );
            $this->add_control(
                'menus_color',
                array(
                    'label'     => __( ' Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav .sub-link' => 'color: {{VALUE}}',
                    ],
                )
            );
            $this->add_control(
                'menus_bg_color',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav .sub-link' => 'background-color: {{VALUE}}',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'menus_typography',
                    'label'     => __( 'Typography', 'ennova-addons' ), 
                    'selector'  => '{{WRAPPER}} .main-nav .sub-link', 
                )
            ); 
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'menus_border',
                    'label' => esc_html__( 'Border', 'ennova-addons' ),
                    'selector' => '{{WRAPPER}} .main-nav .sub-link',
                ]
            );
             
            $this->add_responsive_control(
                'menus_border_radius',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'menus_padding',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'menus_margin',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'menus_box_shadow',
                    'label'     => esc_html__( 'Box Shadow'),
                    'selector' => '{{WRAPPER}} .main-nav .sub-link',
                )
            );

            $this->end_controls_tab();
            $this->start_controls_tab(
                'menus_hover_tab',
                [
                    'label' => esc_html__( 'Hover', 'ennova-addons' ),
                ]
            );

            $this->add_control(
                'menus_color_hover',
                array(
                    'label'     => __( ' Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav .sub-link:hover' => 'color: {{VALUE}}',
                        '{{WRAPPER}} .main-nav .active .sub-link' => 'color: {{VALUE}}',
                    ],
                )
            );
            $this->add_control(
                'menus_color_bg_hover',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' =>[
                        '{{WRAPPER}} .main-nav .sub-link:hover' => 'background-color: {{VALUE}}',
                        '{{WRAPPER}} .main-nav .active .sub-link' => 'background-color: {{VALUE}}',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'menus_typography_hover',
                    'label'     => __( 'Typography', 'ennova-addons' ), 
                    'selector'  => '{{WRAPPER}} .main-nav .sub-link:hover', 
                )
            );
    
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'menus_border_hover',
                    'label' => esc_html__( 'Border', 'ennova-addons' ),
                    'selector' => '{{WRAPPER}} .main-nav .sub-link:hover',
                ]
            );
             
            $this->add_responsive_control(
                'menus_border_radius_hover',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'menus_padding_hover',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'menus_margin_hover',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .sub-link:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'menus_box_shadow_hover',
                    'label'     => esc_html__( 'Box Shadow'),
                    'selector' => '{{WRAPPER}} .main-nav .sub-link:hover ',
                )
            );
            $this->end_controls_tab();
            $this->end_controls_tabs();
            $this->end_controls_section(); 
            
            $this->start_controls_section(
                'section_style_dropdown',
                array(
                    'label' => __( 'Dropdown', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
            $this->add_control(
                'dropdown_description',
                array(
                    'raw'             => __( 'On desktop, this will affect the submenu. On mobile, this will affect the entire menu.', 'ennova-addons' ),
                    'type'            => Controls_Manager::RAW_HTML,
                    'content_classes' => 'elementor-descriptor',
                )
            );
    
            $this->start_controls_tabs( 'tabs_dropdown_item_style' );
    
            $this->start_controls_tab(
                'tab_dropdown_item_normal',
                array(
                    'label' => __( 'Normal', 'ennova-addons' ),
                )
            );
    
            $this->add_control(
                'color_dropdown_item',
                array(
                    'label'     => __( 'Text Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => array(
                        '{{WRAPPER}} .drop-menu .dropdown-item' => 'color: {{VALUE}}',
                    ),
                )
            );
    
            $this->add_control(
                'background_color_dropdown_item',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => array(
                        '{{WRAPPER}} .drop-menu .dropdown-item' => 'background-color: {{VALUE}}',
                    ),
                    'separator' => 'none',
                )
            );
        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'dropdown_typography',
                    'label'     => __( 'Typography', 'ennova-addons' ), 
                    'selector'  => '{{WRAPPER}} .drop-menu .dropdown-item', 
                )
            );
    
            $this->add_group_control(
                Group_Control_Border::get_type(),
                array(
                    'name'      => 'dropdown_border',
                    'label'     => __( 'Border', 'ennova-addons' ),
                    'selector'  => '{{WRAPPER}} .drop-menu .dropdown-item', 
                )
            );
    
            $this->add_responsive_control(
                'dropdown_border_radius',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    ],
                )
            );
            $this->add_responsive_control(
                'dropdown_padding',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'dropdown_margin',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
    
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'dropdown_box_shadow', 
                    'label'     => esc_html__( 'Box Shadow', 'ennova-addons'),
                    'selector' => '{{WRAPPER}} .drop-menu .dropdown-item',
                )
            );
    
            $this->end_controls_tab();
    
            $this->start_controls_tab(
                'tab_dropdown_item_hover',
                array(
                    'label' => __( 'Hover', 'ennova-addons' ),
                )
            );
            $this->add_control(
                'color_dropdown_item_hover',
                array(
                    'label'     => __( 'Text Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => array(
                        '{{WRAPPER}} .drop-menu .dropdown-item:hover' => 'color: {{VALUE}}',
                    ),
                )
            );
    
            $this->add_control(
                'background_color_dropdown_item_hover',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => array(
                        '{{WRAPPER}} .drop-menu .dropdown-item:hover' => 'background-color: {{VALUE}}',
                    ),
                    'separator' => 'none',
                )
            );
        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'dropdown_typography_hover',
                    'label'     => __( 'Typography', 'ennova-addons' ), 
                    'selector'  => '{{WRAPPER}} .drop-menu .dropdown-item:hover', 
                )
            );
    
            $this->add_group_control(
                Group_Control_Border::get_type(),
                array(
                    'name'      => 'dropdown_border_hover',
                    'label'     => __( 'Border', 'ennova-addons' ),
                    'selector'  => '{{WRAPPER}} .drop-menu .dropdown-item:hover', 
                )
            );
    
            $this->add_responsive_control(
                'dropdown_border_radius_hover',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'tablet_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'mobile_default' => [
                        'size' => '',
                        'unit' => '',
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'dropdown_padding_hover',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->add_responsive_control(
                'dropdown_margin_hover',
                array(
                    'label'      => __( 'Margin', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .drop-menu .dropdown-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
    
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                array(
                    'name'     => 'dropdown_box_shadow_hover', 
                    'label'     => esc_html__( 'Box Shadow', 'ennova-addons'),
                    'selector' => '{{WRAPPER}} .drop-menu .dropdown-item:hover',
                )
            );
    
            $this->end_controls_tab();
            $this->end_controls_tabs();
            $this->end_controls_section();
    
            
            $this->start_controls_section(
                'section_style_toggle',
                array(
                    'label' => __( 'Toggle Button', 'ennova-addons' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                )
            );
            $this->start_controls_tabs( 'tabs_toggle_style' );
    
            $this->start_controls_tab(
                'tab_toggle_style_normal',
                array(
                    'label' => __( 'Normal', 'ennova-addons' ),
                )
            );
    
            $this->add_control(
                'toggle_color',
                array(
                    'label'     => __( 'Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'color: {{VALUE}}',
                    ),
                )
            );
    
            $this->add_control(
                'toggle_background_color',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'background-color: {{VALUE}}',
                    ),
                )
            );
            $this->add_control(
                'toggle_border_color',
                array(
                    'label'     => __( 'Border Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array( 
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'border-color: {{VALUE}}', // Harder selector to override text color control
                    ),
                )
            );
            create_box_shadow_control(
                $this,
                [
                    'key'      => 'toggle_box_shadow',
                    'label'    => 'Box Shadow',
                    'selector' => '{{WRAPPER}}  .mobile-menu-toggle',
                ]
            );
            $this->end_controls_tab();
    
            $this->start_controls_tab(
                'tab_toggle_style_hover',
                array(
                    'label' => __( 'Focus', 'ennova-addons' ),
                )
            );
    
            $this->add_control(
                'toggle_color_hover',
                array(
                    'label'     => __( 'Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon:hover' => 'color: {{VALUE}}',
                    ),
                )
            );
    
            $this->add_control(
                'toggle_background_color_hover',
                array(
                    'label'     => __( 'Background Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon:hover' => 'background-color: {{VALUE}}',
                    ),
                )
            );
            $this->add_control(
                'toggle_border_color_hover',
                array(
                    'label'     => __( 'Border Color', 'ennova-addons' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => array( 
                        '{{WRAPPER}} .main-nav .toggle-icon:hover' => 'border-color: {{VALUE}}',
                    ),
                )
            );
            $this->end_controls_tab(); 
            $this->end_controls_tabs();
    
            $this->add_responsive_control(
                'toggle_size',
                array(
                    'label'     => __( 'Size', 'ennova-addons' ),
                    'type'      => Controls_Manager::SLIDER,
                    'range'     => array(
                        'px' => array(
                            'min' => 15,
                        ),
                    ),
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'font-size: {{SIZE}}{{UNIT}}',
                    ),
                    'separator' => 'before',
                )
            );
    
            $this->add_responsive_control(
                'toggle_border_width',
                array(
                    'label'     => __( 'Border Width', 'ennova-addons' ),
                    'type'      => Controls_Manager::SLIDER,
                    'range'     => array(
                        'px' => array(
                            'max' => 10,
                        ),
                    ),
                    'selectors' => array(
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'border-width: {{SIZE}}{{UNIT}}',
                    ),
                )
            );
    
            $this->add_responsive_control(
                'toggle_border_radius',
                array(
                    'label'      => __( 'Border Radius', 'ennova-addons' ),
                    'type'       => Controls_Manager::SLIDER,
                    'size_units' => array( 'px', '%' ),
                    'selectors'  => array(
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'border-radius: {{SIZE}}{{UNIT}}',
                        '{{WRAPPER}} .main-nav .mobile-menu-toggle' => 'border-radius: {{SIZE}}{{UNIT}}',
                    ),
                )
            );
            $this->add_responsive_control(
                'toggle_padding',
                array(
                    'label'      => __( 'Padding', 'ennova-addons' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%','em'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-nav .toggle-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                )
            );
            $this->end_controls_section();
        }
    
        protected function render() {
            
            $available_menus = $this->get_available_menus();
    
            if ( ! $available_menus ) {
                return;
            }
            
            $settings = $this->get_settings_for_display();
            $indicator_icon = $settings['indicator_icon'];
            $toggle_responsive = $settings['toggle_responsive'];
            $menu_type = $settings['menu_type'];
            $menu_class = ($menu_type == 'vertical') ? 'sm sm-vertical sm-clean' : 'sm sm-clean'; ?> 

            <div class="boxy" id="<?php echo $settings['align_items']; ?>-cls"> 

                <?php if($settings['menu_is_sticky'] === 'yes') { ?>

                <nav class="main-nav mn-stick">

                <?php } else{ ?>
                    <nav class="main-nav">

                <?php } ?>
                <button class="mobile-menu-toggle <?php echo $toggle_responsive ;?> " type="button" > 
                <span class="toggle-icon open fas fa-bars"></span>
                </button>

                <div class="ennova-collapse" id="navbarNavDropdown">

                <?php wp_nav_menu( array(
                        'menu'        => $settings['menu'],
                        'menu_class'  => $menu_class.' mobile-nav',
                        'menu_id'     => 'main-menu',
                        'fallback_cb' => 'ennova_mega_menu_walker::fallback',
                        'container'   => '',
                        'walker' => new ennova_mega_menu_walker()
                    ) ); ?>

                </div>
            </nav>
        
        </div>            

    <?php  }
        
    }
    