<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

class ENNOVAPriceMenu extends \Elementor\Widget_Base {

	private $price_menu_card_class = 'ennova-price-menu';
	private $price_card_inner_class = 'ennova-price-menu-inner';
	private $price_menu_card_image_class = 'ennova-price-menu-image';
	private $price_menu_card_heading_class = 'ennova-price-menu-heading';
	private $price_menu_feature_separator_class = 'ennova-price-menu-feature-separator';
	private $price_feature = 'ennova-price-menu-feature';
	private $price_amount  = 'ennova-price-menu-amount';
	private $price_text  = 'ennova-price-menu-feature-text';
	private $price_lebal  = 'ennova-price-menu-lebal';
	private $price_btn  = 'ennova-price-menu-button';
	private $price_star  = 'ennova-price-menu-star';
	private $price_desc  = 'ennova-price-menu-description';

	public function get_name() {
		return 'ennova-price-menu';
	}

	public function get_title() {
		return __( 'Price Menu', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-nav-menu';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'price table',
			'plan', 
			'price list', 
			'price menus ',
			'ennova addons',
			'enn',
		];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'card_star_rating',
			[
				'label' => esc_html__( 'Star Icons', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 5,
				'step' => .5,
				'default' => 4,
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->add_control(
			'card_lebal',
			[
				'label' => __( 'Lebal', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Lanch',
				'condition' => [
					'template_style' => ['layout_1','layout_2','layout_3','layout_7']
				],
			],
		);

		$this->add_control(
			'card_amount',
			[
				'label' => __( 'Amount', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '$5.99',
				'condition' => [
					'template_style!' => ['layout_4','layout_5','layout_6']
				],
			],
		);

		$title ='Basic Plan';

		$this->add_control(
			'card_title', [
				'label' => __( 'Plan Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( $title , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$description = 'Aenean ut turpis blandit eros convallis congue sit amet a libero. Mauris sed tempor felis.';
		$this->add_control(
			'card_description', [
				'label' => __( 'Plan Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 5,
				'default' => __( $description , 'ennova-addons' ),
				'label_block' => true, 
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				], 
				'condition' => [
					'template_style!' => ['layout_7']
				],
			]
		);

	    $repeater = new Repeater();

        $repeater->add_control(
			'items_one_title', 
			[
				'label' => __('Items', 'ennova-addons') , 
				'type' => Controls_Manager::TEXT, 
				'label_block' => true, 
				'default' => __('Price Menu Item', 'ennova-addons') ,
			]
		);
		$this->add_control(
			'items_one_title_block', 
			[
			'label' => __('Add Items', 'ennova-addons') , 
			'type' => Controls_Manager::REPEATER, 
			'fields' => $repeater->get_controls() , 
			'default' => [
					[
						'items_one_title' => __('Price Menu Item 1', 'ennova-addons') ,
					],
					[
						'items_one_title' => __('Price Menu Item 2', 'ennova-addons') ,
					],
					[
						'items_one_title' => __('Price Menu Item 3', 'ennova-addons') ,
					],
				], 
				'condition' => [
					'template_style' => ['layout_1','layout_2','layout_3']
				],
				'title_field' => '{{{ items_one_title }}}', 
			]
		);

		$repeater_two = new Repeater();

		$repeater_two->add_control(
			'items_two_title', 
			[
				'label' => __('Items', 'ennova-addons') , 
				'type' => Controls_Manager::TEXT, 
				'label_block' => true, 
				'default' => __('Price Menu Item', 'ennova-addons') ,
			]
		);
		$repeater_two->add_control(
			'items_amount',
			[
				'label' => __( 'Amount', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('$5.99', 'ennova-addons') ,
			],
		);
		
		$this->add_control(
		'items_two_title_block', 
			[
			'label' => __('Add Items', 'ennova-addons') , 
			'type' => Controls_Manager::REPEATER, 
			'fields' => $repeater_two->get_controls() , 
			'default' => [
					[
						'items_two_title' => __('Price Menu Item 1', 'ennova-addons') ,
						'items_amount' => __('$5.99', 'ennova-addons') ,
					],
					[
						'items_two_title' => __('Price Menu Item 2', 'ennova-addons') ,
						'items_amount' => __('$5.99', 'ennova-addons') ,
					],
					[
						'items_two_title' => __('Price Menu Item 3', 'ennova-addons') ,
						'items_amount' => __('$5.99', 'ennova-addons') ,
					],
				], 
				'condition' => [
					'template_style' => ['layout_4','layout_5','layout_6']
				],
				'title_field' => '{{{ items_two_title }}}', 
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_lebal',
			[
				'label' => __( 'Show Lebal', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'template_style' => ['layout_1','layout_2','layout_3','layout_7']
				],
			]
		);

		$this->add_control(
			'show_image',
			[
				'label' => __( 'Show Image', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_item',
			[
				'label' => __( 'Show Items', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->add_control(
			'show_star',
			[
				'label' => __( 'Show Star', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->add_control(
			'show_link',
			[
				'label' => __( 'Show Button', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);

		$this->add_control(
			'btn_text', [
				'label' => __( 'Button Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Read More' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'btn_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'btn_button_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-arrow-right',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'btn_icon_position',
			[
				'label'       => esc_html__( 'Icon Position', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'after',
				'options'     => [
					'before'      => esc_html__( 'Before', 'ennova-addons' ),
					'after'      => esc_html__( 'After', 'ennova-addons' ),
				],
				'condition' => [
					'template_style!' => ['layout_6','layout_7','layout_8'],
				],
			]
		);

		$this->add_responsive_control(
			'btn_space_before',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_btn.' i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'btn_icon_position' => 'before'
				],
			]
		);

		$this->add_responsive_control(
			'btn_space_after',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_btn.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'btn_icon_position' => 'after'
				],
			]
		);

		$this->end_controls_section();

		//STYLE
		$this->start_controls_section(
			'price_menu_settings',
			[
				'label' => __( 'Price Menu Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'price_menu_box';
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.', .'.$this->price_menu_card_class.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					//'{{WRAPPER}} .'.$this->price_menu_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover' => 'background-color: {{VALUE}}', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'price',
			[
				'label' => __( 'Price Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'price_tabs' );

		$this->start_controls_tab(
			'price_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'price_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.' .amount' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'price_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.' .amount' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'price_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.' .amount',
 			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'price_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.' .amount',
 			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'price_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.' .amount' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'price_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.' .amount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'price_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.' .amount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'price_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.' .amount',
 			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'price_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'price_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .amount' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'price_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .amount' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'price_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .amount',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'price_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .amount',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'price_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .amount' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'price_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .amount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'price_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .amount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'price_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .amount',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'price_menu_lebal',
			[
				'label' => __( 'Lebal Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_1','layout_2','layout_3','layout_7']
				],
			]
		);
		$slug = 'price_menu_lebal';
        $this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_lebal => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_lebal => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->price_lebal,
 			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_lebal,
 			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_lebal => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_lebal => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_lebal => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->price_lebal,
 			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_lebal => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_lebal => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_lebal,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_lebal,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_lebal => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_lebal => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_lebal => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_lebal,
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'price_menu_image_settings',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'price_menu_image';
        $this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_image_class.' img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.':before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			$slug.'_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.' img' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.':before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_image_class.' img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					//'{{WRAPPER}} .'.$this->portfolio_card_icon_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_image_class.' img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img'  =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					//'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' .icon' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			$slug.'width_hover',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.'::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_height_hover',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img'  => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					//'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->portfolio_card_icon_class.' .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_image_class.' img' ,
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'price_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'card_heading_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->start_controls_tabs( 'card_heading_tabs' );

		$this->start_controls_tab(
			'card_heading_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_heading_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_heading_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_title_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ), 
			]
		);

		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_menu_card_heading_class.' a'=> 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_menu_card_heading_class.':hover',
			]
		);
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'card_heading_title_border_type_hover',
                'label'    => __( 'Border Type', 'ennova-addons' ),
				'selector' => 
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class.':hover', 
            ]
        );
		
		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => 
					'{{WRAPPER}} .'.$this->price_menu_card_heading_class.':hover',
				
			],
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'price_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);
		$this->add_responsive_control(
			'card_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->start_controls_tabs( 'card_description_tabs' );

		$this->start_controls_tab(
			'card_description_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_description_color',
			[
				'label'     => __( 'Description Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_desc => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_desc,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_description_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_desc,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_description_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_desc => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_description_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_desc => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_desc => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_description_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_desc,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_description_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ), 
			]
		);

		$this->add_control(
			'card_description_color_hover',
			[
				'label'     => __( 'Description Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_desc => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_description_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_desc.':hover',
			]
		);
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'card_description_border_type_hover',
                'label'    => __( 'Border Type', 'ennova-addons' ),
				'selector' => 
					'{{WRAPPER}} .'.$this->price_desc.':hover', 
            ]
        );
		
		create_border_radius_control(
			$this,
			[
				'key'       => 'card_description_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_description_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_description_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_desc.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_description_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => 
					'{{WRAPPER}} .'.$this->price_desc.':hover',
				
			],
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'price_feature',
			[
				'label' => __( 'Feature Setting', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style!' => ['layout_7']
				],
			]
		);

		$this->add_responsive_control(
			'card_heading_feature_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.' .enn-price-content ul li span.enn-menu-text , {{WRAPPER}} .'.$this->price_menu_card_class.' .enn-menu .enn-menu-text ' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'template_style' => ['layout_1','layout_2','layout_3']
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_feature_tabs' );

		$this->start_controls_tab(
			'card_heading_feature_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_feature_color',
			[
				'label'     => __( 'Item Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-price-content .'.$this->price_text => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_feature_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .enn-price-content .'.$this->price_text,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_feature_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-price-content .'.$this->price_feature,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_feature_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-price-content .'.$this->price_feature => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-price-content .'.$this->price_feature => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .enn-price-content .'.$this->price_feature => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_feature_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}} .enn-price-content .'.$this->price_text,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_feature_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_feature_color_hover',
			[
				'label'     => __( 'Iteam Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_text => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_feature_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_text, 
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_feature_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover.enn-price-content .'.$this->price_feature,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_feature_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_feature => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_feature => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_feature => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_feature_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}} .'.$this->price_menu_card_class.':hover .enn-price-content .'.$this->price_text,
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'feature_separator',
			[
				'label' => __( 'Feature Separator', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_4','layout_5','layout_6',]
				],
			]
		);

		$this->start_controls_tabs( 'feature_separator_tabs' );

		$this->start_controls_tab(
			'feature_separator_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ), 
			]
		);
		
		$this->add_responsive_control(
			'feature_separator_style',
			[
				'label'       => esc_html__( 'Separator Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'dashed',
				'options'     => [
					'none'      => esc_html__( 'None' ),
					'solid'      => esc_html__( 'Solid' ),
					'dotted'      => esc_html__( 'Dotted' ),
					'dashed'      => esc_html__( 'Dashed' ),
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_feature_separator_class => 'border-style:{{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'feature_separator_height',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_feature_separator_class => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'feature_separator_color',
			[
				'label'     => __( 'Separator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_feature_separator_class => 'border-color: {{VALUE}}',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'feature_separator_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_feature_separator_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'feature_separator_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);
		$this->add_responsive_control(
			'feature_separator_style_hover',
			[
				'label'       => esc_html__( 'Separator Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'dashed',
				'options'     => [
					'none'      => esc_html__( 'None' ),
					'solid'      => esc_html__( 'Solid' ),
					'dotted'      => esc_html__( 'Dotted' ),
					'dashed'      => esc_html__( 'Dashed' ),
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_feature_separator_class => 'border-style:{{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'feature_separator_height_hover',
			[
				'label'           => __( 'Separator Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_feature_separator_class => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'feature_separator_color_hover',
			[
				'label'     => __( 'Separator Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_menu_feature_separator_class => 'border-color: {{VALUE}}',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'feature_separator_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_menu_feature_separator_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		//  Star Settings
		$this->start_controls_section(
			'star_settings',
			[
				'label' => __( 'Star Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 
					'show_star' => 'yes', 
					'template_style' => ['layout_7'] 
				],
			]
		);
		$this->add_responsive_control(
			'card_star_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_star => 'text-align: {{VALUE}};',
				],
			]
		);
        $this->start_controls_tabs( 'card_star_tabs' );

		$this->start_controls_tab(
			'card_star_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_star_color',
			[
				'label'     => __( 'Star Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_star.' .star-rating' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'star_size',
			[
				'label'           => __( 'Star Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_star.' .star-rating' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_star_margin',
				'label'     => 'Star Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_star.' .star-rating i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_star_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_star_color_hover',
			[
				'label'     => __( 'Star Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_menu_card_class.':hover .'.$this->price_star.' .star-rating' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'star_size_hover',
			[
				'label'           => __( 'Star Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_star.' .star-rating' =>  'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_star_margin_hover',
				'label'     => 'Star Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_menu_card_class.':hover .'.$this->price_star.' .star-rating i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		// Button Settings
		$this->start_controls_section(
			'button_settings',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => ['layout_7']
				],
			]
		);

		$this->start_controls_tabs( 'btn_tabs' );

		$this->start_controls_tab(
			'btn_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		); 
		$this->add_control(
			'btn_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_btn.' .more' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_btn.' .more i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_btn.' .more' => 'background-color: {{VALUE}}',  
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'btn_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_btn.' .more', 
			]
		);
		$this->add_responsive_control(
			'btn_icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_btn.' .more i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'btn_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_btn.' .more',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'btn_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'btn_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'btn_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'btn_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_btn.' .more',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'btn_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_btn.':hover .more' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_btn.':hover .more i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.':hover .more' => 'background-color: {{VALUE}}', 
				],
			]
		); 

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'btn_hover_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_btn.' .more:hover', 
			]
		);
		$this->add_responsive_control(
			'btn_icon_size_hover',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_btn.' .more:hover i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'btn_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_btn.' .more'.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'btn_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more'.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'btn_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more'.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'btn_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_btn.' .more'.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'btn_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_btn.' .more'.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();  
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$template_style = $settings['template_style'];

		$show_lebal = $settings['show_lebal'];
		$show_image = $settings['show_image'];
		$show_title = $settings['show_title'];
		$show_item = $settings['show_item'];
		$show_star = $settings['show_star'];
		$show_description = $settings['show_description'];
		$show_link = $settings['show_link'];  

		$title = $settings['card_title'];
	
		$amount = $settings['card_amount'];
		$card_lebal = $settings['card_lebal'];
		$image_url = $settings['card_image']['url'];  
		$items_one_title_block = $settings['items_one_title_block'];
		$items_two_title_block = $settings['items_two_title_block'];
		if($template_style == 'layout_7') {
			$description = $settings['card_description'];
			$card_star_rating = $settings['card_star_rating'];
			$rating = $card_star_rating;
			$round_next_rating = round($rating);
			$round_prev_rating = floor($rating);
			$btn_text = $settings['btn_text'];
			$btn_button_icon = $settings['btn_button_icon'];
			$btn_icon_position = $settings['btn_icon_position'];
			$btn_link = $settings['btn_link']['url'];
			$btn_target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
			$btn_nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';
		}
		if($template_style != 'layout_7') {
			$link = $settings['card_link']['url'];
			$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
			$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : '';
		}
		$template_path = ENNOVA_PATH . 'inc/templates/price-menu/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
			case 'layout_3':
				require $template_path. 'layout-3.php';
				break;
			case 'layout_4':
				require $template_path. 'layout-4.php';
				break;
			case 'layout_5':
				require $template_path. 'layout-5.php';
				break;
			case 'layout_6':
				require $template_path. 'layout-6.php';
				break;
			case 'layout_7':
				require $template_path. 'layout-7.php';
				break;
			default:
				require $template_path. 'layout-1.php';
				break;
		}
	}
}