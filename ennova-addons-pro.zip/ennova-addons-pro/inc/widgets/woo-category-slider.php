<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;

class ENNOVAProductCategorySlider extends \Elementor\Widget_Base {

	private $product_cat_card_class = 'ennova-single-category-slider';
	private $product_cat_inner = 'ennova-product-category-inner-slider'; 
	private $product_cat_img = 'ennova-category-image-slider';
	private $product_cat_title = 'ennova-category-name-slider';
	private $product_cat_count = 'ennova-category-count';

	public function get_name() {
		return 'ennova-category-slider';
	}

	public function get_title() {
		return __( 'Product Category Slider', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-woo-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-product-categories';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'query_configuration',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// slider title
		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'one',
				'options'     => [
					'one'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'two'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'three'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'four'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'five'      => esc_html__( 'Layout 5', 'ennova-addons' ),
				],
			]
		);
		
		create_select2(
			$this,
			[
				'key'         => 'product_category',
				'label'       => 'Select Category',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_product_category(),
				'multiple'    => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_configuration',
			[
				'label' => __( 'Item Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_title',
				'label'     => 'Show Title',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_category_count',
				'label'     => 'Show Category Count',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
				'condition' => [
					'template_style!' =>'three',
				]
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_image',
				'label'     => 'Show Image',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'posts_per_page',
				'label'       => 'Limit',
				'placeholder' => 'Default is 10',
				'min'         => 1,
				'default'     => 10,
			]
		);

		create_image_size_control(
			$this,
			[
				'name'      => 'thumbnail_size',
				'default'   => 'thumbnail',
				'condition' => [
					'display_image' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_configuration',
			[
				'label'     => __( 'Slider Settings', 'ennova-addons' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				
			]
		);
		
		create_number(
			$this,
			[
				'key'         => 'slide_to_show',
				'label'       => 'Slides to Show',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 5,
			]
		);

		create_number(
			$this,
			[
				'key'         => 'slides_to_scroll',
				'label'       => 'Slides to Scroll',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1,
			]
		);

		create_number(
			$this,
			[
				'key'         => 'slides_space_between',
				'label'       => 'Slides Space Between',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 30,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_navigation_arrow',
				'label'     => 'Show Navigation Arrow',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'dot_clickable',
				'label'     => 'Dot Clickable',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'autoplay',
				'label'     => 'AutoPlay',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'autoplay_speed',
				'label'       => 'AutoPlay Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 3000,
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		create_number(
			$this,
			[
				'key'         => 'transition_between_slides',
				'label'       => 'Slide Switch Speed',
				'placeholder' => '',
				'min'         => 1,
				'default'     => 1000,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'loop',
				'label'     => 'Loop',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'mousewheel',
				'label'     => 'Mouse on Wheel',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'keyboard_control',
				'label'     => 'Keyboard Control',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_dots',
				'label'     => 'Show Dots',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'no',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_scroll_bar',
				'label'     => 'Show Scroll Bar',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		$this->end_controls_section();

		// STYLE
		// style item box
		$this->start_controls_section(
			'section_item_style',
			[
				'label' => __( 'Box Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,

			]
		);

		$slug = 'product_categroy_item';
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_normal_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class.':hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_card_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// style item ends

		// styles image
		$this->start_controls_section(
			'section_image_style',
			[
				'label'     => __( 'Image Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'product_categroy_image';

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Overlay Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->product_cat_img.' .enn_img:before' => 'background: linear-gradient(180deg, rgba(33, 33, 33, 0.05) 0%, {{VALUE}} 100%) ',
				], 
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 400,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 400,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_img.' .enn_img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_img.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->product_cat_img.' .enn_img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		); 
		
		$this->add_responsive_control(
			$slug.'_hover_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 400,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.':hover .enn_img' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_hover_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 400,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.':hover .enn_img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		); 

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}}.'.$this->product_cat_img.':hover .enn_img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_img.':hover .enn_img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_img.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_img.':hover  .enn_img',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();
		// styles image ends

		// styles item title
		$this->start_controls_section(
			'section_item_title_style',
			[
				'label'     => __( 'Title Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'product_categroy_title';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_text_align',
				'label'     => 'Alignment',
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' .title' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a:hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// style item title ends

		// styles item count
		$this->start_controls_section(
			'section_item_count_style',
			[
				'label'     => __( 'Count Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style!' =>'three',
				]
			]
		);

		$slug = 'product_categroy_count';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_text_align',
				'label'     => 'Alignment',
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.'',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.'',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.':hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.':hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// style item count ends

		create_navigation_style( $this , [] );
	}
	
	protected function render() {
		$settings                    = $this->get_settings_for_display();
		$element_id                  = 'ennova_slider_' . $this->get_id(); 
		$template_style              = $settings['template_style'];
		$limit              		= $settings['posts_per_page'];
		$template_path = ENNOVA_PATH . 'inc/templates/style-1/woo-product-category.php'; 

		$slide_to_show               = isset( $settings['slide_to_show'] ) && $settings['slide_to_show'] ? $settings['slide_to_show'] : 3;
		$slide_to_show_tablet        = isset( $settings['slide_to_show_tablet'] ) && $settings['slide_to_show_tablet'] ? $settings['slide_to_show_tablet'] : 2;
		$slide_to_show_mobile        = isset( $settings['slide_to_show_mobile'] ) && $settings['slide_to_show_mobile'] ? $settings['slide_to_show_mobile'] : 1;
		$slides_to_scroll            = isset( $settings['slides_to_scroll'] ) && $settings['slides_to_scroll'] ? $settings['slides_to_scroll'] : 3;
		$slides_to_scroll_mobile     = isset( $settings['slides_to_scroll_mobile'] ) && $settings['slides_to_scroll_mobile'] ? $settings['slides_to_scroll_mobile'] : 2;
		$slides_to_scroll_tablet     = isset( $settings['slides_to_scroll_tablet'] ) && $settings['slides_to_scroll_tablet'] ? $settings['slides_to_scroll_tablet'] : 1;
		$slides_space_between        = isset( $settings['slides_space_between'] ) && $settings['slides_space_between'] ? $settings['slides_space_between'] : 10;
		$slides_space_between_mobile = isset( $settings['slides_space_between_mobile'] ) && $settings['slides_space_between_mobile'] ? $settings['slides_space_between_mobile'] : 2;
		$slides_space_between_tablet = isset( $settings['slides_space_between_tablet'] ) && $settings['slides_space_between_tablet'] ? $settings['slides_space_between_tablet'] : 5;

		$autoplay       = false;
		$autoplay_speed = 3000;

		if ( array_key_exists( 'autoplay', $settings ) && $settings['autoplay'] === 'yes' ) {
			$autoplay = true;
			if ( array_key_exists( 'autoplay_speed', $settings ) ) {
				$autoplay_speed = $settings['autoplay_speed'];
			}
		}

		$transition_between_slides = 1000;
		$loop                      = false;
		$mousewheel                = false;
		$keyboard_control          = false;

		if ( isset( $settings['transition_between_slides'] ) && ! empty( $settings['transition_between_slides'] ) ) {
			$transition_between_slides = $settings['transition_between_slides'];
		}

		if ( isset( $settings['loop'] ) && ! empty( $settings['loop'] ) && $settings['loop'] === 'yes' ) {
			$loop = true;
		}
		if ( isset( $settings['mousewheel'] ) && ! empty( $settings['mousewheel'] ) && $settings['mousewheel'] === 'yes' ) {
			$mousewheel = true;
		}
		if ( isset( $settings['keyboard_control'] ) && ! empty( $settings['keyboard_control'] ) && $settings['keyboard_control'] === 'yes' ) {
			$keyboard_control = true;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'ennova-outer-wrapper' );
		$this->add_render_attribute( 'wrapper', 'data-wid', $this->get_id() );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . '>';
		echo '<div
        		class="ennova_slider_wrapper "
        		id="' . esc_attr( $element_id ) . '"
        		data-slide-to-show="' . esc_html( $slide_to_show ) . '"
				data-slide-to-show-mobile="' . esc_html( $slide_to_show_mobile ) . '"
				data-slide-to-show-tablet="' . esc_html( $slide_to_show_tablet ) . '"
        		data-slides-to-scroll="' . esc_html( $slides_to_scroll ) . '"
				data-slides-to-scroll-mobile="' . esc_html( $slides_to_scroll_mobile ) . '"
				data-slides-to-scroll-tablet="' . esc_html( $slides_to_scroll_tablet ) . '"
        		data-slides-space-between="' . esc_html( $slides_space_between ) . '"
				data-slides-space-between-mobile="' . esc_html( $slides_space_between_mobile ) . '"
				data-slides-space-between-tablet="' . esc_html( $slides_space_between_tablet ) . '"
				data-autoplay="' . esc_html( $autoplay ) . '"
				data-autoplay-speed="' . esc_html( $autoplay_speed ) . '"

				data-transition_between_slides="' . esc_html( $transition_between_slides ) . '"
				data-loop="' . esc_html( $loop ) . '"
				data-mousewheel="' . esc_html( $mousewheel ) . '"
				data-keyboard_control="' . esc_html( $keyboard_control ) . '"
        	>';	

		$select_cats = $settings['product_category'];

		if($select_cats == '' || empty($select_cats) ){
			$categories_list = ennova_get_all_category();
		}else{
			$categories = [];
			foreach ($select_cats as $category) {
				$categories[] = get_term_by( 'name', $category, 'product_cat' );
			}
			$categories_list = $categories;
		}

		$swiper_container_class = 'swiper swiper-container swiper-' . $this->get_id();
		if ( $categories_list && count( $categories_list ) > 0 ) { ?>
			<!-- Slider main container -->
			<div class="<?php echo esc_html( $swiper_container_class ); ?>">
				<!-- Additional required wrapper -->
				<div class="swiper-wrapper">
					<?php require ENNOVA_PATH . 'inc/templates/style-1/woo-product-category-slider.php'; ?>
				</div>
				<?php
				if ( $settings['display_dots'] === 'yes' ) {
					?>
					<!-- If we need pagination -->
					<div class="swiper-pagination"></div>
					<?php
				}
				?>
				<?php
				if ( $settings['show_navigation_arrow'] === 'yes' ) {
					?>
					<!-- If we need navigation buttons -->
					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
					<?php
				}
				?>
				<?php
				if ( $settings['show_scroll_bar'] === 'yes' ) {
					?>
					<!-- If we need scrollbar -->
					<div class="swiper-scrollbar"></div>
					<?php
				}
				?>
			</div>
			<?php
		} else {
			echo 'No Category Found!';
		}
		echo '</div>';
		echo '</div>';
	}
}