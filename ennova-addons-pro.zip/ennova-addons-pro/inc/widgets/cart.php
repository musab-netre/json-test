<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;

class ENNOVACart extends Widget_Base {

	private $cart_button_class = 'ennova-cart-button';
	private $cart_total_class = 'ennova-cart-total';
	private $cart_icon_class = 'ennova-cart-icon';
	private $cart_counter_class = 'ennova-cart-counter';
	private $cart_offcanvas_class = 'ennova-cart-offcanvas';

	public function get_name() {
		return 'ennova-cart';
	}

	public function get_title() {
		return __( 'Cart', 'ennova-addons' );
	}

	public function get_icon() {
		return 'enn-icon eicon-cart';
	}

	public function get_categories() {
		return [ 'wc-woo-element' ];
	}

    public function get_style_depends() {
        return ['ennova-styles-css'];

    }

	public function get_script_depends() {
		return [
			'ennova-custom-js',
		];
	}
	
	public function get_keywords() {
		return [
			'cart',
			'wishlist',
			'favorite',
			'add to cart',
			'ennova addons',
			'enn',
			'woo',
		];
	}

	protected function register_controls() {

		$this->general_content_controls();
		$this->style_content_controls();
	}

	protected function general_content_controls() {

		$this->start_controls_section(
			'section_general_fields',
			[
				'label' => __( 'Cart', 'ennova-addons' ),
			]
		);

        $this->add_control(
			'ennova_cart_icon',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-shopping-cart',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'items_indicator',
			[
				'label'        => __( 'Items Count', 'ennova-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'ennova-addons' ),
				'label_off'    => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',    
				
			]
		);

		$this->add_control(
			'show_subtotal',
			[
				'label'        => __( 'Show Total Price', 'ennova-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'ennova-addons' ),
				'label_off'    => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',

			]
		);

		$this->add_responsive_control(
			'cart_align',
			[
				'label'              => __( 'Alignment', 'ennova-addons' ),
				'type'               => Controls_Manager::CHOOSE,
				'options'            => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'            => '',

                'selectors' =>[
                    '{{WRAPPER}} .ennova-cart' => 'text-align: {{VALUE}}',
                ]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cart_settings',
			[
				'label' => __( 'Cart Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cart_type_style',
			[
				'label'       => esc_html__( 'Cart Type', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'slide',
				'options'     => [
					'slide'      => esc_html__( 'Slide', 'ennova-addons' ),
					'mini_cart' => esc_html__( 'Dropdown', 'ennova-addons' ),
				],
			]
		); 
		
		$this->add_control(
			'open_cart_type',
			[
				'label'       => esc_html__( 'Open Cart', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'on_click',
				'options'     => [
					'on_click'      => esc_html__( 'On Click', 'ennova-addons' ),
					'on_hover' => esc_html__( 'On Hover', 'ennova-addons' ),
				],
			]
		);

		$this->end_controls_section();
	}

	protected function style_content_controls() {
		$this->start_controls_section(
			'section_heading_typography',
			[
				'label' => __( 'Cart Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'toggle_button_colors' );

		$this->start_controls_tab(
			'toggle_button_normal_colors',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'toggle_button_price_color',
			[
				'label'     => __( 'Price Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_total_class.' .woocommerce-Price-amount  bdi' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'toggle_button_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_icon_class.' i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .'.$this->cart_icon_class.' svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toggle_button_background_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'background-color: {{VALUE}}',
				],
			]
		);

        create_typography_control(
			$this,
			[
				'name'     => 'toggle_button_price_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->cart_total_class,
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_size',
			[
				'label'      => __( 'Icon Size', 'ennova-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_icon_class.' i' => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .'.$this->cart_icon_class.' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_space',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .'.$this->cart_icon_class.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .'.$this->cart_icon_class.' svg' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'toggle_button_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->cart_button_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'toggle_button_border_radius',
				'label'     => 'Border Radius',
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_margin',
				'label'     => 'Margin',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_padding',
				'label'     => 'Padding',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'toggle_button_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->cart_button_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'toggle_button_hover_colors',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'toggle_button_price_color_hover',
			[
				'label'     => __( 'Price Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_total_class.' .woocommerce-Price-amount  bdi' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'toggle_button_icon_color_hover',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toggle_button_background_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        create_typography_control(
			$this,
			[
				'name'     => 'toggle_button_price_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_total_class,
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_size_hover',
			[
				'label'      => __( 'Icon Size', 'ennova-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' i' => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_space_hover',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .'.$this->cart_button_class.':hover .'.$this->cart_icon_class.' svg' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'toggle_button_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->cart_button_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'toggle_button_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_margin_hover',
				'label'     => 'Margin',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_padding_hover',
				'label'     => 'Padding',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'toggle_button_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->cart_button_class.':hover',
			]
		);
		

		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon',
			[
				'label'     => __( 'Counter', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				
			]
		);

		$this->start_controls_tabs( 'counter_tabs' );

		$this->start_controls_tab(
			'counter_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'counter_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'counter_background_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_size',
			[
				'label'           => __( 'Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'counter_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'counter_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'counter_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'counter_color_hover',
			[
				'label'     => __( 'Text Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'counter_background_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_width_hover',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_size_hover',
			[
				'label'           => __( 'Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'counter_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'counter_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class.':hover .'.$this->cart_counter_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'section_cart_style',
			[
				'label' => esc_html__( 'Slider / Dropdown', 'ennova-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'background_color',
				'label'     => 'Background Color',
				'selectors' => [	
					'{{WRAPPER}} .ennova-cart-offcanvas' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-cart-offcanvas',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-cart-offcanvas' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_padding',
			[
				'label' => esc_html__( 'Padding', 'ennova-addons' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ennova-cart-offcanvas' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'cart_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .ennova-cart-offcanvas',
			]
		);

		$this->add_control(
			'heading_close',
			[
				'label' => esc_html__( 'Close Cart', 'ennova-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'close_cart_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'selectors' => [
					'{{WRAPPER}} .enn-offcanvas-close .times' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'close_cart_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .enn-offcanvas-close' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'cart_icon_style' );

		$this->start_controls_tab(
			'icon_normal',
			[
				'label' => esc_html__( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'close_cart_icon_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-offcanvas-close .times' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover',
			[
				'label' => esc_html__( 'Hover', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'close_cart_icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-offcanvas-close:hover .times' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'heading_remove_item_button_style',
			[
				'label' => esc_html__( 'Remove Item', 'ennova-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				
			]
		);

		$this->add_responsive_control(
			'remove_item_button_size',
			[
				'label' => esc_html__( 'Icon Size', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .item-remove' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				
			]
		);

		$this->start_controls_tabs(
			'cart_remove_item_button_style',
			[
				
			]
		);

		$this->start_controls_tab(
			'remove_item_button_normal',
			[
				'label' => esc_html__( 'Normal', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'remove_item_button_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-remove a i' => 'color: {{VALUE}}',
				],
				
			]
		);

		$this->add_control(
			'remove_item_button_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-remove' => 'background-color: {{VALUE}}',
				],
				
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'remove_item_button_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .item-remove',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'remove_item_button_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .item-remove' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'remove_item_button_hover',
			[
				'label' => esc_html__( 'Hover', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'remove_item_button_hover_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-remove:hover a i' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'remove_item_button_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-remove:hover' => 'background-color: {{VALUE}}',
				],
				
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'remove_item_button_border_hover_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .item-remove:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'remove_item_button_border_hover_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .item-remove:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'heading_subtotal_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Subtotal', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'subtotal_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-sub-total-price .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'subtotal_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .enn-sub-total-price .sub-title',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'item_border_type_hover',
				'label'    => 'Divider Style',
				'selector' => '{{WRAPPER}} .enn-sub-total-price',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'item_border_radius_hover',
				'label'     => 'Divider Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-sub-total-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'subtotal_price_color',
			[
				'label' => esc_html__( 'Price Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-sub-total-price .sub-price' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'subtotal_price_typography',
				'label'    => 'Price Typography',
				'selector' => '{{WRAPPER}} .enn-sub-total-price .sub-price',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'subtotal_price_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-sub-total-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'product_box_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .enn-sub-total-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product_tabs_style',
			[
				'label' => esc_html__( 'Products', 'ennova-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_product_box_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Product box', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'product_box_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-items .enn-cart-item' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'product_box_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-items .enn-cart-item',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'product_box_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-items .enn-cart-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'product_box_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-items .enn-cart-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'product_box_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-items .enn-cart-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'product_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .enn-cart-items .enn-cart-item',
			]
		);

		$this->add_responsive_control(
			'product_box_gap',
			[
				'label' => esc_html__( 'Spacing', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'size_units' => [ '%', 'px' ],
				'selectors' => [
					'{{WRAPPER}} .enn-cart-items .enn-cart-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_product_image_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Product Image', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'product_image_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .enn-cart-item .item-image a img' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			'product_image_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .enn-cart-item .item-image a img' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'product_image_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-item .item-image a img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'product_image_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-item .item-image a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'product_image_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-item .item-image a img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'product_image_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .enn-cart-item .item-image a img',
			]
		);

		$this->add_control(
			'heading_product_title_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Product Title', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'product_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .item-details .item-title',
			]
		);

		$this->start_controls_tabs( 'product_title_colors' );

		$this->start_controls_tab( 'product_title_normal_colors', [ 'label' => esc_html__( 'Normal', 'ennova-addons' ) ] );

		$this->add_control(
			'product_title_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-details .item-title' => 'color: {{VALUE}};',

				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'product_title_hover_colors', [ 'label' => esc_html__( 'Hover', 'ennova-addons' ) ] );

		$this->add_control(
			'product_title_hover_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-details .item-title:hover' => 'color: {{VALUE}};',

				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'heading_product_variations_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Variations', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'product_variations_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--product-variations-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'product_variations_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .elementor-menu-cart__product .variation',
			]
		);

		$this->add_control(
			'heading_product_price_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Product Price', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'product_price_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-details .item-price' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'product_price_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .item-details .item-price',
			]
		);

		$this->add_control(
			'heading_quantity_title_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Quantity', 'ennova-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'product_quantity_color',
			[
				'label' => esc_html__( 'Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .item-quantity .item-count' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'product_quantity_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .item-quantity .item-count',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_buttons',
			[
				'label' => esc_html__( 'Buttons', 'ennova-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'space_between_buttons',
			[
				'label' => esc_html__( 'Space Between', 'ennova-addons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				
			]
		);

		$this->add_control(
			'heading_view_cart_button_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'View Cart', 'ennova-addons' ),
				
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'view_cart_buttons_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child + a',
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'view_cart_button_text_colors', [] );

		$this->start_controls_tab(
			'heading_view_cart_button_normal_style',
			[
				'label' => esc_html__( 'Normal', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'view_cart_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'view_cart_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'view_cart_button_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child + a',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'view_cart_button_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'view_cart_button_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'view_cart_button_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child + a ',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'heading_view_cart_button_hover_style',
			[
				'label' => esc_html__( 'Hover', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'view_cart_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a:hover' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'view_cart_button_hover_background',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'view_cart_button_hover_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child + a:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'view_cart_button_hover_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'view_cart_button_hover_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child + a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'view_cart_button_hover_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child + a:hover ',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'heading_checkout_button_style',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Checkout', 'ennova-addons' ),
				
			]
		);

		create_typography_control(
			$this,
			[
				'name' => 'cart_checkout_button_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child',
				'separator' => 'before',
				
			]
		);

		$this->start_controls_tabs('cart_checkout_button_text_colors', [] );

		$this->start_controls_tab(
			'heading_cart_checkout_button_normal_style',
			[
				'label' => esc_html__( 'Normal', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'checkout_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'checkout_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'checkout_button_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'checkout_button_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .enn-cart-btn a:first-child' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'checkout_button_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'checkout_button_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child ',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'heading_cart_checkout_button_hover_style',
			[
				'label' => esc_html__( 'Hover', 'ennova-addons' ),
				
			]
		);

		$this->add_control(
			'checkout_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child:hover' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'checkout_button_hover_background',
			[
				'label' => esc_html__( 'Background Color', 'ennova-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'checkout_button_hover_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'checkout_button_hover_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .enn-cart-btn a:first-child:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'checkout_button_hover_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .enn-cart-btn a:first-child:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'checkout_button_hover_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .enn-cart-btn a:first-child:hover ',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {

	if ( null === WC()->cart ) {
		return;
	}

	$settings  = $this->get_settings_for_display(); 
	$cart_style = $settings['cart_type_style'];
	$open_type = $settings['open_cart_type'];
	$product_count = WC()->cart->get_cart_contents_count();
	$get_cart_subtotal = WC()->cart->get_cart_subtotal();
	$view_cart_url = wc_get_cart_url();
	$checkout_url = wc_get_checkout_url();
	?>
    <div class="ennova-cart ennova-bor" >
        <div class="cart-inner">
            <a class="cart <?php echo esc_attr($this->cart_button_class) ?>">
            <?php if($settings['show_subtotal'] === 'yes' ) { ?>
                <span class='cart-total <?php echo esc_attr($this->cart_total_class) ?>'>
                    <?php echo WC()->cart->get_cart_subtotal(); ?>
                </span>
            <?php } ?>    
                <div class="cart-icon <?php echo esc_attr($this->cart_icon_class) ?>">
                   <?php \Elementor\Icons_Manager::render_icon( $settings['ennova_cart_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                   </div>
                <?php if($settings['items_indicator'] === 'yes' ) { ?>   
                <span class='counter <?php echo esc_attr($this->cart_counter_class) ?>'>
                    <?php echo WC()->cart->get_cart_contents_count(); ?>
                </span>
                <?php } ?>
            </a>       
        </div>  
		<?php // Get cart contents
$cart_items = WC()->cart->get_cart_contents();
?>
	<div class="enn-offcanvas <?php echo esc_attr($this->cart_offcanvas_class); ?> <?php echo esc_attr($cart_style); ?> <?php echo $open_type ; ?> ">
		<div class="enn-offcanvas-close">
			<span class="times"></span>
			<span class="times"></span>
		</div>
		<div class="enn-shopping-cart">
          <!-- items -->
          <div class="enn-cart-items">
			<?php $cart_subtotal = WC()->cart->get_subtotal(); 
			foreach ( $cart_items as $cart_item_key => $cart_item ) {
				$product_id = $cart_item['product_id'];
				$product_image_id = get_post_thumbnail_id( $product_id );
				$product_image = wp_get_attachment_image_url( $product_image_id, 'thumbnail' );
				$product_name = get_the_title( $product_id );
				$product_price = $cart_item['data']->get_price();
    			$product_quantity = $cart_item['quantity'];
				$product_link = get_permalink($product_id);
				$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );	
				$remove_url = wc_get_cart_remove_url( $cart_item_key );
      ?>
          <div class="enn-cart-item">
            <div class="item-image">
             <a href="<?php echo esc_url($product_link); ?>"> <img src="<?php echo esc_url($product_image); ?>" alt="Common Projects"> </a>
            </div>
            <div class="item-details">
			<a href="<?php echo esc_url($product_link); ?>"><h6 class="item-title"><?php echo esc_html($product_name); ?></h6></a>
              <div class="item-quantity">
                <!-- <span class="fas fa-chevron-left item-up"></span> -->
                <span class="item-count"><?php echo esc_html($product_quantity); ?> x </span>
                <!-- <span class="fas fa-chevron-right item-down"></span> -->
              </div>
              <div class="item-price">$<?php echo esc_html($product_price); ?></div>
            </div>
            <div class="item-remove">
			<?php
				echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'woocommerce_cart_item_remove_link',
					sprintf(
						'<a href="%s" class="remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><i class="%s"></i></a>',
						esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
						esc_attr__( 'Remove this item', 'woocommerce' ),
						esc_attr( $product_id ),
						esc_attr( $cart_item_key ),
						esc_attr( $_product->get_sku() ),
						esc_attr('fas fa-times')
					),
					$cart_item_key
				);
			?>
            </div>
          </div>
		<?php } ?>
        </div>
          <!-- /items -->
        <div class="enn-cart-more">
         <div class="enn-sub-total-price">
          <h5 class="sub-title">Sub Total</h5>
          <span class="sub-price">$<?php echo esc_html($cart_subtotal); ?></span>
         </div>
         <div class="enn-cart-btn">
          <a href="<?php echo esc_url($checkout_url ); ?>">Checkout</a>
          <a href="<?php echo esc_url($view_cart_url ); ?>">View Cart</a>
         </div>
        </div>
      </div>
	</div>
    </div>
		<?php
	}
	protected function content_template() {
	}
}
