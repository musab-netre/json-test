<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

class ENNOVAService extends \Elementor\Widget_Base {

	private $service_card_class = 'ennova-service-card';
	private $service_card_inner_class = 'ennova-service-inner-card';
	private $service_card_image_class = 'ennova-service-card-image';
	private $service_card_heading_class = 'ennova-service-card-heading';
	private $service_subtitle = 'ennova-service-card-subtitle';
	private $service_card_icon_class = 'ennova-service-card-icon';
	private $service_card_description_class = 'ennova-service-card-description';
	private $service_card_read_more_class = 'ennova-service-card-read-more';

	public function get_name() {
		return 'ennova-service';
	}

	public function get_title() {
		return __( 'Service', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-info-box';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'service item',
			'service',
			'item',
			'enn',
			'enn service',
			'ennova addons',
		];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 8', 'ennova-addons' ),
					'layout_9'      => esc_html__( 'Layout 9', 'ennova-addons' ),
					'layout_10'     => esc_html__( 'Layout 10', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [ 
					'template_style' => [
						'layout_2',
						'layout_5',
						'layout_7',
						'layout_9',
					],
				],
			]
		);

	

		$this->add_control(
			'card_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'solid',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
					],
				],
			]
		);
		$this->add_control(
			'card_subtitle', [
				'label' => __( 'Sub Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Advertise' , 'ennova-addons' ),
				'label_block' => true,
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '==',
							'value'    => 'layout_10',
						],
					],
				],
			]
		);
		$this->add_control(
			'card_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Card Title' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
	

		$description = 'Aenean ut turpis blandit eros convallis congue sit amet a libero. Mauris sed tempor felis.';
		$this->add_control(
			'card_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 5,
				'default' => __( $description, 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						]
					]
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_image',
			[
				'label' => __( 'Show Image', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [ 
					'template_style' => [
						'layout_2', 
						'layout_5',
						'layout_7',
						'layout_9',
					],
				],
			]
		);


		$this->add_control(
			'show_icon',
			[
				'label' => __( 'Show Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_7',
						],
					],
				],
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						]
					]
				]
			]
		);

		$this->add_control(
			'show_link',
			[
				'label' => __( 'Show Read More', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'card_link_text', [
				'label' => __( 'Button Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Read More' , 'ennova-addons' ),
				'label_block' => true,
				'condition' => [
					'template_style!' => ['layout_6','layout_7','layout_8'],
				],
			]
		);

		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'link_button_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-arrow-right',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'link_button_position',
			[
				'label'       => esc_html__( 'Icon Position', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'after',
				'options'     => [
					'before'      => esc_html__( 'Before', 'ennova-addons' ),
					'after'      => esc_html__( 'After', 'ennova-addons' ),
				],
				'condition' => [
					'template_style!' => ['layout_6','layout_7','layout_8'],
				],
			]
		);

		$this->add_responsive_control(
			'link_button_space_before',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'link_button_position' => 'before',
					'template_style!' => ['layout_6','layout_7','layout_8'],
				],
			]
		);

		$this->add_responsive_control(
			'link_button_space_after',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'link_button_position' => 'after',
					'template_style!' => ['layout_6','layout_7','layout_8'],
				],
			]
		);

		$this->end_controls_section();

		//STYLE
		// Service Box
		$this->start_controls_section(
			'service_settings',
			[
				'label' => __( 'Service Box Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_opacity_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_class.', .'.$this->service_card_class.'.service_four::before',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_opacity_hover_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_class.':hover',
				'condition' => [
					'template_style!' => [
						'layout_1',
						'layout_4',
						'layout_8',
					],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_opacity_two_hover_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_class.'::before',
				'condition' => [
					'template_style' => [
						'layout_1',
						'layout_8',
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_opacity_three_hover_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_class.'.service_four:hover:before',
				'condition' => [
					'template_style' => [
						'layout_4',
					],
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_class.':hover',
			]
		);
		$this->end_controls_tab(); 
		$this->end_controls_tabs();
		$this->end_controls_section();

		// Service Inner Settings
		$this->start_controls_section(
			'service_inner_style',
			[
				'label' => __( 'Service Content Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'template_style' => [
						'layout_3',
						'layout_7',
						'layout_9',
					],
				],
			]
		); 
		$slug = 'service_inner_box';
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_inner_class => 'background-color: {{VALUE}}',
				], 
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_inner_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_inner_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			$slug.'_bg_hover_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_inner_class.':hover' => 'background-color: {{VALUE}}',
				], 
			]
		);
		 
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_inner_class.':hover',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_inner_padding_hover',
				'label'     => 'Inner Content Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_inner_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_inner_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Image Settings
		$this->start_controls_section(
			'service_image_settings',
			[
				'label' => __( 'Image Settings ', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE, 
				'condition' => [ 
					'template_style' => [
						'layout_2',
						'layout_5',
						'layout_7',
						'layout_9',
					],
				],
			], 
		);

		$this->add_control(
			'servie_image_bg_color',
			[
				'label'     => __( 'Overlay Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_image_class.'::before , .service_five .'.$this->service_card_image_class.' + 	.content::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [ 
					'template_style' => [
						'layout_2',
						'layout_5',
						'layout_7',
						'layout_9',
					],
				],
			]
		);
		
		$slug = 'service_box_image';
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_image_class.'' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_image_class.'' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_image_class.' img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_image_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .service_five  .'.$this->service_card_image_class.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_image_class.' img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_image_class.'',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		
		$this->add_responsive_control(
			$slug.'_hover_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_image_class.':hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_hover_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_image_class.':hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_image_class.' img:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_image_class.' img:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_image_class.' img:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_image_class.':hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Icon Settings
		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Icon Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_icon_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_icon_class => 'justify-content: {{VALUE}};',
				],
				'condition' => [ 
					'template_style!' => ['layout_8'],
				],
			]
		);

        $this->start_controls_tabs( 'card_icon_tabs' );

		$this->start_controls_tab(
			'card_heading_icon_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:before, {{WRAPPER}} .'.$this->service_card_icon_class.' .icon',
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_icon_class.' .icon' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->service_card_icon_class.' .icon svg' => 'fill: {{VALUE}}',
				],
			],
		);

		$this->add_responsive_control(
			'icon_width',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_icon_class.' .icon',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_icon_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_icon_class . ' .icon',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_icon_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_bg_color_hover',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->service_card_class.':hover .icon:before, {{WRAPPER}} .'.$this->service_card_class.':hover .icon',
			]
		);
		$this->add_control(
			'icon_color_hover',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_class.':hover .icon' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->service_card_class.':hover .icon svg' => 'fill: {{VALUE}}',
				], 
			]
		);

		$this->add_responsive_control(
			'icon_width_hover',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:hover' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size_hover',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:hover i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:hover svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_icon_class. ' .icon:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.' .icon:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->service_card_icon_class. ' .icon:hover:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_icon_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_icon_class . ' .icon:hover',
			]
		);

		$this->end_controls_tab();  
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Subtitle Settings
		$this->start_controls_section(
			'service_heading_subtitle',
			[
				'label' => __( 'Subtitle', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' =>[
					'template_style' =>['layout_10'],
				]
			]
		);

        $this->start_controls_tabs( 'card_heading_sub_tabs' );

		$this->start_controls_tab(
			'card_heading_subtitle_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_control(
			'card_heading_subtitle_color',
			[
				'label'     => __( 'Subtitle Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_subtitle_typography',
				'label'    => ' Subtitle Typography',
				'selector' => '{{WRAPPER}} .'.$this->service_subtitle, 
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_subtitle_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_subtitle,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_subtitle_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_subtitle,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_subtitle_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_subtitle_hover_color',
			[
				'label'     => __( 'Subtitle Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class.':hover .'.$this->service_subtitle => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_subtitle_hover_typography',
				'label'    => ' Subtitle Typography',
				'selector' => '{{WRAPPER}}.'.$this->service_subtitle.':hover',
			]
		);
 
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_subtitle_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_subtitle.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_subtitle_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_subtitle.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_subtitle_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_subtitle.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Title Settings
		$this->start_controls_section(
			'service_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class => 'text-align: {{VALUE}};',
				],
				'condition' =>[
					'template_style!' =>['layout_10'],
				]
			]
		);

        $this->start_controls_tabs( 'card_heading_tabs' );

		$this->start_controls_tab(
			'card_heading_title_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_class.' h3' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Heading Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_heading_class,
			]
		);
		
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_heading_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_heading_class,
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_title_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Heading Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_class.':hover h3' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_heading_class.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_title_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_heading_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_title_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_heading_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_title_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_heading_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Description Settings
		$this->start_controls_section(
			'service_description',
			[
				'label' => __( 'Description Format', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						]
					]
				]
			]
		);

		$this->add_responsive_control(
			'card_heading_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'card_heading_description_tabs' );

		$this->start_controls_tab(
			'card_heading_description_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		
		$this->add_control(
			'card_heading_description_color',
			[
				'label'     => __( 'Description Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_description_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_description_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_description_class,
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_description_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_description_color_hover',
			[
				'label'     => __( 'Description Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_class.':hover .'.$this->service_card_description_class.'.text' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography_hover',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_description_class.':hover',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_heading_description_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_description_class.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_description_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_description_class.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_text_shadow_control(
			$this,
			[
				'key'      => 'card_heading_description_text_shadow_hover',
				'label'    => 'Text Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_description_class.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		// Service Button Settings
		$this->start_controls_section(
			'service_button_settings',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_read_more_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class => 'text-align: {{VALUE}};',
				],
			]
		); 
		$this->start_controls_tabs( 'card_heading_read_more_tabs' );

		$this->start_controls_tab(
			'card_heading_read_more_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		); 
		$this->add_control(
			'card_heading_read_more_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_read_more_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more' => 'background-color: {{VALUE}}', 
					'{{WRAPPER}}  .'.$this->service_card_class.':after' => 'background-color: {{VALUE}}', 
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'card_heading_read_more_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more',
				'condition' => [
					'template_style!' => ['layout_6','layout_7','layout_8',],
				],
			]
		);
		$this->add_responsive_control(
			'btn_icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_class.' .more i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_6','layout_7','layout_8',],
				],
			
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_read_more_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_read_more_class.' .more',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_read_more_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_heading_read_more_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_read_more_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_control(
			'card_heading_read_more_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->service_card_class.':hover .more' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->service_card_class.':hover .more i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_read_more_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_class.':hover .more' => 'background-color: {{VALUE}}', 
				],
			]
		); 

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'card_heading_read_more_hover_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more:hover',
				'condition' => [
					'template_style!' => ['layout_6','layout_7','layout_8',],
				],
			]
		);
		$this->add_responsive_control(
			'btn_icon_size_hover',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->service_card_class.' .more:hover i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_read_more_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->service_card_read_more_class.' .more'.':hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_read_more_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more'.':hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_padding_hover',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more'.':hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_margin_hover',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->service_card_read_more_class.' .more'.':hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_heading_read_more_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->service_card_read_more_class.' .more'.':hover',
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();  
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$show_image = $settings['show_image'];
		$show_icon = $settings['show_icon'];
		$show_title = $settings['show_title'];
		$show_description = $settings['show_description'];
		$show_link = $settings['show_link'];

		$title = $settings['card_title'];
		$subtitle = $settings['card_subtitle'];
		$description = $settings['card_description'];
		$card_icon = $settings['card_icon'];
		$link_text = $settings['card_link_text'];
		$link_button_icon = $settings['link_button_icon'];
		$link_button_position = $settings['link_button_position'];
		$link = $settings['card_link']['url'];
		$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : '';

		$template_style = $settings['template_style'];

		if ( ($template_style == 'layout_2') ||($template_style == 'layout_5') ||($template_style == 'layout_7') ||($template_style == 'layout_9') ) {
			$image_url = $settings['card_image']['url'];
		}

		$template_path = ENNOVA_PATH . 'inc/templates/service/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
			case 'layout_3':
				require $template_path. 'layout-3.php';
				break;
			case 'layout_4':
				require $template_path. 'layout-4.php';
				break;
			case 'layout_5':
				require $template_path. 'layout-5.php';
				break;
			case 'layout_6':
				require $template_path. 'layout-6.php';
				break;
			case 'layout_7':
				require $template_path. 'layout-7.php';
				break;
			case 'layout_8':
				require $template_path. 'layout-8.php';
				break;
			case 'layout_9':
				require $template_path. 'layout-9.php';
				break;
			case 'layout_10':
				require $template_path. 'layout-10.php';
				break;
			default:
				require $template_path. 'layout-1.php';
				break;
		}
	}
}