<?php
if (
	! function_exists( 'ennova_is_free_active' )
) {
	function ennova_is_free_active() {
		return is_plugin_active('ennova-addons/ennova-addons.php');
	}
}

if (
	! function_exists( 'ennova_show_disable_free_notice' )
) {
	function ennova_show_disable_free_notice() {
		$deactivate_url = wp_nonce_url( self_admin_url( 'plugins.php?action=deactivate&plugin=ennova-addons/ennova-addons.php' ), 'deactivate-plugin_ennova-addons/ennova-addons.php' );
		$classnames = '';

		?>
			<div class="notice notice-info is-dismissible <?php echo $classnames ?>">
			<p><?php esc_html_e('You have Ennova Pro installed you can disable and delete the free plugin.','ennova-addons'); ?>
				<a href="<?php echo esc_url( $deactivate_url ); ?>" class="button-primary">
					<?php esc_html_e('Deactivate free plugin','ennova-addons'); ?></a>
			</p>
			</div>
		<?php
	}
}

if (
	! function_exists( 'ennova_get_post_status' )
) {
	function ennova_get_post_status() {
		 $post_statuses       = [];
		$post_statuses['any'] = esc_html__( 'Any', 'ennova-addons' );
		$post_statuses        = get_post_statuses();
		return $post_statuses;
	}
}
if ( ! function_exists( 'ennova_get_product_types' ) ) {
	function ennova_get_product_types() {
		$product_types_lists = wc_get_product_types();
		return $product_types_lists;
	}
}
if ( ! function_exists( 'ennova_get_attachment_alt' ) ) {
	function ennova_get_attachment_alt( $attachment_id ) {
		if ( ! $attachment_id ) {
			return '';
		}

		$attachment = get_post( $attachment_id );
		if ( ! $attachment ) {
			return '';
		}

		$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		if ( ! $alt ) {
			$alt = $attachment->post_excerpt;
			if ( ! $alt ) {
				$alt = $attachment->post_title;
			}
		}
		return trim( wp_strip_all_tags( $alt ) );
	}
}
function ennova_display_product_rating( $average, $rating_count, $id ) {
	if ( 0 === $average ) {
		$html  = '<div class="star-rating">';
		$html .= wc_get_star_rating_html( $average, $rating_count );
		$html .= '</div>';
		return $html;
	} else {
		return wc_get_rating_html( $average, $rating_count );
	}
}

function ennova_get_categories() {
	$categories = get_categories([
		"hide_empty" => 0,
		"type"      => "post",
		"orderby"   => "name",
		"order"     => "ASC"
		]
	);

	$cat = [];

	foreach( $categories as $category ) {
		$cat[$category->term_id] = $category->name;
	}

	return $cat;
}


function ennova_get_tags() {
	$tags = get_tags(array(
			'hide_empty' => false
	));

	$tgs = [];

	foreach( $tags as $tag ) {
		$tgs[$tag->slug] = $tag->name;
	}

	return $tgs;
}


function ennova_get_product_category() {
	$categories = get_categories(
		[
			'hide_empty' => 0,
			// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
			//'exclude'  =>  1,
			'taxonomy'   => 'product_cat', // mention taxonomy here.
		]
	);

	$category_lists = [];

	foreach ( $categories as $category ) {
		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
		// $category_lists[$category->term_id] = $category->name;
		$category_lists[ $category->name ] = $category->name . ' (' . $category->count . ')';
	}

	if ( count( $category_lists ) > 0 ) {
		return $category_lists;
	}

	return false;
}


function ennova_get_all_category() {
	$categories = get_categories(
		[
			'hide_empty' => 0,
			// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
			//'exclude'  =>  1,
			'taxonomy'   => 'product_cat', // mention taxonomy here.
		]
	);

	if ( count( $categories ) > 0 ) {
		return $categories;
	}

	return false;
}

/** Get Woocommerce Categories */
if ( class_exists( 'woocommerce' ) ) {
	
	if (!function_exists('ennova_get_woo_categories')) {
		function ennova_get_woo_categories() {
			$terms = get_terms(array(
				'taxonomy' => 'product_cat',
				'hide_empty' => false,
			));
	
			$term_list = [];
	
			foreach ($terms as $term) {
				$term_list[$term->term_id] = $term->name;
			}
	
			return $term_list;
		}
	}

	function ennova_get_product_tags() {
		$terms      = get_terms( 'product_tag' );
		$term_array = [];
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$term_array[ $term->slug ] = $term->name;
			}
			return $term_array;
		}
		return false;
	}

	function woocommerceCategorySlug( $id ){
		$term = get_term_by('id', $id, 'product_cat', 'ARRAY_A');
		return $term['slug'];
	}

}




function get_category_details_by_name( $name ) {
	$slug       = '';
	$id         = '';
	$categories = ennova_get_all_category();
	foreach ( $categories as $category ) {
		if ( $name === $category->name ) {
			$slug = $category->slug;
			$id   = $category->cat_ID;
		}
	}

	return [
		'slug' => $slug,
		'id'   => $id,
	];
}
function get_placeholder_image_src() {
	$placeholder_image = ELEMENTOR_ASSETS_URL . 'images/placeholder.png';
	$placeholder_image = apply_filters( 'elementor/utils/get_placeholder_image_src', $placeholder_image );
	return $placeholder_image;
}

function ennova_get_all_authors() {
    $args = array(
        'role__in'     => array('author', 'administrator'),
        'orderby'      => 'display_name',
        'order'        => 'ASC',
        'number'       => null,
        'fields'       => 'all',
    );
    $authors = get_users( $args );
    $author_list = array();

    foreach ( $authors as $author ) {
        $author_list[$author->ID] = $author->display_name;
    }

    return $author_list;
}

function in_multi_array($needle, $haystack) {
    foreach ($haystack as $item) {
        if (is_array($item) || is_object($item)) {
            if (in_multi_array($needle, $item)) {
                return true;
            }
        } else {
			// print_r($item);
            if ($item == $needle) {
				
                return true;
            }
        }
    }
    return false;
}