$slug = 'title';
$this->start_controls_tabs( $slug.'_style_tabs' );

$this->start_controls_tab(
    $slug.'_normal_style',
    [
        'label' => __( 'Normal', 'ennova-addons' ),

    ]
);

$this->end_controls_tab();

$this->start_controls_tab(
    $slug.'_hover_style',
    [
        'label' => __( 'Hover', 'ennova-addons' ),

    ]
);

$this->end_controls_tab();

$this->end_controls_tabs();
