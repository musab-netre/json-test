<div class="ennova-heading-wrapper heading_two <?php echo esc_attr($this->heading_card_class); ?>">

	<div class="heading-inner <?php echo esc_attr($this->heading_card_inner_class); ?>">

			<<?php echo esc_attr($heading_html_tag); ?> class="title">
			<a href="<?php echo esc_url($link); ?>"<?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>> <?php echo esc_html($title); ?></a>
			</<?php echo esc_attr($heading_html_tag); ?> >
	</div>
</div>