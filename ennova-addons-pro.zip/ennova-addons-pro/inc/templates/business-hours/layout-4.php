<div class="business_hours_four <?php echo esc_attr($this->business_hours_card_class); ?>">

	
	<?php
	if ( $show_header_title === 'yes' ) {
		?>
	<div class="header_content <?php echo esc_attr($this->business_hours_header_class); ?>">
		<h3 class="title <?php echo esc_attr($this->business_hours_header_title_class); ?>"><?php echo esc_html($header_title); ?></h3>
	</div>
		<?php
	}
	?>
	<div class="feature_content <?php echo esc_attr($this->business_hours_feature_class) ?>">
		<?php
		if ( $show_feature === 'yes' ) {
			
			if (isset($business_hours_block) && !empty($business_hours_block))
			{
				foreach ($business_hours_block as $key => $title_block)
				{
					$text_block = $title_block['business_hours_text'];
					
					?>
					<div class=" feature_list <?php echo esc_attr($this->business_hours_feature_inner_class); ?>" > 
						<div class="feature_title"><?php echo esc_html($title_block['business_hours_title']);?></div>
						<div class="feature_hours"><?php echo esc_html($title_block['business_hours_text']);?></div>
					</div>
					<div class="separator">
						<div class="list_separator <?php echo esc_attr($this->business_hours_feature_separator_class); ?>"></div>
					</div>
					<?php
				}
			} 
		}
		?>
	</div>
	<?php
	if ( $show_footer_text === 'yes' ) {
		?>
		<div class="footer_content <?php echo esc_attr($this->business_hours_footer_class); ?>">
			<p class="footer_text <?php echo esc_attr($this->business_hours_footer_text_class); ?>"><?php echo esc_html($footer_text); ?></p>
		</div>
		<?php
	}
	?>
</div>