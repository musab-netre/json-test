<?php

if ( !$products ) {
	$products = wc_get_products( $args );
}

$first_tab_id = '';

if($swiper_div_tabs && count($swiper_div_tabs) > 0) {
	$first_tab_id = reset($swiper_div_tabs);
}

$arr =  '';
echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . 'compare-cat="'.$arr.'">';

$class = 'ennova_product_wrapper ennova-product-grid-wrapper '. 'ennova-'.$this->get_id(). ' ' . $category_class . ' ';
if ( $counter === 0  ) {
	$class .= " category-active";
} else {
	$class .= " category-hide";
}

if ( $hide === true ) {
	$class .= ' ennova_hide';
}

if ( $products ) {?>
	<div
	class="<?php echo esc_attr($class); ?>"
	data-first_tab_id="<?php echo esc_attr($first_tab_id); ?>">
	<?php
		foreach ($products as $product) {
			$product_id = $product->get_id();
			$terms = get_the_terms( $product_id , 'product_cat' );
			if ($only_on_sale && !in_array($product_id, $on_sales_ids, true)) {
				continue;
			}

			if ( $only_best_sale && $product->get_total_sales() < $best_sale_count) {
				continue;
			}

			if ( $is_best_rated && $product->get_average_rating() < $best_rated_count ) {
				continue;
			}

			$thumbnail_id = $product->get_image_id();

			?>
				<div class="ennova-single-grid-product <?php echo 'ennova-tabs-'.$this->get_id() ?>
				<?php
					if ( ! $thumbnail_id ) {
						echo esc_attr('ennova-no-grid-product-image');}
					?>"
					data-swiper_div_tabs="<?php
					if($swiper_div_tabs && count($swiper_div_tabs) > 0) {
					if ( !empty( $terms ) ) {
						foreach ( $terms as $term ) {
							if ( array_key_exists($term->term_id, $swiper_div_tabs)){
								echo esc_attr($swiper_div_tabs[$term->term_id]);
							}
						}
					}
				}
			?>">
<?php

	$template_style = $this->get_settings_for_display()['template_style'];
	$template_path = ENNOVA_PATH . 'inc/templates/product-items/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
			case 'layout_3':
				require $template_path. 'layout-3.php';
				break;
			case 'layout_4':
				require $template_path. 'layout-4.php';
				break;
			case 'layout_5':
				require $template_path. 'layout-5.php';
				break;
			default:
				require $template_path. 'layout-1.php';
				break;
		} ?>
			</div>

			<?php

		}
	?>
	</div>
	<?php
} else {
	// echo "No Products Found!";
}