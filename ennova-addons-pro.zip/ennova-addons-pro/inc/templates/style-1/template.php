<?php
// phpcs:ignoreFile
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . ' >';
$class = 'ennova_product_wrapper ennova_slider_wrapper '. 'ennova-'.$this->get_id(). ' ' . $category_class . ' ';
if ( $counter === 0  ) {
	$class .= " category-active";
} else {
	$class .= " category-hide";
}

if ( $hide === true ) {
	$class .= ' ennova_hide';
}

$first_tab_id = '';

if($swiper_div_tabs && count($swiper_div_tabs) > 0) {
	$first_tab_id = reset($swiper_div_tabs);
}

echo '<div
		class="' . $class .'"
		id="' . esc_attr( $element_id ) . '"
		data-slide-to-show="' . esc_html( $slide_to_show ) . '"
		data-slide-to-show-mobile="' . esc_html( $slide_to_show_mobile ) . '"
		data-slide-to-show-tablet="' . esc_html( $slide_to_show_tablet ) . '"
		data-slides-to-scroll="' . esc_html( $slides_to_scroll ) . '"
		data-slides-to-scroll-mobile="' . esc_html( $slides_to_scroll_mobile ) . '"
		data-slides-to-scroll-tablet="' . esc_html( $slides_to_scroll_tablet ) . '"
		data-slides-space-between="' . esc_html( $slides_space_between ) . '"
		data-slides-space-between-mobile="' . esc_html( $slides_space_between_mobile ) . '"
		data-slides-space-between-tablet="' . esc_html( $slides_space_between_tablet ) . '"
		data-autoplay="' . esc_html( $autoplay ) . '"
		data-autoplay-speed="' . esc_html( $autoplay_speed ) . '"
		data-transition_between_slides="' . esc_html( $transition_between_slides ) . '"
		data-loop="' . esc_html( $loop ) . '"
		data-mousewheel="' . esc_html( $mousewheel ) . '"
		data-keyboard_control="' . esc_html( $keyboard_control ) . '"
		data-clickable="' . esc_html( $dot_clickable ) . '"
		data-first_tab_id="'.$first_tab_id.'"
	>';

$swiper_container_class = 'swiper swiper-container swiper-' . $this->get_id();
if (
			$products
		) {
			?>
			<!-- Slider main container -->
			<div class="<?php echo esc_html( $swiper_container_class ); ?>">
				<?php
				if ( $title && $template_style === 'default' ) {
					echo "<h2 class='ennova-slider-title'>" . $title . '</h2>';
				}
				?>
				<!-- Additional required wrapper -->
				<div class="swiper-wrapper">
				<?php
foreach ($products as $product) {
	$product_id = $product->get_id();
	$terms = get_the_terms( $product_id , 'product_cat' );

	if ($only_on_sale && !in_array($product_id, $on_sales_ids, true)) {
		continue;
	}

	if ( $only_best_sale && $product->get_total_sales() < $best_sale_count) {
		continue;
	}

	if ( $is_best_rated && $product->get_average_rating() < $best_rated_count ) {
		continue;
	}

	$thumbnail_id = $product->get_image_id(); ?>
	<div class="swiper-slide <?php echo 'ennova-tabs-'.$this->get_id() ?>" data-swiper_div_tabs="<?php
		if($swiper_div_tabs && count($swiper_div_tabs) > 0) {
			if ( !empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( array_key_exists($term->term_id, $swiper_div_tabs)){
						echo esc_attr($swiper_div_tabs[$term->term_id]);
					}
				}
			}
		}
	?>">
	<?php 
		$template_path = ENNOVA_PATH . 'inc/templates/product-items/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
			case 'layout_3':
				require $template_path. 'layout-3.php';
				break;
			case 'layout_4':
				require $template_path. 'layout-4.php';
				break;
			case 'layout_5':
				require $template_path. 'layout-5.php';
				break;
			default:
				require $template_path. 'layout-1.php';
				break;
		} ?>
	 
	</div>
<?php
}?>
</div>
				<?php
				if ( $display_dots === 'yes' ) {
					?>
					<!-- If we need pagination -->
					<div class="swiper-pagination"></div>
					<?php
				}
				?>
				<?php
				if ( $show_navigation_arrow === 'yes' ) {
					?>
					<!-- If we need navigation buttons -->
					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
					<?php
				}
				?>
				<?php
				if ( $show_scroll_bar === 'yes' ) {
					?>
					<!-- If we need scrollbar -->
					<div class="swiper-scrollbar"></div>
					<?php
				}
				?>
			</div>
			<?php
		} else {
			// echo 'No Products Found!';
		}
		echo '</div>';
		echo '</div>';