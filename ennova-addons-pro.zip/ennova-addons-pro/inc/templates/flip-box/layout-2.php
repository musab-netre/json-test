<div class="flip-card two <?php echo esc_attr( $this->flip_card_class); if($flip_3d_effect == 'yes') { echo esc_attr('ennova-flip-box-3d'); } ?>">
	<div class="flip-card-inner">
		<div class="flip-card-front <?php echo esc_attr($this->flip_front_class); ?>" >
			<div class="flip-img">
				<img src="<?php echo esc_url($front_image_url) ?>" alt="<?php echo esc_attr($front_card_title) ?>">
			</div>
			<?php if ( $show_icon === 'yes' ) { ?>
				<div class="enn-icon <?php echo esc_attr($this->flip_icon_class); ?>">
					<?php \Elementor\Icons_Manager::render_icon( $front_card_icon, [ 'aria-hidden' => 'true' ] ); ?>
				</div> 
			<?php } ?>
			<?php if ( $show_title === 'yes' ) { ?>
				<div class="enn-heading">
				<h3 class="title <?php echo esc_attr($this->flip_title_class); ?>"><?php echo esc_html($front_card_title); ?></h3> 
				</div>
			<?php } ?>
			<?php if ( $show_desc === 'yes' ) { ?>
				<div class="enn-description">
				<p class="description <?php echo esc_attr($this->flip_desc_class); ?>"><?php echo esc_html($front_card_description); ?></p> 
				</div>
			<?php } ?>
		</div>
		<div class="flip-card-back <?php echo esc_attr($this->flip_back_class); ?>" style="background-image: url('<?php echo esc_url($front_image_url) ?>');"> 
			<?php if ( $show_btn === 'yes' ) { ?>
			<a
				class="enn-btn <?php echo esc_attr($this->flip_btn_class); ?> <?php echo $back_link_button_position === 'before' ? 'ennova-no-flex': '' ?>"
				href="<?php echo esc_url($back_link); ?>"
				<?php echo $back_target ?>
				<?php echo $back_nofollow ?>>
				<?php 
					if ($back_link_button_position === 'before') {
						\Elementor\Icons_Manager::render_icon( $back_link_button_icon, [ 'aria-hidden' => 'true' ] );
					}
				?>
				<span><?php echo esc_html($back_link_text) ?></span>
				<?php 
					if ($back_link_button_position === 'after') {
						\Elementor\Icons_Manager::render_icon( $back_link_button_icon, [ 'aria-hidden' => 'true' ] );
					}
				?>
			</a>
			<?php } ?>
		</div>
	</div>
</div>