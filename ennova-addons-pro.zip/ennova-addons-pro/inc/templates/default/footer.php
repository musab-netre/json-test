<?php
do_action( '_ennova_foot_' );
wp_footer(); ?>
</body>
</html>