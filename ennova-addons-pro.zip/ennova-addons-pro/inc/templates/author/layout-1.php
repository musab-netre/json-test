<div class="enn-author-item one <?php echo esc_attr($this->author_card_class) ?>">
	<?php
	if ( $show_image === 'yes' ) {
		?>
			<div class="enn-author-thumbnail <?php echo esc_attr($this->author_card_image_class) ?>">
			<a href="<?php echo esc_url($card_link) ?>" class="enn-img">
				<img src="<?php echo esc_url($image_url) ?>" alt="<?php echo esc_attr($title) ?>">
			</a>
			<?php
				if ( $show_label === 'yes' ) {
					?>
						<div class="enn-label <?php echo esc_attr($this->author_card_label_class) ?>">
							<span><?php echo esc_html($label) ?></span>
						</div>
					<?php
				}
			?>                
			</div>
		<?php
	}
	?>                
	<div class="enn-content <?php echo esc_attr($this->author_card_inner_class) ?>">
		<div class="enn-author-title">
			<?php
			if ( $show_title === 'yes' ) {
				?>
					<h2 class="title <?php echo esc_attr($this->author_card_heading_class); ?>">
					<a href="<?php echo esc_url($card_link); ?>"><?php echo esc_html($title); ?></a></h2>
				<?php
			}
			?>
			<?php
			if ( $show_description === 'yes' ) {
				?>
	<span class="description <?php echo esc_attr($this->author_card_description_class); ?>"><?php echo esc_html($description); ?></span>
				<?php
			} 
			?>
		</div>
			<?php
		if ( $show_link === 'yes' ) {
			?>
			<div class="enn-social-icons <?php echo esc_attr($this->author_social_icon_class) ?>">
				<?php
				foreach ($socials as $key => $socials) { 
				$author_social_link = $socials['author_social_link']['url'];
				$target = $socials['author_social_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $socials['author_social_link']['nofollow'] ? ' rel="nofollow"' : '';
				if ($key === 4 ) { break; }?>
				<a href="<?php echo esc_url( $author_social_link ); ?>" <?php echo  $target ?> <?php echo  $nofollow ?>> 
				<?php \Elementor\Icons_Manager::render_icon( $socials['author_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>                            
				</a>
				<?php
			} ?>
			</div>
			<?php
		}
		?>
	</div>
</div>