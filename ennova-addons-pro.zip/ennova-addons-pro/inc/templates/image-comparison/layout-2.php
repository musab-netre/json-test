<div class="image-comparison two <?php echo esc_attr($this->image_compare_class); ?>" tigger="<?php echo esc_attr($tigger_style); ?>">
	<div class="images-container juxtapose" data-mode="vertical">
		<img class="before-image" src="<?php echo esc_url($after_image_url); ?>" alt="before" >
		<img class="after-image" src="<?php echo esc_url($before_image_url); ?>" alt="after" >
	</div>
</div>