<div class="ennova-team-wrapper team_eight <?php echo esc_attr($this->team_card_class); ?>">
	<div class="team-inner <?php echo esc_attr($this->team_card_inner_class); ?>">
		<div class="top-content <?php echo esc_attr($this->team_card_top_content_class); ?>">
			  <?php
			if ( $show_image === 'yes' ) {
			?>
				<div class="top_img <?php echo esc_attr($this->team_card_image_class); ?>">
					<img class="img-fluid" src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($title); ?>">
				</div>
			<?php
			}
			?>
			<div class="overlay">
			<?php if ( $show_icon === 'yes' ) {
							?>
							<div class="<?php echo esc_attr($this->team_card_icon_class); ?>">
							<div class="social-icon"><?php
							if( $this->class_name == 'ENNOVATeam'){ 
								if (isset($social_icons_block) && !empty($social_icons_block))
								{
								foreach ($social_icons_block as $key => $icon_block)
									{
									$target = $icon_block['social_icon_link']['is_external'] ? ' target="_blank"' : '';
									$nofollow = $icon_block['social_icon_link']['nofollow'] ? ' rel="nofollow"' : ''; ?>
									<a href="<?php echo esc_url($icon_block['social_icon_link']['url']) ?>" <?php echo $target; ?> <?php echo $nofollow; ?>>
									<?php \Elementor\Icons_Manager::render_icon($icon_block['social_icon'], ['aria-hidden' => 'true']); ?>
									</a>
									<?php
									}
								} 
							} elseif ( $this->class_name == 'ENNOVATeamCarousel') { 
								if($link_one != '') { ?>
									<a href="<?php echo esc_url($link_one) ?>"<?php echo $target_one . $nofollow_one; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_one, ['aria-hidden' => 'true']); ?>
									</a>	
								<?php }	if($link_two != '') { ?>						
									<a href="<?php echo esc_url($link_two) ?>"<?php echo $target_two . $nofollow_two; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_two, ['aria-hidden' => 'true']); ?>
									</a>		
								<?php }	if($link_three != '') { ?>								
									<a href="<?php echo esc_url($link_three) ?>"<?php echo $target_three . $nofollow_three; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_three, ['aria-hidden' => 'true']); ?>
									</a>		
								<?php }	if($link_four != '') { ?>								
									<a href="<?php echo esc_url($link_four) ?>"<?php echo $target_four . $nofollow_four; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_four, ['aria-hidden' => 'true']); ?>
									</a>		
								<?php }	if($link_five != '') { ?>								
									<a href="<?php echo esc_url($link_five) ?>"<?php echo $target_five . $nofollow_five; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_five, ['aria-hidden' => 'true']); ?>
									</a>	
								<?php }	if($link_six != '') { ?>									
									<a href="<?php echo esc_url($link_six) ?>"<?php echo $target_six . $nofollow_six; ?>>
										<?php \Elementor\Icons_Manager::render_icon($icon_six, ['aria-hidden' => 'true']); ?>
									</a>	
								<?php }	
							}
							?>
							</div>
							</div>
							<?php       
						} 
					  ?>
			</div>
		</div>
		<div class="bottom-content <?php echo esc_attr($this->team_card_bottom_content_class) ?>">
			<div class="heading">
				<?php
				if ( $show_title === 'yes' ) {
					?>
						<h3 class="title <?php echo esc_attr($this->team_card_heading_class); ?>"><?php echo esc_html($title); ?></h3>
					<?php
				}
				?>
				<?php
				if ( $show_designation === 'yes' ) {
					?>
					<p class="category <?php echo esc_attr($this->team_card_designation_class); ?>"><?php echo esc_html($designation); ?></p>
				<?php
				}
				?>
			</div>
		</div>
	</div>
</div>