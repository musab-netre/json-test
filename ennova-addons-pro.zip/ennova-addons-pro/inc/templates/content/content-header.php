<header id="masthead" class="ennova-site-header">
	<?php the_content(); ?>
</header>
