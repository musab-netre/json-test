<footer id="mastfooter" class="ennova-site-footer">
	<div class="ennova-footer-inner">
		<?php the_content(); ?>
	</div>
</footer>