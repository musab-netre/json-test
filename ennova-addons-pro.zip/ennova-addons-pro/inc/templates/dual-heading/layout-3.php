<div class="heading_three <?php echo esc_attr($this->heading_card_class); ?>">
	<?php if($show_heading == 'yes'){ ?>
	<<?php echo $heading_html_tag ?> class="title">
		<a href="<?php echo esc_url($link); ?>" <?php echo $target ?> <?php echo $nofollow ?> >
		<?php echo esc_html($before_title); ?> <span><?php echo esc_html($title); ?></span> <?php echo esc_html($after_title); ?> 
		</a>
	</<?php echo $heading_html_tag; ?>>
	<?php } ?>
	<?php if($show_subtext == 'yes') { ?>
	<div class="text"><?php echo __($subtext, 'ennova-addons'); ?></div>
	<?php } ?>
</div>