<div class="enn-price-menu seven <?php echo esc_attr($this->price_menu_card_class); ?>">
    <div class="enn-inner">
		<?php if ( $show_image === 'yes' ) {
			?>
				<div class="enn-menu-image <?php echo esc_attr($this->price_menu_card_image_class); ?>">
					<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($title); ?>" class="img-cover" >
					<?php
					if ( $show_lebal === 'yes' ) {
						?>
							<span class="tag <?php echo esc_attr($this->price_lebal); ?>"><?php echo esc_html($card_lebal);?></span>
						<?php
					} ?>
				</div>
			<?php
			}
		?>
        <div class="enn-price-content">
            <div class="enn-menu-heading">
			<?php
				if ( $show_title === 'yes' ) {
					?>
						<h4 class="enn-title <?php echo esc_attr($this->price_menu_card_heading_class); ?>"><a href="<?php echo esc_url($btn_link); ?>"<?php echo $btn_target ?><?php echo $btn_nofollow ?>>
						<?php echo esc_html($title); ?></a></h4>
					<?php
				}
			?>
			<?php
				if ( $show_description === 'yes' ) {
				?>
					<p class="description <?php echo esc_attr($this->price_desc); ?>"><?php echo esc_html($description); ?></p>
				<?php
				}
			?>
            </div>
			<?php
			if ( $show_star === 'yes' ) {
				?>
					<div class="<?php echo esc_attr($this->price_star); ?>">
						<?php 
							if(is_numeric( $rating ) && floor( $rating ) != $rating){
								?><div class="star-rating"><?php
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_prev_rating){
                                        ?><i class="fas fa-star"></i><?php
                                    }else if($i <= $round_next_rating){
                                        ?><i class="fas fa-star-half-alt"></i><?php
                                    }else{
										?><i class="far fa-star"></i><?php
									}
                                }
								?></div><?php
                            }elseif($rating == 0 || $rating == '0' ){
								?><div class="star-rating"><?php
                                $num_iterations = 5;
                                for ($i = 1; $i <= $num_iterations; $i++) {
                                    ?><i class="far fa-star"></i><?php
                                }
								?></div><?php
                            }else{
								?><div class="star-rating"><?php
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_next_rating){
                                        ?><i class="fas fa-star"></i><?php
                                    }else{
                                        ?><i class="far fa-star"></i><?php
                                    }
                                }
								?></div><?php
                            } ?> 
					</div>
				<?php
				}
			?>
			<div class="enn-price-bottom">
				<?php
				if ( $show_link === 'yes' ) {
					?>
					<div class="enn-price-menu-btn <?php echo esc_attr($this->price_btn); ?>">
						<a
							class="more<?php echo $btn_icon_position === 'before' ? ' ennova-no-flex': '' ?>"
							href="<?php echo esc_url($btn_link); ?>"
							<?php echo $btn_target ?>
							<?php echo $btn_nofollow ?>>
							<?php 
								if ($btn_icon_position === 'before') {
									\Elementor\Icons_Manager::render_icon( $btn_button_icon, [ 'aria-hidden' => 'true' ] );
								}
							?>
							<?php echo esc_html($btn_text); ?>
							<?php 
								if ($btn_icon_position === 'after') {
									\Elementor\Icons_Manager::render_icon( $btn_button_icon, [ 'aria-hidden' => 'true' ] );
								}
							?>
						</a>
					</div>
					<?php
					}
				if ( $show_item === 'yes' ) { ?>
					<span class="amount <?php echo esc_attr($this->price_amount); ?>"><?php echo esc_html($amount); ?></span>
				<?php } ?>
			</div>
        </div>
    </div>
</div>
