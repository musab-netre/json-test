<div class="enn-price-menu three <?php echo esc_attr($this->price_menu_card_class); ?>">
    <div class="enn-inner">
		<?php
		if ( $show_lebal === 'yes' ) {
			?>
				<span class="tag <?php echo esc_attr($this->price_lebal); ?>"><?php echo esc_html($card_lebal);?></span>
			<?php
		}
		?>
		<?php
			if ( $show_image === 'yes' ) {
		?>
        <div class="enn-menu-image <?php echo esc_attr($this->price_menu_card_image_class); ?>">
            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($title); ?>" class="img-cover" >
        </div>
		<?php
			}
		?>
        <span class="amount <?php echo esc_attr($this->price_amount); ?>"><?php echo esc_html($amount); ?></span>
        <div class="enn-price-content">
            <div class="enn-menu-heading">
			<?php
			if ( $show_title === 'yes' ) {
			?>
                <h4 class="enn-title <?php echo esc_attr($this->price_menu_card_heading_class); ?>"><a href="<?php echo esc_url($link); ?>"<?php echo $target ?><?php echo $nofollow ?>>
				<?php echo esc_html($title); ?></a></h4>
			<?php
			}
			?>
                <span class="enn-title-connector <?php echo esc_attr($this->price_menu_feature_separator_class); ?>"></span>
            </div>
			<ul>
			<?php
			if ( $show_item === 'yes' ) {
			if (isset($items_one_title_block) && !empty($items_one_title_block)){
						foreach ($items_one_title_block as $key => $text_block){
			?>
                <li class="<?php echo esc_attr($this->price_feature); ?>"> 
					<span class="enn-menu-text <?php echo esc_attr($this->price_text); ?>"><?php echo esc_html($text_block['items_one_title']);?></span>
				</li>
			<?php
            }}} 
			?>
			</ul>
        </div>
    </div>
</div>
