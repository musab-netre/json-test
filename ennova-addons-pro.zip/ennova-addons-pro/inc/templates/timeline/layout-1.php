<div class="enn-timeline-items">
	<span class="timeline-line <?php echo esc_attr($this->timeline_line) ?>"></span>
	<span class="timeline-inner-line <?php echo esc_attr($this->timeline_inner_line) ?>"></span>
	<?php
	if (isset($timeline_block) && !empty($timeline_block)) { 
		foreach ($timeline_block as $key => $content_block)
		{
			$date_block = $content_block['card_date'];
			$title_block = $content_block['card_title'];
			$subtitle_block = $content_block['card_subtitle'];
			$desc_block = $content_block['card_description'];
			$link_block = $content_block['card_link']['url']; 
			$target = $content_block['card_link']['is_external'] ? ' target="_blank"' : '';
			$nofollow = $content_block['card_link']['nofollow'] ? ' rel="nofollow"' : '';
			?>
			<div class="enn-timeline-item">
				<div class="timeline-dot <?php echo esc_attr($this->timeline_dot) ?>"></div>
				<?php
				if ( $show_date === 'yes' ) {
					?>
						<div class="timeline-date <?php echo esc_attr($this->timeline_card_date_class) ?>">
							<span><?php echo esc_html($date_block) ?></span>
						</div>
					<?php
				}
				?>
				<div class="enn-timeline-content <?php echo esc_attr($this->timeline_card_class) ?>">
				<?php
				if ( $show_subtitle === 'yes' ) {
					?>
						<div class="enn-subtitle <?php echo esc_attr($this->timeline_card_subtitle_class) ?>">
							<span><?php echo esc_html($subtitle_block) ?></span>
						</div>
					<?php
					}
				?>
				<?php
				if ( $show_title === 'yes' ) {
					?>
						<div class="heading">
							<h3 class="title <?php echo esc_attr($this->timeline_card_heading_class) ?>">
							<a href="<?php echo esc_url($link_block) ?>"<?php echo $target ?> <?php echo $nofollow ?>><?php echo esc_html($title_block) ?></a></h3>
						</div>
					<?php
				}
				?>
				<?php
				if ( $show_description === 'yes' ) {
					?>
						<div class="description <?php echo esc_attr($this->timeline_card_description_class) ?>">
							<span><?php echo esc_html($desc_block); ?></span>
						</div>
					<?php
				}
				?>
				</div>
			</div>
			<?php
		} 
	}
	?>
</div>