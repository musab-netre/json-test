<?php
if (isset($price_list_item) && !empty($price_list_item)) {
	foreach ($price_list_item as $key => $item) {
		$image_url = $item['card_image' ]['url'];
		$title = $item['card_title' ];
		$amount = $item['card_amount']; 
		$description = $item['card_description']; 
		?>
		<div class="enn-price-list four <?php echo esc_attr($this->price_list_card_class); ?>">
			<div class="enn-inner">
				<div class="enn-list-image <?php echo esc_attr($this->price_list_card_image_class); ?>">
					<img class="img-cover" src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($title); ?>">
					<?php
						if ( $show_amount === 'yes' ) {
							?>
						<span class="amount"><?php echo esc_html($amount); ?></span>
						<?php
						}
						?>
				</div>
				<div class="enn-price-content <?php echo esc_attr($this->price_card_inner_class); ?>">
					<div class="enn-list">
					<?php
						if ( $show_title === 'yes' ) {
							?>
							<h4 class="enn-title <?php echo esc_attr($this->price_list_card_heading_class); ?>"><?php echo esc_html($title);?></h4>
						<?php
						}
						?>
						<span class="enn-title-connector <?php echo esc_attr($this->price_list_feature_separator_class); ?>">
						</span>
					</div>

				<?php
				if ( $show_description === 'yes' ) {
						?>
							<p class="text <?php echo esc_attr($this->price_list_card_description_class); ?>"><?php echo esc_html($description); ?></p>
						<?php
					}
				?>
			</div>
		</div>
	</div>
	<?php
	}
}