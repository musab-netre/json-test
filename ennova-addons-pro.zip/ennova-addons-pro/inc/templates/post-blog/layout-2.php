<?php if($blog_design == 'card') { ?>
    <!-- blog card post -->
    <div class="enn-blog-post enn-card two <?php echo esc_attr($this->blog_card_class);?>" id="<?php get_the_ID() ?>">
        <?php
            if ($thumbnail_id) {
                echo '<div class="enn-blog-thumb md '.esc_attr($this->blog_img).'">' ;
                $image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src($thumbnail_id, $thumbnail_size_key, $params['settings']);
                echo sprintf('<img src="%s" title="%s" alt="%s"%s class="enn-link-div enn-back-img" />', esc_url($image_src), get_the_title($thumbnail_id), ennova_get_attachment_alt($thumbnail_id), '');
                echo '</div>' ;
            }
        ?>
        <article class="small <?php echo esc_attr($this->blog_inner) ;?>">
        <div class="enn-blog-category <?php echo $category_style;?> <?php echo esc_attr($this->blog_category) ;?>">
                <?php
                    if ( count($params['categories']) > 0 && $show_category === 'yes') {
                        foreach($params['categories'] as $category ) {
                            $category = (array) $category;
                            ?>
                                <a href="<?php echo get_category_link( $category['term_id'] ) ?>"><?php echo esc_html($category['name']); ?></a>
                            <?php
                        }
                    }
                    ?>
            </div>
            <div class="enn-blog-meta <?php echo esc_attr($this->blog_meta);?>">
                <?php
                    if( $show_author === 'yes' ) {
                        ?>
                            <span class="enn-author">
                                <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_avatar(get_the_author_meta( 'ID') , 150); ?><?php the_author(); ?></a>
                            </span>
                        <?php
                    }
                ?>
                <?php
                    if( $show_date === 'yes' ) {
                        ?>
                            <span class="enn-blog-date">
                                <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j'));  ?>" class="entry-date"><i class="far fa-clock"></i>
                                    <?php
                                        the_time('F j, Y');
                                    ?>
                                </a>
                            </span>
                        <?php
                    }
                ?>
                <?php
                    if ( $params['comments_count'] > 0 && $show_comments === 'yes') {
                            $text = 'Comment';
                            if ( $params['comments_count'] > 1 ) {
                                $text = 'Comments';
                            }
                        ?>
                            <span class="enn-comments-link"> <a href="<?php comments_link(); ?>"><i class="far fa-comments"></i><?php echo get_comments_number(). ' ' ?></a> </span>
                        <?php
                    }
                ?>
            </div>

            <?php
                if ( $show_title === 'yes' ) {
                    // title_html_tag
                    echo '<'.$title_html_tag.' class="title '.esc_attr($this->blog_title).'">';
                    if ( $params['title_length'] > 0 ) {
                        ?>
                            <a href="<?php echo esc_url(get_permalink()); ?>" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title(), $params['title_length'], '' ); ?></a>
                        <?php
                    }
                    echo '</'.$title_html_tag.'>';
                }
            ?>
            <?php
                if ( $params['excerpt_length'] > 0 ) {
                    ?>
                        <div class="discription <?php echo esc_attr($this->blog_desc);?>">
                    <?php
                    echo wp_trim_words( get_the_content(), $params['excerpt_length'], '' );
                    ?>
                        </div>
                    <?php
                }
            ?>
            <?php
                if( $show_read_more === 'yes' ) {
                    ?>
                        <div class="enn-more-link">
                        <a
                            class="enn_cta_btn <?php echo esc_attr($this->blog_btn) ;?> <?php echo $link_button_position === 'before' ? 'ennova-no-flex': '' ?>"
                            href="<?php the_permalink(); ?>" target="_blank" >
                            <?php 
                                if ($link_button_position === 'before') {
                                    \Elementor\Icons_Manager::render_icon( $link_button_icon, [ 'aria-hidden' => 'true' ] );
                                }
                            ?>
                            <?php echo esc_html($link_text) ?>
                            <?php 
                                if ($link_button_position === 'after') {
                                    \Elementor\Icons_Manager::render_icon( $link_button_icon, [ 'aria-hidden' => 'true' ] );
                                }
                            ?>
                        </a>
                        </div>
                    <?php
                }
            ?>
        </article>
    </div>
    <!-- /blog card post -->
<?php } elseif($blog_design == 'over') { ?>
    <!-- blog Overlay post -->
    <div class="enn-blog-post enn-overlay seven <?php echo esc_attr($this->blog_card_class) ;?>" id="<?php echo get_the_ID(); ?>">
        <?php
            $image_src = '';
            if ($thumbnail_id) {
                $image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src($thumbnail_id, $thumbnail_size_key, $params['settings']);
            }
            if ( $image_src === '' ) {
                ?>
                    <div class="enn-blog-post three lg enn-back-img bshre <?php echo esc_attr($this->blog_img);?>">
                <?php
            } else {
                $bg = "background-image: url(". esc_url($image_src) .");";
                ?>
                    <div class="enn-blog-post three lg enn-back-img bshre <?php echo esc_attr($this->blog_img);?>" style=" <?php echo $bg ?> ">
                <?php
            }
        ?>
        <a href="<?php echo esc_url(get_permalink()); ?>" class="enn-link-div"></a>
        <article class="inner <?php echo esc_attr($this->blog_inner) ;?>">
        <div class="enn-blog-category <?php echo esc_attr($category_style);?> <?php echo esc_attr($this->blog_category);?>">
                <?php
                    if ( count($params['categories']) > 0 && $show_category === 'yes') {
                        foreach($params['categories'] as $category ) {
                            $category = (array) $category;
                            ?>
                                <a href="<?php echo  get_category_link( $category['term_id'] ) ?>"><?php echo esc_html($category['name']) ?></a>
                            <?php
                        }
                    }
                    ?>
            </div>
            <?php
                if ( $show_title === 'yes' ) {
                    // title_html_tag
                    echo '<'.$title_html_tag.' class="title '.esc_attr($this->blog_title).'">';
                    if ( $params['title_length'] > 0 ) {
                        ?>
                            <a href="<?php echo esc_url(get_permalink()); ?>" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title(), $params['title_length'], '' ); ?></a>
                        <?php
                    }
                    echo '</'.$title_html_tag.'>';
                }
            ?>
            <div class="enn-blog-meta <?php echo esc_attr($this->blog_meta) ;?>">
                <?php
                    if( $show_author === 'yes' ) {
                        ?>
                            <span class="enn-author">
                                <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_avatar(get_the_author_meta( 'ID') , 150); ?><?php the_author(); ?></a>
                            </span>
                        <?php
                    }
                ?>
                <?php
                    if( $show_date === 'yes' ) {
                        ?>
                            <span class="enn-blog-date">
                                <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j'));  ?>" class="entry-date"><i class="far fa-clock"></i>
                                    <?php
                                        the_time('F j, Y');
                                    ?>
                                </a>
                            </span>
                        <?php
                    }
                ?>
                <?php
                    if ( $params['comments_count'] > 0 && $show_comments === 'yes') {
                            $text = 'Comment';
                            if ( $params['comments_count'] > 1 ) {
                                $text = 'Comments';
                            }
                        ?>
                            <span class="enn-comments-link"> <a href="<?php comments_link(); ?>"><i class="far fa-comments"></i><?php echo get_comments_number(). ' ' ?></a> </span>
                        <?php
                    }
                ?>
            </div>
        </article>
        </div>
    </div>
    <!-- /blog Overlay post -->
<?php }