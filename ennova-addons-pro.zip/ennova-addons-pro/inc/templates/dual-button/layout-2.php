<div class="enn-dual-button two <?php echo esc_attr($this->dual_button_card_class); ?>">
	<div class="inner <?php echo esc_attr($this->dual_button_card_inner_class); ?>">
		<?php if ( $show_link === 'yes' ) { ?>
			<a class="enn-btn one <?php echo $this->dual_button_one_class ?> <?php echo $link_button_position === 'before' ? 'ennova-no-flex': '' ?>"
							href="<?php echo esc_url($link); ?>"
							<?php echo esc_html($target); ?>
							<?php echo esc_html($nofollow); ?>>
							<?php 
								if ($link_button_position === 'before') {
									\Elementor\Icons_Manager::render_icon( $link_button_icon, [ 'aria-hidden' => 'true' ] );
								}
							?>
							<span><?php echo esc_html($link_text); ?></span>
							<?php 
								if ($link_button_position === 'after') {
									\Elementor\Icons_Manager::render_icon( $link_button_icon, [ 'aria-hidden' => 'true' ] );
								}
							?>
			</a>
		<?php } ?>
		<?php if ( $show_two_link === 'yes' ) { ?>
			<a class="enn-btn two <?php echo esc_attr($this->dual_button_two_class); ?> <?php echo $link_two_button_position === 'before' ? 'ennova-no-flex': '' ?>"
					href="<?php echo esc_url($link_two); ?>"
					<?php echo esc_attr($target); ?>
					<?php echo esc_attr($nofollow); ?>>
				<?php 
					if ($link_two_button_position === 'before') {
						\Elementor\Icons_Manager::render_icon( $link_two_button_icon, [ 'aria-hidden' => 'true' ] );
					}
				?>
				<span><?php echo esc_html($link_two_text); ?></span>
				<?php 
					if ($link_two_button_position === 'after') {
						\Elementor\Icons_Manager::render_icon( $link_two_button_icon, [ 'aria-hidden' => 'true' ] );
					}
				?>
			</a>
		<?php } ?>
	</div>
</div>