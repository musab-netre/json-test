<?php // phpcs:disable WordPress.Security.NonceVerification.Recommended
// phpcs:disable WordPress.WP.I18n.MissingTranslatorsComment
namespace EnnovaAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Plugin {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {

		// Remove All Third Party Notices
		add_action( 'admin_enqueue_scripts',  [ $this, 'remove_notices' ]);

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// if ( ! class_exists( 'woocommerce' ) ) {
		// 	add_action( 'admin_notices', [ $this, 'admin_notice_missing_wc_plugin' ] );
		// 	return;
		// }

		$this->file_include();
		// add_action( 'admin_enqueue_scripts',  [ $this, 'remove_notifications_from_ennova_menu_page' ]);
		add_action('init', [ $this, 'init_enn_mega_menu'] , 999);
		add_action( 'admin_footer', [ $this, 'render_settings_popup' ] , 10 );
		add_action( 'wp_ajax_ennova_create_mega_menu_template', [ $this, 'ennova_create_mega_menu_template' ]  );
		add_action( 'wp_ajax_ennova_save_mega_menu_settings', [ $this, 'ennova_save_mega_menu_settings' ]  );

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, ENNOVA_MIN_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, ENNOVA_MIN_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Enqueue Styles
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts_styles' ] );
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_styles' ] );
		add_action('elementor/editor/after_enqueue_styles', [$this, 'ennova_editor_enqueue_scripts']);
		
		// Enqueue Scripts
		add_action(
			'elementor/frontend/after_register_scripts',
			[ $this, 'enqueue_scripts' ]
		);
		// Register widget
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action('elementor/controls/register', [$this, 'init_controls']);

		add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'elementor_js'] );

		add_action( 'admin_enqueue_scripts', array( $this, 'load_scripts' ) );
		add_shortcode('ennova_year', array( $this, 'get_year' ) );
		add_shortcode('ennova_site_tile', array( $this, 'get_site_name' ) );
		add_action('wp_ajax_woo_quickview', array( $this, 'woo_quickview' ));
		add_action('wp_ajax_nopriv_woo_quickview', array( $this, 'woo_quickview' ));
		add_action('wp_ajax_woo_compare_list', array( $this, 'woo_compare_list' ));
		add_action('wp_ajax_nopriv_woo_compare_list', array( $this, 'woo_compare_list' ));
		add_action('wp_ajax_woo_compare', array( $this, 'woo_compare' ));
		add_action('wp_ajax_nopriv_woo_compare', array( $this, 'woo_compare' ));
		add_action('wp_ajax_search_site',[ $this,'ajax_search'] );
        add_action('wp_ajax_search_woo_site',[ $this,'ajax_woo_search'] );
		// Refresh the cart fragments.
		if ( class_exists( 'woocommerce' ) ) {
			add_filter( 'woocommerce_add_to_cart_fragments', [ $this, 'cart_refresh' ] );
		}
		// Admin
        if (is_admin()) {
	        if ( ! empty( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] ) {
		        add_action( 'init', [ $this, 'register_wc_hook' ], 5 );
	        }
        }
		add_action('wp_ajax_remove_product', [ $this, 'remove_product_from_cart' ]);
		add_action('wp_ajax_nopriv_remove_product', [ $this, 'remove_product_from_cart' ]);
	}

	public function remove_notifications_from_ennova_menu_page() {
		$screen = get_current_screen();
		if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu' || isset( $screen->post_type ) && $screen->post_type == 'ennova-header-footer') {
			remove_all_actions( 'admin_notices' );
		}

	}
	
	/**
	* Get the Selected menu ID
	* @author Tom Hemsley (https://wordpress.org/plugins/megamenu/)
	*/
	public function get_selected_menu_id() {
		$nav_menus = wp_get_nav_menus( array('orderby' => 'name') );
		$menu_count = count( $nav_menus );
		$nav_menu_selected_id = isset( $_REQUEST['menu'] ) ? (int) $_REQUEST['menu'] : 0;
		$add_new_screen = ( isset( $_GET['menu'] ) && 0 == $_GET['menu'] ) ? true : false;

		$current_menu_id = $nav_menu_selected_id;

		// If we have one theme location, and zero menus, we take them right into editing their first menu
		$page_count = wp_count_posts( 'page' );
		$one_theme_location_no_menus = ( 1 == count( get_registered_nav_menus() ) && ! $add_new_screen && empty( $nav_menus ) && ! empty( $page_count->publish ) ) ? true : false;

		// Get recently edited nav menu
		$recently_edited = absint( get_user_option( 'nav_menu_recently_edited' ) );
		if ( empty( $recently_edited ) && is_nav_menu( $current_menu_id ) ) {
			$recently_edited = $current_menu_id;
		}

		// Use $recently_edited if none are selected
		if ( empty( $current_menu_id ) && ! isset( $_GET['menu'] ) && is_nav_menu( $recently_edited ) ) {
			$current_menu_id = $recently_edited;
		}

		// On deletion of menu, if another menu exists, show it
		if ( ! $add_new_screen && 0 < $menu_count && isset( $_GET['action'] ) && 'delete' == $_GET['action'] ) {
			$current_menu_id = $nav_menus[0]->term_id;
		}

		// Set $current_menu_id to 0 if no menus
		if ( $one_theme_location_no_menus ) {
			$current_menu_id = 0;
		} elseif ( empty( $current_menu_id ) && ! empty( $nav_menus ) && ! $add_new_screen ) {
			// if we have no selection yet, and we have menus, set to the first one in the list
			$current_menu_id = $nav_menus[0]->term_id;
		}

		return $current_menu_id;

	}

		// Get Menu Items Data
	public function get_menu_items_data( $menu_id = false ) {

		if ( ! $menu_id ) {
			return false;
		}

		$menu = wp_get_nav_menu_object( $menu_id );

		$menu_items = wp_get_nav_menu_items( $menu );

		if ( ! $menu_items ) {
			return false;
		}

		return $menu_items;
	}

		// Get Mega Menu Item Settings
	public function get_menu_items_settings() {
		$menu_items = $this->get_menu_items_data( $this->get_selected_menu_id() );

		$settings = [];

		if ( ! $menu_items ) {
			return [];
		} else {
			foreach ( $menu_items as $key => $item_object ) {
				$item_id = $item_object->ID;

				$item_meta = get_post_meta( $item_id, 'ennova-mega-menu-settings', true );

				if ( !empty($item_meta) ) {
					$settings[ $item_id ] = $item_meta;
				} else {
					$settings[ $item_id ] = [];
				}
			}
			
			return $settings;
		}
	}

	function remove_product_from_cart() {
		if ( isset($_POST) ) {
			$product_id = $_POST['product_id'];
        } 
	
		// Get the cart instance
		$cart = WC()->cart;
		
		// Remove the product from the cart
		$cart->remove_cart_item($product_id);
		
		// Return the cart fragment
		\WC_AJAX::get_refreshed_fragments();
		
		wp_die();
	}

	public function woo_quickview() {
		global $post, $product, $woocommerce;
	
		$prod_id = $_POST["product"];
		$product = get_product( $prod_id );

		// If the WC_product Object is not defined globally
		if ( ! is_a( $product, 'WC_Product' ) ) {
			$product = wc_get_product( $prod_id );
		}

		$terms = get_the_terms( $prod_id, 'product_cat' );
		$product_cats = '';
		if ( $terms && ! is_wp_error( $terms ) ) {
			$product_cats .= '<span class="posted_in">Category:';
			foreach ( $terms as $term ) {
				$term_link = get_term_link( $term );
				$product_cats .= '<a href="' . esc_url( $term_link ) . '">' . $term->name . '</a>';
			}
			$product_cats .= '</span>';
		}

		$sku = !$product->get_sku()== '' ? $product->get_sku() : "N/A";

		$quick_view = '';

		$quick_view .= '<div class="ennova-popup">
					<div class="overlay">
					<div class="close-btn">&times;</div>
					<div class="popup-img">
						<img src="'.wp_get_attachment_url( $product->get_image_id() ).'" alt="">
					</div>
					<div class="popup-content">
					<h2 class="enn_product_title">'.$product->get_name().'</h2>
					<p class="price">'.$product->get_price_html().'</p>
						<p>'.$product->get_description().'</p> 
						<div class="woocommerce"><div class="woocommerce-notices-wrapper"></div>'.ob_start().woocommerce_template_single_add_to_cart( array(), $product ).ob_get_clean().'</div>
					<div class="product_meta">
					<span class="sku_wrapper">SKU: <span class="sku">'.$sku.'</span></span>'.$product_cats.'</div>
						</div>
					</div>
				</div>'; 
		
		$items =  json_encode($quick_view);

		// Generate the "Add to Cart" button HTML
		
        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }
	}

	public function woo_compare_list() {
		global $post, $product, $woocommerce;
		
		if ( isset($_POST) ) {
			$prod_compare_id = $_POST["product_compare_id"];
			if(!$prod_compare_id == 'blank'){
				$loop = wc_get_products(array(
					'limit'  => -1, // All products
					'status' => 'publish', // Only published products

				) );
			}else{
				$loop = '';
			}
			$prod_id = $_POST["product_id"];
			$product = get_product( $prod_id );

			// If the WC_product Object is not defined globally
			if ( ! is_a( $product, 'WC_Product' ) ) {
				$product = wc_get_product( $prod_id );
			}
		}
		$weight_unit = get_option('woocommerce_weight_unit');
		$pro_weight = $product->get_weight() == '' || $product->get_weight() == 0 ? '<span class="blank-place"></span>' : $product->get_weight();
		$pro_stock = $product->get_availability()['availability'] == '' || $product->get_availability()['availability'] == 0 ? '<span class="blank-place"></span>' : $product->get_availability()['availability'];
		$pro_desc = $product->get_description() == '' ? '<span class="blank-place"></span>' : $product->get_description();
		$sku = !$product->get_sku()== '' ? $product->get_sku() : "N/A";
		$url = get_permalink($prod_id);
		$rating = get_post_meta( $prod_id, '_wc_average_rating', true );
		$round_next_rating = round($rating);
        $round_prev_rating = floor($rating);
		$compare_table = '';
		$compare_table .= 
		'<div class="ennova-popup_two">
		 <div class="overlay">
		   <div class="cmr-close-btn">&times;</div>
		   <div class="compare-table">
			 <div class="compare-products-choice">';
			 foreach($loop as $item){
				$compare_table .= 
				'<div class="compare-product-list" >
				  <div class="compare-list-img">
					<img src="'.wp_get_attachment_url( $item->get_image_id() ).'" alt="">
				  </div>
				  <div class="compare-product-item">
					<h4>'.$item->get_name().'</h4>
					<a class="compare-btn" prod-com-id="'.$item->get_id().'">Compare</a>
				  </div>
				</div>';
			}
					 
			 $compare_table .= '</div>
			 <div class="compare-product-selected">
			 <div class="compare-title">
				<ul> 
				<li class="com-title">
					<h6>Title</h6>
				</li>
				<li>Price</li>
				<li class="reveiw">Rating</li>
				<li class="discription">Description</li>
				<li>Sku</li>
				<li>Availability</li>
				<li>Weight</li>
				<li>Veiw Products</li>
				</ul>
			</div>
			   <!-- --compare-product-- -->
			   <div class="compare-product">
                      <ul>
					  <li class="com-rev"> <a href="#">Remove</a></li>
                        <li>
                            <div class="compare-img">
                              <img src="'.wp_get_attachment_url( $product->get_image_id() ).'" alt="">
                            </div>
                        </li>
                        <li class="com-title">
                          <h6>'.$product->get_name().'</h6>
                        </li>
                        <li>'.$product->get_price().get_woocommerce_currency_symbol().'</li>
                        <li class="reveiw">
                          <div class="compare-rating" rating="'.esc_attr($rating).'">
                            ';
							if(is_numeric( $rating ) && floor( $rating ) != $rating){
                                
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_prev_rating){
                                        $compare_table .= '<i class="fas fa-star"></i>';
                                    }else if($i <= $round_next_rating){
                                        $compare_table .= '<i class="fas fa-star-half-alt"></i>';
                                    }else{
										$compare_table .= '<i class="far fa-star"></i>';
                                    }
                                }
                                
                            }elseif($rating == 0 || $rating == '0' ){
                                
                                $num_iterations = 5;
                                for ($i = 1; $i <= $num_iterations; $i++) {
									$compare_table .= '<i class="far fa-star"></i>';
                                }
                                
                            }else{
                                
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_next_rating){
										$compare_table .= '<i class="fas fa-star"></i>';
                                    }else{
										$compare_table .= '<i class="far fa-star"></i>';
                                    }
                                }
                                
                            }
								
							$compare_table .= '
                          </div>
                        </li>
                        <li class="discription">
                          <p>'.$pro_desc.'</p>
                        </li>
                        <li>'.$sku.'</li>
                        <li>'.$product->get_stock_status().'</li>
                        <li>'.$pro_weight.'</li>
                        <li><a href="'.esc_attr($url).'" class="">View</a></li>
                      </ul>
                    </div>
			   <!--/ --compare-product-- -->
			 </div>
			
		   </div>
		 </div>
	   </div>';
		
        $items =  json_encode($compare_table);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }
        
	}

	public function woo_compare() {global $post, $product, $woocommerce;
		if ( isset($_POST) ) {
			$prod_id = $_POST["compared_product_id"];
			$product = get_product( $prod_id );

			// If the WC_product Object is not defined globally
			if ( ! is_a( $product, 'WC_Product' ) ) {
				$product = wc_get_product( $prod_id );
			}
		}

		$weight_unit = get_option('woocommerce_weight_unit');
		$pro_weight = $product->get_weight() == '' || $product->get_weight() == 0 ? '<span class="blank-place"></span>' : $product->get_weight().$weight_unit;

		$pro_desc = $product->get_description() == '' ? '<span class="blank-place"></span>' : $product->get_description();
		$url = get_permalink($prod_id);
		$sku = !$product->get_sku()== '' ? $product->get_sku() : "N/A";
		$rating = get_post_meta( $prod_id, '_wc_average_rating', true );
		$round_next_rating = round($rating);
        $round_prev_rating = floor($rating);
		$round_rating = round($rating);

		$compare_product = '';

			 $compare_product .= '
			   <!-- --compare-product-- -->
			   <div class="compare-product">
                      <ul>
					  <li class="com-rev"> <a href="#">Remove</a></li>
                        <li>
                            <div class="compare-img">
                              <img src="'.wp_get_attachment_url( $product->get_image_id() ).'" alt="">
                            </div>
                        </li>
                        <li class="com-title">
                          <h6>'.$product->get_name().'</h6>
                        </li>
                        <li>'.$product->get_price().get_woocommerce_currency_symbol().'</li>
                        <li class="reveiw">
                          <div class="compare-rating" rating="'.esc_attr($rating).'">
                            ';
							if(is_numeric( $rating ) && floor( $rating ) != $rating){
                                
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_prev_rating){
                                        $compare_product .= '<i class="fas fa-star"></i>';
                                    }else if($i <= $round_next_rating){
                                        $compare_product .= '<i class="fas fa-star-half-alt"></i>';
                                    }else{
										$compare_product .= '<i class="far fa-star"></i>';
                                    }
                                }
                                
                            }elseif($rating == 0 || $rating == '0' ){
                                for ($i = 1; $i <= 5; $i++) {
									$compare_product .= '<i class="far fa-star"></i>';
                                }  
                            }else{
                                for ($i = 1; $i <= 5; $i++) {
                                    if( $i <= $round_next_rating){
										$compare_product .= '<i class="fas fa-star"></i>';
                                    }else{
										$compare_product .= '<i class="far fa-star"></i>';
                                    }
                                }    
                            }
								
							$compare_product .= '
                          </div>
                        </li>
                        <li class="discription">
                          <p>'.$pro_desc.'</p>
                        </li>
                        <li>'.$sku.'</li>
                        <li>'.$product->get_stock_status().'</li>
                        <li>'.$pro_weight.'</li>
                        <li><a href="'.esc_url($url).'" class="">View</a></li>
                      </ul>
                    </div>
			   <!--/ --compare-product-- -->';

		
        $items =  json_encode($compare_product);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }
        
	}
	public function load_scripts($hook) {
        wp_enqueue_style( 'eap-all-font-awesome', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/all.min.css', array(),  ENNOVA_VERSION, true );
        wp_enqueue_style( 'eap-font-awesome', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/fontawesome.min.css', array(),  ENNOVA_VERSION, true );
		
		// Deny if NOT a Menu Page
		if ( 'nav-menus.php' == $hook ) {
			// Color Picker
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'wp-color-picker-alpha', ENNOVA_URL .'assets/js/wp-color-picker-alpha.min.js', ['jquery', 'wp-color-picker'], ENNOVA_VERSION , true );
	
			// Icon Picker
			wp_enqueue_script( 'ennova-iconpicker-js', ENNOVA_URL .'assets/js/fontawesome-iconpicker.min.js', ['jquery'], ENNOVA_VERSION , true );
			wp_enqueue_style( 'ennova-iconpicker-css', ENNOVA_URL .'assets/css/fontawesome-iconpicker.min.css', ENNOVA_VERSION , true );
			wp_enqueue_style( 'ennova-mega-menu-css', ENNOVA_URL .'assets/css/mega-menu.css', [], ENNOVA_VERSION );

			// enqueue JS
			wp_enqueue_script( 'ennova-mega-menu-js', ENNOVA_URL .'assets/js/mega-menu.js', ['jquery'], ENNOVA_VERSION );

			wp_localize_script( 
				'ennova-mega-menu-js',
				'EnnovaMegaMenuSettingsData',
				[
					'settingsData' => $this->get_menu_items_settings(),
					'nonce' => wp_create_nonce( 'ennova-mega-menu-js' ),
				]
			);
	
		}
	}
	// Register Post Type for mega menu
	public function register_mega_menu_cpt() {
		$args = array(
			'label'				  => esc_html__( 'Ennova Mega Menu', 'ennova-addons' ),
			'public'              => true,
			'publicly_queryable'  => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'supports'            => array( 'title', 'editor', 'elementor' ),
			'hierarchical'        => false,
		);

		register_post_type( 'enn_mega_menu', $args );
	}

	// Convert to Canvas Template
	public function convert_to_canvas_template( $template ) {
		if ( is_singular('enn_mega_menu') ) {
			$template = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

			if ( file_exists( $template ) ) {
				return $template;
			} else {
				return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
			}
		}
		return $template;
	}

	// Init Mega Menu
	public function init_enn_mega_menu() {
		$this->register_mega_menu_cpt();
		add_action( 'template_include', [$this , 'convert_to_canvas_template'], 9999 );
	}

		// Create Menu Template
	function ennova_create_mega_menu_template() {

		$nonce = $_POST['nonce'];

		if ( !wp_verify_nonce( $nonce, 'ennova-mega-menu-js' )  || !current_user_can( 'manage_options' ) ) {
		return; // Get out of here, the nonce is rotten!
		}

		// $menu_id = intval( $_REQUEST['menu'] );
		// $menu_item_id = intval( $_REQUEST['item'] );
		$menu_item_id = intval( $_POST['item_id'] );
		$mega_menu_id = get_post_meta( $menu_item_id, 'ennova-mega-menu-item', true );

		if ( ! $mega_menu_id ) {

			$mega_menu_id = wp_insert_post( array(
				'post_title'  => 'ennova-mega-menu-item-' . $menu_item_id,
				'post_status' => 'publish',
				'post_type'   => 'enn_mega_menu',
			) );

			update_post_meta( $menu_item_id, 'ennova-mega-menu-item', $mega_menu_id );

		}

		$edit_link = add_query_arg(
			array(
				'post' => $mega_menu_id,
				'action' => 'elementor',
			),
			admin_url( 'post.php' )
		);

		wp_send_json([
			'data' => [
				'edit_link' => $edit_link
			]
		]);
	}
		// Save Mega Menu Settings
	function ennova_save_mega_menu_settings() {

		$nonce = $_POST['nonce'];

		if ( !wp_verify_nonce( $nonce, 'ennova-mega-menu-js' )  || !current_user_can( 'manage_options' ) ) {
		exit; // Get out of here, the nonce is rotten!
		}

		if ( isset($_POST['item_settings']) ) {
			update_post_meta( $_POST['item_id'], 'ennova-mega-menu-settings', $_POST['item_settings'] );
		}

		wp_send_json_success($_POST['item_settings']);
	}
			// Render Settings Popup
	function render_settings_popup() {
		$screen = get_current_screen();

		if ( 'nav-menus' !== $screen->base ) {
			return;
		}

		?>

		<div class="ennova-mm-settings-popup-wrap">
			<div class="ennova-mm-settings-popup">
				<div class="ennova-mm-settings-popup-header">
					<span class="ennova-mm-popup-logo" style="background:url('') no-repeat center center / contain;">RE</span>
					<span><?php esc_html_e('Ennova Mega Menu', 'ennova-addons'); ?></span>
					<span class="ennova-mm-popup-title"><?php esc_html_e('Menu Item: ', 'ennova-addons'); ?><span></span></span>
					<span class="dashicons dashicons-no-alt ennova-mm-settings-close-popup-btn"></span>
				</div>

				<div class="ennova-mm-settings-wrap" >
					<h4><?php esc_html_e('General', 'ennova-addons'); ?></h4>
					<div class="ennova-mm-setting ennova-mm-setting-switcher">
						<h4><?php esc_html_e('Enable Mega Menu', 'ennova-addons'); ?></h4>
						<input type="checkbox" id="ennova_mm_enable">
						<label for="ennova_mm_enable"></label>
					</div>
					<div class="ennova-mm-setting">
						<h4><?php esc_html_e('Mega Menu Content', 'ennova-addons'); ?></h4>
						<button class="button button-primary ennova-edit-mega-menu-btn">
							<i class="eicon-elementor-square" aria-hidden="true"></i>
							<?php esc_html_e('Edit with Elementor', 'ennova-addons'); ?>
						</button>
					</div>
					<div class="ennova-mm-setting">
						<h4><?php esc_html_e('Dropdown Position', 'ennova-addons'); ?></h4>
						<select id="ennova_mm_position">
							<option value="default"><?php esc_html_e('Default', 'ennova-addons'); ?></option>
							<option value="relative"><?php esc_html_e('Relative', 'ennova-addons'); ?></option>
						</select>
					</div>
					<div class="ennova-mm-setting">
						<h4><?php esc_html_e('Dropdown Width', 'ennova-addons'); ?></h4>
						<select id="ennova_mm_width">
							<option value="default"><?php esc_html_e('Default', 'ennova-addons'); ?></option>
							<option value="full"><?php esc_html_e('Full Width', 'ennova-addons'); ?></option>
							<option value="custom"><?php esc_html_e('Custom', 'ennova-addons'); ?></option>
						</select>
					</div>
					<div class="ennova-mm-setting">
						<h4><?php esc_html_e('Custom Width (px)', 'ennova-addons'); ?></h4>
						<input type="number" id="ennova_mm_custom_width" value="600">
					</div>
				</div>
				<div class="ennova-mm-settings-popup-footer">
                	<button class="button ennova-save-mega-menu-btn">
						<?php esc_html_e('Save', 'ennova-addons'); ?>
					</button>
            	</div>
			</div>
		</div>

		<!-- Iframe Popup -->
		<div class="ennova-mm-editor-popup-wrap">
			<div class="ennova-mm-editor-close-popup-btn"><span class="dashicons dashicons-no-alt"></span></div>
			<div class="ennova-mm-editor-popup-iframe"></div>
		</div>
		<?php
	}

	public function remove_notices() {
		$screen = get_current_screen();
        if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu' || isset( $screen->post_type ) && $screen->post_type == 'ennova-header-footer') {
            remove_all_actions( 'admin_notices' );
        }
	}

	// editor styles
	public function ennova_editor_enqueue_scripts()
	{
		// editor style
		wp_enqueue_style(
			'ennova-editor',
			ENNOVA_URL . 'assets/css/editor-css.css',
			false
		);
	}

	public function elementor_js() {
        wp_enqueue_script(
            'swiper',
            ELEMENTOR_ASSETS_URL . 'lib/swiper/swiper.min.js',
            ['jquery'],
            ENNOVA_VERSION, true 
        );
    }

	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			__( '"%1$s" requires "%2$s" to be installed and activated.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova Addons for Elementor', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'Elementor', 'ennova-addons' ) . '</strong>'
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}

	public function admin_notice_missing_wc_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			__( '"%1$s" requires "%2$s" to be installed and activated.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova Addons for Elementor', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'WooCommerce', 'ennova-addons' ) . '</strong>'
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			__( '"%1$s" requires "%2$s" version %3$s or greater.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'Elementor', 'ennova-addons' ) . '</strong>',
			ENNOVA_MIN_ELEMENTOR_VERSION
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			__( '"%1$s" requires "%2$s" version %3$s or greater.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'PHP', 'ennova-addons' ) . '</strong>',
			ENNOVA_MIN_PHP_VERSION
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}

	public function enqueue_styles() {
		wp_register_style( 'ennova-swiper-css', 'https://unpkg.com/swiper/swiper-bundle.min.css', null, ENNOVA_VERSION );
		wp_register_style( 'ennova-swiper-custom-css', ENNOVA_URL . 'assets/css/ennova-widget-css.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-image-compare-css', ENNOVA_URL . 'assets/css/juxtapose.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-filter-gallery', ENNOVA_URL . 'assets/css/filter-gallery.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-post-blog-css', ENNOVA_URL . 'assets/css/ennova-post-blog.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-woo-widgets-css', ENNOVA_URL . 'assets/css/ennova-woo-widgets.css', [], ENNOVA_VERSION );
		
		wp_register_style( 'ennova-styles-css', ENNOVA_URL . 'assets/css/style.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-google-fonts', 'https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,200&display=swap', null, ENNOVA_VERSION );

		wp_enqueue_style( 'ennova-filter-gallery' );
		wp_enqueue_style( 'ennova-post-blog-css' );
		wp_enqueue_style( 'ennova-woo-widgets-css' );
		wp_enqueue_style('ennova-styles-css');
		wp_enqueue_style('ennova-google-fonts');
		wp_enqueue_style( 'ennova-swiper-css' );
		wp_enqueue_style( 'ennova-swiper-custom-css' );
		wp_enqueue_style( 'ennova-image-compare-css' );

        wp_enqueue_style( 'sm-clean-css', ENNOVA_URL . 'assets/css/sm-clean.css');
        wp_enqueue_style( 'sm-core-css', ENNOVA_URL . 'assets/css/sm-core-css.css');
        wp_enqueue_style( 'jquery-auto-complete-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css', array(), '1.13.2' );
		
		wp_enqueue_style( 'enn-font-awesome', ENNOVA_URL . 'assets/css/all.css', array(), null );

	}

	public function enqueue_scripts() {
		wp_register_script( 'ennova-swiper-custom-js', ENNOVA_URL . 'assets/js/ennova-widget-js.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-filter-gallery-js', ENNOVA_URL . 'assets/js/ennova-filter-gallery.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-image-compare-js', ENNOVA_URL . 'assets/js/image-compare.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-ticker-js', ENNOVA_URL . 'assets/js/jquery.marquee.min.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-post-blog-js', ENNOVA_URL . 'assets/js/ennova-post-blog.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'jquery-smartmenus-js', ENNOVA_URL.'assets/js/jquery.smartmenus.js', ['jquery'], '1.1.1', true );
        wp_register_script( 'ennova-custom-js', ENNOVA_URL.'assets/js/custom.js', ['jquery', 'jquery-smartmenus-js'], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-search-js', ENNOVA_URL . 'assets/js/search.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-woosearch-js', ENNOVA_URL . 'assets/js/woo-search.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-woo-js', ENNOVA_URL . 'assets/js/ennova-woo.js', [], ENNOVA_VERSION, true );
		wp_enqueue_script('jquery-auto-complete-js','https://code.jquery.com/ui/1.13.2/jquery-ui.js', array( 'jquery' ),'1.13.2',true);
		wp_enqueue_script( 'ennova-filter-gallery-js' );
		wp_enqueue_script( 'ennova-swiper-js' );
		wp_enqueue_script( 'ennova-swiper-custom-js' );
		wp_enqueue_script( 'ennova-ticker-js' );
		wp_enqueue_script( 'ennova-image-compare-js' );
		wp_enqueue_script( 'ennova-post-blog-js' );
		wp_enqueue_script( 'jquery-smartmenus-js' );
        wp_enqueue_script( 'ennova-custom-js' );
		wp_localize_script(
            'ennova-custom-js',
            'wc_cart_fragments_params',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
            )
        );
        wp_enqueue_script( 'ennova-search-js' );
		wp_enqueue_script( 'ennova-woosearch-js' );
		wp_enqueue_script( 'ennova-woo-js' );
		wp_localize_script( 'ennova-woo-js', 'myajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		wp_localize_script(
            'ennova-woosearch-js',
            'woo_search',
            array(
                'ajax' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'woo_tittle_nonce' ),
            )
        );

	}

	public function get_site_name() {
        return '<a class="ennova-copyright-info" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
    }

    public function get_year() {
        return esc_html( date( 'Y' ) );
    }

	public function admin_scripts_styles($hook) {
		$screen = get_current_screen();
        if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu') {
            wp_enqueue_script ( 'ennova-admin-js', ENNOVA_URL . 'assets/js/admin.js', [], ENNOVA_VERSION, true );
        }
  	}

	  public function register_wc_hook() {
		if ( class_exists( 'WooCommerce' ) ) {
			wc()->frontend_includes();
		}
	}

	public function register_widgets() {
		$this->includes();
		$this->register_slider_widgets();
	}

	public function includes() {
		require_once ENNOVA_PATH . 'inc/widgets/widget-utils.php';

		require_once ENNOVA_PATH . 'inc/widgets/site-logo.php';
		require_once ENNOVA_PATH . 'inc/widgets/site-title.php';
		require_once ENNOVA_PATH . 'inc/widgets/site-tagline.php';
		require_once ENNOVA_PATH . 'inc/widgets/copyright.php';
		require_once ENNOVA_PATH . 'inc/widgets/search.php';
		require_once ENNOVA_PATH . 'inc/widgets/menus.php';
		require_once ENNOVA_PATH . 'inc/widgets/mega-menus.php';

		require_once ENNOVA_PATH . 'inc/widgets/creative-button.php';
		require_once ENNOVA_PATH . 'inc/widgets/dual-button.php';
		require_once ENNOVA_PATH . 'inc/widgets/team.php';
		require_once ENNOVA_PATH . 'inc/widgets/testimonial.php';
		require_once ENNOVA_PATH . 'inc/widgets/feature.php';
		require_once ENNOVA_PATH . 'inc/widgets/dual-heading.php';
		require_once ENNOVA_PATH . 'inc/widgets/flip-box.php';
		require_once ENNOVA_PATH . 'inc/widgets/progress-bar.php';
		require_once ENNOVA_PATH . 'inc/widgets/calltoaction.php';
		
		require_once ENNOVA_PATH . 'inc/widgets/service.php';
		require_once ENNOVA_PATH . 'inc/widgets/timeline.php';
		require_once ENNOVA_PATH . 'inc/widgets/number-box.php';
		require_once ENNOVA_PATH . 'inc/widgets/portfolio.php';
		require_once ENNOVA_PATH . 'inc/widgets/price.php';
		require_once ENNOVA_PATH . 'inc/widgets/price-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/price-menu.php';
		require_once ENNOVA_PATH . 'inc/widgets/business-hours.php';
		require_once ENNOVA_PATH . 'inc/widgets/filter-gallery.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-blog-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-blog.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-timeline.php';
		require_once ENNOVA_PATH . 'inc/widgets/featured-post-blog.php';
		require_once ENNOVA_PATH . 'inc/widgets/express-post-widget.php';
		require_once ENNOVA_PATH . 'inc/widgets/category-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-category-tab.php';
		require_once ENNOVA_PATH . 'inc/widgets/single-column-cate.php';
		require_once ENNOVA_PATH . 'inc/widgets/author.php';
		require_once ENNOVA_PATH . 'inc/widgets/author-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/image-hotspot.php';
		require_once ENNOVA_PATH . 'inc/widgets/image-comparison.php';
		require_once ENNOVA_PATH . 'inc/widgets/video-post.php';
		
		require_once ENNOVA_PATH . 'inc/widgets/slider-widget.php';
		require_once ENNOVA_PATH . 'inc/widgets/service-carousel.php';
		require_once ENNOVA_PATH . 'inc/widgets/portfolio-carousel.php';
		require_once ENNOVA_PATH . 'inc/widgets/testimonial-carousel.php';
		require_once ENNOVA_PATH . 'inc/widgets/team-carousel.php';
		require_once ENNOVA_PATH . 'inc/widgets/blog-carousel.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-ticker.php';
		
		require_once ENNOVA_PATH . 'inc/widgets/woo-product-slider.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-product-grid.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-category-grid.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-category-slider.php';
		require_once ENNOVA_PATH . 'inc/widgets/product-category-tab.php';
		require_once ENNOVA_PATH . 'inc/widgets/product-grid-with-nav.php';
		require_once ENNOVA_PATH . 'inc/widgets/cart.php';
		require_once ENNOVA_PATH . 'inc/widgets/cart-page.php';
		require_once ENNOVA_PATH . 'inc/widgets/checkout.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-banner.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo_search.php';

		require_once ENNOVA_PATH . 'inc/widgets/cf7.php';
		require_once ENNOVA_PATH . 'inc/widgets/everest-forms.php';
		require_once ENNOVA_PATH . 'inc/widgets/ninja-forms.php';

		
	}
	public function total_widgets(){
		$All_Widgets = [];
		foreach (registered_widgets() as $widget_setting) {
			foreach ( $widget_setting['widgets'] as $widget) {

				$widget_id = explode(" ",$widget['slug']);
				$widget_id = implode("-ennova-",$widget_id);
			   
				$All_Widgets[] .= get_option($widget_id, $widget_id) == "" ? false : true ;
			}
		}

		return $All_Widgets;
	}
	public function total_TP_widgets(){
		$All_Widgets = [];
		foreach (third_party_widgets() as $widget_setting) {
		  $widget_id = explode(" ",$widget_setting['name']);
		  $widget_id = implode("-ennova-",$widget_id);
		 
		  $All_Widgets[] .= get_option($widget_id, $widget_id) == "" ? false : true ;
		}

		return $All_Widgets;
	}
	public function register_slider_widgets() {

		$header_scripts = get_option('Copyright',true);
		define("WIDGETS", $this->total_widgets());
		define("Third_WIDGETS", $this->total_TP_widgets());
		$widget_manager = \Elementor\Plugin::instance()->widgets_manager;
		$i = 0;
		foreach ( registered_widgets() as $widgets ) {

			if($widgets['widget_cat'] == 'Ennova Woocommerce'){
				foreach ( $widgets['widgets'] as $widget ) {

					$class_name = '\EnnovaAddons\\'. $widget['name'];
					if( !$widget['name'] == '' && !WIDGETS[$i] == false ){
						if(array_key_exists('id', $widget ) && $widget['id'] == 'woocommerce' && class_exists( 'woocommerce' ) ){
							$widget_manager->register( new $class_name() );
						}
					}
					$i++;
				}
			}else{
				foreach ( $widgets['widgets'] as $widget ) {

					$class_name = '\EnnovaAddons\\'. $widget['name'];
						
					if( !$widget['name'] == '' && !WIDGETS[$i] == false ){
						$widget_manager->register( new $class_name() );
					}
	
					$i++;
					
				}
			}
		}
		$j = 0;
		foreach ( third_party_widgets() as $widget ) {
			$class_name = '\EnnovaAddons\\'. $widget['name'];
			$plug_path = get_plugin_install_path($widget['id']);
			 if(is_plugin_active($plug_path)){ 
				if( !$widget['name'] == '' && !Third_WIDGETS[$j] == '' ){
					$widget_manager->register( new $class_name() );
				}
			}
			$j++;
		}
	}

	public function init_controls() {
	require_once ENNOVA_PATH . 'inc/controls/class-selectize-control.php';
	\Elementor\Plugin::instance()->controls_manager->register_control('meta-store-selectize', new Selectize_Control() );
	}

	public function file_include(){
		require_once ENNOVA_PATH . 'inc/admin.php';
	}

	public function cart_refresh( $fragments ) {

		$has_cart = is_a( WC()->cart, 'WC_Cart' );
		if ( ! $has_cart ) {
			return $fragments;
		}
		$cart_subtotal = WC()->cart->get_subtotal();
		$product_count = WC()->cart->get_cart_contents_count();
		$sub_total = WC()->cart->get_cart_subtotal();
		$cart_items = WC()->cart->get_cart_contents();
		$cart_contents = '<div class="enn-cart-items">';
		 foreach ( $cart_items as $cart_item_key => $cart_item ) {
			$product_id = $cart_item['product_id'];
			$product_image_id = get_post_thumbnail_id( $product_id );
			$product_image = wp_get_attachment_image_url( $product_image_id, 'thumbnail' );
			$product_name = get_the_title( $product_id );
			$product_price = $cart_item['data']->get_price();
			$product_quantity = $cart_item['quantity'];
			$product_link = get_permalink($product_id);
			$view_cart_url = wc_get_cart_url();
			$checkout_url = wc_get_checkout_url();
			$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );	

			$remove_url = wc_get_cart_remove_url( $cart_item_key );
			
			$cart_contents  .= '<div class="enn-cart-item">
				<div class="item-image"><a href="'.esc_url($product_link).'"> <img src="'.esc_url($product_image).'" alt="Common Projects"> </a>
				</div>
				<div class="item-details">
				<a href="'.esc_url($product_link).'"><h6 class="item-title">'.esc_html($product_name).'</h6></a>
				<div class="item-quantity">
					<!-- <span class="fas fa-chevron-left item-up"></span> -->
					<span class="item-count">'.esc_html($product_quantity).' x </span>
					<!-- <span class="fas fa-chevron-right item-down"></span> -->
				</div>
				<div class="item-price">$'.esc_html($product_price).'</div>
				</div>
				<div class="item-remove">';
				
				$cart_contents  .= apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'woocommerce_cart_item_remove_link',
					sprintf(
						'<a href="%s" class="remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><i class="%s"></i></a>',
						esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
						esc_attr__( 'Remove this item', 'woocommerce' ),
						esc_attr( $product_id ),
						esc_attr( $cart_item_key ),
						esc_attr( $_product->get_sku() ),
						esc_attr('fas fa-times')
					),
					$cart_item_key
				);
			
$cart_contents  .= '</div>
			</div>';

			 }
		$cart_contents .= '</div>';

		if ( null !== WC()->cart ) {

			$fragments['span.cart-total'] = '<span class="cart-total">' . $sub_total . '</span>';

			$fragments['span.counter'] = '<span class="counter">' . $product_count . '</span>';

			$fragments['div.enn-cart-items'] = $cart_contents;

			$fragments['span.sub-price'] = '<span class="sub-price">' . $sub_total . '</span>';

			
		}
		return $fragments;
	}

	public function ajax_search() {
		
        if ( isset($_POST) ) {
    
            $results = new \WP_Query( array(
                'post_type'     => array( 'post', 'page' ),
                's'             =>  $_POST['srch1'],
            ) );
    
        }  
    
        $items = array();
    
        if ( !empty( $results->posts ) ) {
            foreach ( $results->posts as $result ) {
                $items[] = $result->post_title;
            }
        }

        $items =  json_encode($items);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }

    }

    public function ajax_woo_search() {

        if ( isset($_POST) ) {
    
            $results = new \WP_Query( array(
                'post_type' => 'product',
                's'             =>  $_POST['srchwoo'],
            ) );
    
        }  
    
        $items = array();
    
        if ( !empty( $results->posts ) ) {
            foreach ( $results->posts as $result ) {
                $items[] = $result->post_title;
            }
        }

        $items =  json_encode($items);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        } 

    }
}

Plugin::instance();
