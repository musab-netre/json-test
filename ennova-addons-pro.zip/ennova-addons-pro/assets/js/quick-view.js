// (function ($) {
// 	'use strict';

// /**
//   * Woocommerce product quickview js
//   **/

//   var ProductFeatureQuickView = function( $scope, $ ){ 
    

//     $('.quick-cls').click(function() {
//         var thisEl = $(this);
//         thisEl.parent().parent().toggleClass("popup");
//         var product_id = $(this).find('.enn-tooltip').attr('data-prod-id');
//         var data = {action: 'woo_quickview', product: product_id};

    
//         $.ajax({
//             url: myajax.ajaxurl,
//             type: "POST",
//             data: data,
//             success: function (response) {
                
//                 var jsdata = JSON.parse(response.data);
//                 console.log(jsdata);
//                 thisEl.parent().parent().append(jsdata);
//             },
//             complete: function() {
//                 var quick_view = document.querySelectorAll('.close-btn');
//                 for (var i = 0; i < quick_view.length; i++) {
//                     quick_view[i].addEventListener('click', function(event) {
                        
//                         var par = this.parentElement.parentElement.parentElement;
//                         if(par.classList.contains('popup')){
//                         par.classList.remove('popup');
//                         this.parentElement.parentElement.remove();

//                         }
//                     });
//                 }
//                 // document.addEventListener('click', function(){
//                 //     var close_view = document.querySelector('.close-btn');
//                 //     var par = close_view.parentElement.parentElement.parentElement;
//                 //     if(par.classList.contains('popup')){
//                 //         par.classList.remove('popup');
//                 //         close_view.parentElement.parentElement.remove();

//                 //     }
                    
//                 // })
//             },
//             error: function(errorThrown){
//                 console.log(errorThrown);
//                 console.log('quick view ajax error');
//             },
//         });
    
        
    
//     });
    
// }

// jQuery(window).on('elementor/frontend/init', function () {
//     elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-slider.default', ProductFeatureQuickView);
// });

// jQuery(window).on('elementor/frontend/init', function () {
//     elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-grid.default', ProductFeatureQuickView);
// });

// } )( jQuery );