( function( $ ) {
	/**
	* Search widget JS
	*/
	var WidgetennovaSearchButton = function( $scope, $ ){

		if ( 'undefined' == typeof $scope )
			return;

			var $input = $scope.find( "input.ennova_search_input" );
			var $clear = $scope.find( "button#clear" );
			var $clear_with_button = $scope.find( "button#clear-with-button" );
			var $search_button = $scope.find( ".ennova-search-submit" );
			var $toggle_search = $scope.find( ".ennova-search-icon-toggle input" );

		$scope.find( '.search-btn i.fa-search' ).on( 'click', function( ){
			$scope.find( ".ennova-search-wrapper" ).toggleClass( "ennova-input-focus" );					
		});
  		   

		// $search_button.on( 'touchstart click', function(){
		// 	$input.submit();
		// });

		$toggle_search.css( 'padding-right', $toggle_search.next().outerWidth() + 'px' );

	
		$input.on( 'keyup', function(){
			$clear.style = (this.value.length) ? $clear.css('visibility','visible'): $clear.css('visibility','hidden');
			$clear_with_button.style = (this.value.length) ? $clear_with_button.css('visibility','visible'): $clear_with_button.css('visibility','hidden');
			$clear_with_button.css( 'right', $search_button.outerWidth() + 'px' );
		});

		$clear.on("click",function(){
			this.style = $clear.css('visibility','hidden');
			$input.value = "";
		});
		$clear_with_button.on("click",function(){
			this.style = $clear_with_button.css('visibility','hidden');
			$input.value = "";
		});

	var searchRequest;	

	$input.autocomplete({
		source: function(term, suggest){
			var term1 = $scope.find( "input.ennova_search_input" ).val();
			try { searchRequest.abort(); } catch(e){}
			searchRequest = $.post(search.ajax, { srch1: term1, action: 'search_site' }, function(res) {
				var rspns = eval(res.data);
				var na = [];
				$.map(rspns, function(item) {
				let result = item.toLowerCase().includes(term1.toLowerCase());
					if(result == true){
						na.push(item);
					}	
				});
					suggest(na);
			});
		}
	  });

	}


    $( window ).on( 'elementor/frontend/init', function () {

		elementorFrontend.hooks.addAction( 'frontend/element_ready/ennova-search.default', WidgetennovaSearchButton );
	});
} )( jQuery );
