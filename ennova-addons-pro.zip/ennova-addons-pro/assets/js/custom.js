(function ($) {

  /**
   * Nav widgets JS
   */
  var WidgetennovaNavMenu = function( $scope, $ ){ 
  
    if ( 'undefined' == typeof $scope ) {
        return;
    }
  
    var $main = $scope.find( ".main-nav" );

    var full_toggle = $scope.hasClass( 'ennova-mobile-menu-full-width' );
    var e_column = $scope.closest('.elementor-column').length;
    var e_contain = $scope.closest('[data-element_type="container"]').length;
    console.log(full_toggle);
    $scope.find('.toggle-icon.open').on("click", function() {
      $main.toggleClass('open-nav');
      $scope.find('.ennova-collapse').toggleClass('responsiv_nav');
      fullWidthMobileDropdown();
    });

    $scope.find('#main-menu').smartmenus({
      subMenusSubOffsetX: 1,
      subMenusSubOffsetY: -8
    });

      fullWidthMobileDropdown();
    

    // Run Functions on Resize
    $(window).smartresize(function() {
        fullWidthMobileDropdown();
    });

    // Full Width Dropdown
    function fullWidthMobileDropdown() {
      
      if ( ( full_toggle == false || e_column < 0 ||  e_contain < 0 )  ) {
        return;
      }
      console.log('alert from main menu');
      
      if(window.innerWidth < 1023){
        $scope.find('#main-menu').parent('div').addClass('tab-mob');
        let megaSubMenuDesk = $scope.find('.tab-mob');

        if($scope.closest('.elementor-column').length > 0){
          var eColumn   = $scope.closest('.elementor-column'),
          mWidth 	  = $scope.closest('.elementor-top-section').outerWidth() - 2 * $scope.find('#main-menu').offset().left,
          mPosition = eColumn.offset().left + parseInt(eColumn.css('padding-left'), 10);
          console.log('elementor column');
        } else if($scope.closest('[data-element_type="container"]').length > 0) {
          var eColumn   = $scope.closest('[data-element_type="container"]'),
          mWidth 	  = $scope.closest('.e-con-inner').closest('[data-element_type="container"]').outerWidth() - 2 * $scope.find('#main-menu').offset().left,
          mPosition = eColumn.offset().left + parseInt(eColumn.css('padding-left'), 10);
          console.log('hello');
        }
       
        

          megaSubMenuDesk.css({
          'width' : mWidth +'px',
          'left' : - mPosition +'px'
        });

      }else{
        $scope.find('.tab-mob').removeAttr("style"); 
        $scope.find('#main-menu').parent('div').removeClass('tab-mob');
      }
    }
     

  const content_right = document.querySelector(".ennova-main-menu");
  const bs_sidebar = document.querySelector(".mn-stick");
    if (bs_sidebar) {
      const observer = new IntersectionObserver(
        (entries) => {
          const ent = entries[0];
          ent.isIntersecting == false
          ? bs_sidebar.classList.add("head-is-stuck")
          : bs_sidebar.classList.remove("head-is-stuck");
        },
        {
          root: null,
          rootMargin: "",
          threshold:"",
        }
      );
      observer.observe(content_right);
    }

  
  }

  /**
  * Mega Menu widgets JS
  */
  var WidgetennovaMegaMenu = function( $scope, $ ){ 
  
    if ( 'undefined' == typeof $scope ) {
        return;
    }
  
    var $main = $scope.find( ".main-nav" );
  
    $scope.find('.toggle-icon.open').on("click", function() {
      $main.toggleClass('open-nav');
      $scope.find('.ennova-collapse').toggleClass('responsiv_nav');
      fullWidthMobileDropdown();
      MegaMenuCustomWidth();
    });
  
    $scope.find('.sub-arrow-icon').on("click", function(){
      MegaMenuCustomWidth();
    });

    $scope.find('#main-menu').smartmenus({
      subMenusSubOffsetX: 1,
      subMenusSubOffsetY: -8
    });

      MegaMenuCustomWidth();
      fullWidthMobileDropdown();
    

    // Run Functions on Resize
    $(window).smartresize(function() {
        MegaMenuCustomWidth();
        fullWidthMobileDropdown();
    });

    // Mega Menu Full or Custom Width
    function MegaMenuCustomWidth() {
      let megaItem = $scope.find('.ennova-mega-menu-true');

      megaItem.each(function() {
        if(window.innerWidth > 1023){
          if($(this).hasClass('ennova-mega-menu-width-full')){
            $(this).find('.ennova-sub-mega-menu').parent().addClass('desk-nav');
              var megaSubMenu = $(this).find('.desk-nav');

          }else{
            $(this).find('.ennova-sub-mega-menu').parent().addClass('desk-nav1');
              var megaSubMenu = $(this).find('.desk-nav1');

          }
          
          
          if ( $(this).hasClass('ennova-mega-menu-width-full') ) {
            if($scope.find('.boxy').attr("id") == "flex-star-cls"){
              var left = $scope.find('.boxy').offset().left + 14;
            }else if($scope.find('.boxy').attr("id") == "center-cls"){
              var left = $scope.find('.boxy').offset().left + 60;
            }else{
              var left = $scope.find('.boxy').offset().left + 110;
            }
            
            megaSubMenu.css({
              'max-width' : $(window).width() +'px',
              'left' : -  left +'px',
              'position' : 'absolute',
            });	
          } else if ( $(this).hasClass('ennova-mega-menu-width-custom') ) {
            megaSubMenu.css({
              'width' : $(this).data('custom-width') +'px',
            });
          } else if ( $(this).hasClass('ennova-mega-menu-width-default') && $(this).hasClass('ennova-mega-menu-pos-relative') ) {
            megaSubMenu.css({
              'width' : $(this).closest('.elementor-column').outerWidth() +'px',
            });
          }
        }else{
          $(this).find('.ennova-sub-mega-menu').parent().removeAttr("style"); 
          $(this).find('.ennova-sub-mega-menu').parent().removeClass('desk-nav');
          $(this).find('.ennova-sub-mega-menu').parent().removeAttr("style"); 
          $(this).find('.ennova-sub-mega-menu').parent().removeClass('desk-nav1');
        }
        
      });
    }

    // Full Width Dropdown
    function fullWidthMobileDropdown() {
      if ( ! $scope.hasClass( 'ennova-mobile-menu-full-width' ) || ! $scope.closest('.elementor-column').length ) {
        return;
      }

      if(window.innerWidth < 1023){
        $scope.find('#main-menu').parent('div').addClass('tab-mob');
        let megaSubMenuDesk = $scope.find('.tab-mob');

        var eColumn   = $scope.closest('.elementor-column'),
          mWidth 	  = $scope.closest('.elementor-top-section').outerWidth() - 2 * $scope.find('#main-menu').offset().left,
          mPosition = eColumn.offset().left + parseInt(eColumn.css('padding-left'), 10);

          megaSubMenuDesk.css({
          'width' : mWidth +'px',
          'left' : - mPosition +'px'
        });

      }else{
        $scope.find('.tab-mob').removeAttr("style"); 
        $scope.find('#main-menu').parent('div').removeClass('tab-mob');
      }
    }

     

  const content_right = document.querySelector(".boxy");
  const bs_sidebar = document.querySelector(".mn-stick");
    if (bs_sidebar) {
      const observer = new IntersectionObserver(
        (entries) => {
          const ent = entries[0];
          ent.isIntersecting == false
          ? bs_sidebar.classList.add("head-is-stuck")
          : bs_sidebar.classList.remove("head-is-stuck");
        },
        {
          root: null,
          rootMargin: "",
          threshold:"",
        }
      );
      observer.observe(content_right);
    }
  
  }

  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-nav-menu.default', WidgetennovaNavMenu);
  });

  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-mega-menu.default', WidgetennovaMegaMenu);
  });

  //Dual button
  var WidgetDualButton = function( $scope, $ ){ 

    
   $scope.find('.enn-dual-button.four .enn-btn')
        .on('mouseenter', function(e) {
          var parentOffset = $(this).offset(),
              relX = e.pageX - parentOffset.left,
              relY = e.pageY - parentOffset.top;
          $(this).find('.layer').css({top:relY, left:relX})
        })
        .on('mouseout', function(e) {
          var parentOffset = $(this).offset(),
              relX = e.pageX - parentOffset.left,
              relY = e.pageY - parentOffset.top;
          $(this).find('.layer').css({top:relY, left:relX})
        });

  }

  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-dual-button.default', WidgetDualButton);
  });
  

  var WidgetTimeline = function( $scope, $ ){ 
  // -------------------- TIMELINE ---------------------------- 
  var items = $scope.find(".enn-timeline-items .timeline-dot"),
  timelineHeight = $scope.find(".enn-timeline-items").height(),
  greyLine = $scope.find('.timeline-line'),
  lineToDraw = $scope.find('.timeline-inner-line');

  // sets the height that the greyLine (.default-line) should be according to `.timeline ul` height

  // run this function only if draw line exists on the page
    if(lineToDraw.length) {
      $(window).on('scroll', function () {

        // Need to constantly get '.draw-line' height to compare against '.default-line'
        var redLineHeight = lineToDraw.height(),
        greyLineHeight = greyLine.height(),
        windowDistance = $(window).scrollTop(),
        windowHeight = $(window).height() / 2,
        timelineDistance = $scope.find(".enn-timeline-items").offset().top;

        if(windowDistance >= timelineDistance - windowHeight) {
          line = windowDistance - timelineDistance + windowHeight;

          if(line <= greyLineHeight) {
            lineToDraw.css({
              'height' : line + 8 + 'px'
            });
          }
        }

        // This takes care of adding the class in-view to the li:before items
        var bottom = lineToDraw.offset().top + lineToDraw.outerHeight(true);
        items.each(function(index){
          var circlePosition = $(this).offset();

          if(bottom > circlePosition.top) {				
            $(this).addClass('highlighted-dot');
          } else {
            $(this).removeClass('highlighted-dot');
          }
        });	
      });
    }  
  }

  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-timeline.default', WidgetTimeline);
  });

  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-post-blog-timeline.default', WidgetTimeline);
  });

  var newsticker = function( $scope, $ ){ 
  
    var ticker = $scope.find( ".enn-latest-news" );
    var mainDiv = $scope.find('.enn-latest-news-slider');
    var PauseVal =  (mainDiv.attr('tickerHover') == 'yes' ) ? true : false;
    var tickerSlide = mainDiv.marquee({
      speed: mainDiv.attr('tickerSpeed'),
      direction: mainDiv.attr('tickerDirection'), 
      delayBeforeStart: 0,
      duplicated: true,
      pauseOnHover: PauseVal,
      startVisible: true
    });
    ticker.on( "click", ".enn-latest-play span", function() {
      $(this).find( "i" ).toggleClass( "fa-pause fa-play" )
      tickerSlide.marquee( "toggle" );
    })
  }
  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-post-ticker.default', newsticker);
  });

} )( jQuery );
  
// Resize Function - Debounce
(function($,sr){

  var debounce = function (func, threshold, execAsap) {
      var timeout;

      return function debounced () {
          var obj = this, args = arguments;
          function delayed () {
              if (!execAsap)
                  func.apply(obj, args);
              timeout = null;
          };

          if (timeout)
              clearTimeout(timeout);
          else if (execAsap)
              func.apply(obj, args);

          timeout = setTimeout(delayed, threshold || 100);
      };
  }
  // smartresize 
  jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');
  

var WidgetCartView = function( $scope, $ ){  
// Cart Offcanvas
var condition = $scope.find('.enn-offcanvas');
  if( condition.hasClass('slide') && condition.hasClass('on_click') ){

    //slide on click
    $scope.find('.cart').click( function (s) { 
      var main_slide = $scope.find('.slide.on_click');  
      main_slide.addClass('show-slide');   
    } );
    $scope.find('.enn-offcanvas-close').click(function (s) { 
      var main_slide = $scope.find('.slide.on_click');  
      main_slide.removeClass('show-slide');   
    } );
  }

  else if( condition.hasClass('slide') && condition.hasClass('on_hover') ){ 
    //slide on hover
    $scope.find('.cart').mouseover( function (s) { 
      var main_slide = $scope.find('.slide.on_hover');  
      main_slide.addClass('show-slide');   
    } );
    $scope.find('.enn-offcanvas-close').click(function (s) { 
      var main_slide = $scope.find('.slide.on_hover');  
      main_slide.removeClass('show-slide');   
    } ); 
  }

  else if( condition.hasClass('mini_cart') && condition.hasClass('on_click') ){
    //Mini Cart on click
    $scope.find('.cart').click( function (s) { 
      var main_slide = $scope.find('.mini_cart.on_click');  
      main_slide.addClass('show-drop');   
    } );
    $scope.find('.enn-offcanvas-close').click(function (s) { 
      var main_slide = $scope.find('.mini_cart.on_click');  
      main_slide.removeClass('show-drop');   
    } ); 
  }

  else if( condition.hasClass('mini_cart') && condition.hasClass('on_hover') ){
    //Mini Cart on hover
    $scope.find('.cart').mouseover( function (s) { 
      var main_slide = $scope.find('.mini_cart.on_hover');  
      main_slide.addClass('show-drop');   
    } );
    $scope.find('.enn-offcanvas-close').click(function (s) { 
      var main_slide = $scope.find('.mini_cart.on_hover');  
      main_slide.removeClass('show-drop');   
    } ); 
  }
}

jQuery(window).on('elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction('frontend/element_ready/ennova-cart.default', WidgetCartView);
});

var WidgetProgressBar = function( $scope, $ ){
  const wId = $scope.data("id");

	const wrapper = document.querySelector(`.elementor-element-${wId}`);
  let suffdiv = wrapper.querySelector('.ennova-progress-items');

  let suffix =  suffdiv.getAttribute("prog-suffix");
  const progress_bars = wrapper.querySelector('.enn-pro-percentage');

    let SPEED = 25;

    let limit = parseInt(progress_bars.innerHTML, 10);

    for(let i = 0; i <= limit; i++) {
        setTimeout(function () {
          progress_bars.innerHTML = i + suffix;
        }, SPEED * i);
    }


}
jQuery(window).on('elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction('frontend/element_ready/ennova-progress-bar.default', WidgetProgressBar);
});

const imageHotspot = function( $scope, $ ){

  const wId = $scope.data("id");

	const wrapper = document.querySelector(`.elementor-element-${wId}`);

  let suffdiv = wrapper.querySelector('.enn-image-hotspots');

  let suffix =  suffdiv.getAttribute("tigger");

  if ( suffix === 'by_click' ) {
    $scope.find('.enn-hotspot-item').each(function(){
      $(this).on("click", function() {
        $(this).find('.enn-hotspot-tooltip').toggleClass('enn-tooltip-trigger');
      });
    });
    
  }

};


jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-image-hotspot.default",imageHotspot
	);
});

// Product Banner
const pos = document.documentElement;
pos.addEventListener("mousemove", e =>{
  pos.style.setProperty('--x', e.clientX + "px");
  pos.style.setProperty('--y', e.clientY + "px");
});

const VideoPostWidget = function( $scope, $ ){
  const wId = $scope.attr("data-id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
// Video Post Widget

function Tabs() {
  
  let bindAll = function() {
    let menuElements = wrapper.querySelectorAll('[enn-tab]');
    for(let i = 0; i < menuElements.length ; i++) {
      menuElements[i].addEventListener('click', change, false);
    }
  }

  let clear = function() {
    let menuElements = wrapper.querySelectorAll('[enn-tab]');
    for(let i = 0; i < menuElements.length ; i++) {
      menuElements[i].classList.remove('active');
      let id = menuElements[i].getAttribute('enn-tab');
      console.log(id);
      document.getElementById(id).classList.remove('active');
    }
  }

  let change = function(e) {
    clear();
    e.target.classList.add('active');
    let id = e.currentTarget.getAttribute('enn-tab');
    console.log(id);
    document.getElementById(id).classList.add('active');
  }

  bindAll();
}

let connectTabs = new Tabs();

};

jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-video-post.default",VideoPostWidget
	);
});