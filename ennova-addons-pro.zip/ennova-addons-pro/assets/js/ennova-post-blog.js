const ennovaPostCategoryTab = () => {
	const categoryTabs = document.querySelectorAll(".ennova-pc-tab");

	categoryTabs.forEach((tab) => {
		const dataId = tab.getAttribute("data-wrapper-id");
		console.log(dataId);
		const wrapper = document.querySelector(
			`.ennova-post-category-tab-wrapper.ennova-pc-tab-${dataId}`
		);
		const lists = wrapper.querySelector(`ul.tabs`);

		const outerWrapper = wrapper.querySelector(".outer-wrapper");

		if (outerWrapper) {
			const children = outerWrapper.children;
			Array.from(children).forEach((child) => {
				child.style.display = "none";
			});
		}

		if (lists) {
			const firstListId = lists.querySelector("li").getAttribute("data-id");
			const outerWrapperChild = outerWrapper.querySelector(
				`[data-tab-id="${firstListId}"]`
			);
			outerWrapperChild.style.display = "block";
			lists.addEventListener("click", (e) => {
				if (e.target.tagName === "LI") {
					const activeList = lists.querySelector("li.active");
					const list = e.target;

					if (activeList) {
						activeList.classList.remove("active");
					}
					list.classList.add("active");

					const id = e.target.getAttribute("data-id");
					const children = outerWrapper.children;
					Array.from(children).forEach((child) => {
						if (child.getAttribute("data-tab-id") === id) {
							child.style.display = "block";
						} else {
							child.style.display = "none";
						}
					});
				}
			});
		}
	});
};

jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-post-category-tab.default",
		ennovaPostCategoryTab
	);
});