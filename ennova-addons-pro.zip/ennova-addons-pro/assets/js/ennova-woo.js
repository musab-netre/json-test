/**
  * Woocommerce product quickview js
 **/

var ProductFeatureQuickView = function( $scope, $ ){ 
    const wId = $scope.data("id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	const outerWrapper = wrapper.querySelector(".ennova-outer-wrapper");
    const SwipeExists = wrapper.querySelector('.swiper-container') !== null;
    const PoponeExists = $scope.find('.ennova-popup') !== null;
    $scope.find('.quick-cls').click(function() {
        if(PoponeExists == true){
            $scope.find('.ennova-popup').remove();
        }
        console.log('quick is clicked');
        if(SwipeExists !== true){
            console.log('Swiper not Exist');
            var thisEl = $(this);
            thisEl.parent().parent().toggleClass("popup");
            var product_id = $(this).find('.enn-tooltip').attr('data-prod-id');
            var data = {action: 'woo_quickview', product: product_id};
    
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) {
                    
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    thisEl.parent().parent().append(jsdata);
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('popup')){
                            par.classList.remove('popup');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                    console.log('quick view ajax error');
                },
            });
        }else{
            console.log('Swiper Exist');
            var thisEl = $(this);
            $scope.toggleClass("on_Pup");
            var product_id = $(this).find('.enn-tooltip').attr('data-prod-id');
            var data = {action: 'woo_quickview', product: product_id};
    
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) {
                    
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    $scope.append(jsdata);
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('on_Pup')){
                            par.classList.remove('on_Pup');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                    console.log('quick view ajax error');
                },
            });
        }
    
    });
    
}

jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-slider.default', ProductFeatureQuickView);
});

jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-grid.default', ProductFeatureQuickView);
});

var ProductFeatureCompare = function( $scope, $ ){ 
    const wId = $scope.data("id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	const outerWrapper = wrapper.querySelector(".ennova-outer-wrapper");
    const SwipeExists = wrapper.querySelector('.swiper-container') !== null;
    const PoponeExists = $scope.find('.ennova-popup') !== null;
    $scope.find('.compare-cls').click(function() {
        if(PoponeExists == true){
            $scope.find('.ennova-popup_two').remove();
        }
        console.log('compare is clicked');
        if(SwipeExists !== true){
            console.log('Swiper not Exist');
            var thisEl = $(this);
            thisEl.parent().parent().toggleClass("compareOn");
            var product_compare_id = thisEl.parents('.ennova-outer-wrapper').attr('compare-cat');
            var product_id = $(this).prev().find('.enn-tooltip').attr('data-prod-id');
            product_compare_id = !(product_compare_id == '') ? product_compare_id : 'blank';
            var data = {action: 'woo_compare_list', product_compare: product_compare_id, product_id: product_id};
    
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) {
                    
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    thisEl.parent().parent().append(jsdata);
    
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.cmr-close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('compareOn')){
                            par.classList.remove('compareOn');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                    
                    $('.compare-btn').click(function() {
                        var elements = document.querySelectorAll(".compare-product");
                        var count = elements.length;
                        console.log("Number of elements selected: " + count);
                        if(count  < 5 ){
                        var comthis = $(this);
                        var compared_product_id = comthis.attr('prod-com-id');
                        var data = {action: 'woo_compare',compared_product_id: compared_product_id};
                        
                    
                        $.ajax({
                            url: myajax.ajaxurl,
                            type: "POST",
                            data: data,
                            success: function (response) {
                                
                                var jsdata = JSON.parse(response.data);
                                comthis.parents('.compare-table').find('.compare-product-selected').append(jsdata);
                
                            },
                            complete: function() {
                                $('.com-rev a').click(function() {
                                    $(this).parents('.compare-product').remove();
                                });
                                //  var quick_view = document.querySelectorAll('.cmr-close-btn');
                                //  for (var i = 0; i < quick_view.length; i++) {
                                //      quick_view[i].addEventListener('click', function(event) {
                                        
                                //          var par = this.parentElement.parentElement.parentElement;
                                //          if(par.classList.contains('compareOn')){
                                //          par.classList.remove('compareOn');
                                //          this.parentElement.parentElement.remove();
                
                                //          }
                                //      });
                                //  }
                                // document.addEventListener('click', function(){
                                //     var close_view = document.querySelector('.cmr-close-btn');
                                //     var par = close_view.parentElement.parentElement.parentElement;
                                //     if(par.classList.contains('compareOn')){
                                //         par.classList.remove('compareOn');
                                //         close_view.parentElement.parentElement.remove();
                
                                //     }
                                    
                                // })
                            },
                            error: function(errorThrown){
                                console.log(errorThrown);
                            },
                        });

                        }
                    
                    });
                    
                    
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                },
            });
        }else{
            console.log('Swiper Exist');
    
            var thisEl = $(this);
            $scope.toggleClass("on_Pup-compare");
            var product_compare_id = thisEl.parents('.ennova-outer-wrapper').attr('compare-cat');
            var product_id = $(this).prev().find('.enn-tooltip').attr('data-prod-id');
            product_compare_id = !(product_compare_id == '') ? product_compare_id : 'blank';
            var data = {action: 'woo_compare_list', product_compare: product_compare_id, product_id: product_id};
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) { 
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    $scope.append(jsdata);
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.cmr-close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('on_Pup-compare')){
                            par.classList.remove('on_Pup-compare');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                    
    
                    $('.compare-btn').click(function() {
                        var elements = document.querySelectorAll(".compare-product");
                        var count = elements.length;
                        console.log("Number of elements selected: " + count);
                        if(count  < 5 ){
                        var comthis = $(this);      
                        var compared_product_id = comthis.attr('prod-com-id');
                        var data = {action: 'woo_compare',compared_product_id: compared_product_id};
                        
                    
                        $.ajax({
                            url: myajax.ajaxurl,
                            type: "POST",
                            data: data,
                            success: function (response) {
                                
                                var jsdata = JSON.parse(response.data);
                                comthis.parents('.compare-table').find('.compare-product-selected').append(jsdata);
                
                            },
                            complete: function() {
                                $('.com-rev a').click(function() {
                                    $(this).parents('.compare-product').remove();
                                });
                                //  var quick_view = document.querySelectorAll('.cmr-close-btn');
                                //  for (var i = 0; i < quick_view.length; i++) {
                                //      quick_view[i].addEventListener('click', function(event) {
                                        
                                //          var par = this.parentElement.parentElement.parentElement;
                                //          if(par.classList.contains('compareOn')){
                                //          par.classList.remove('compareOn');
                                //          this.parentElement.parentElement.remove();
                
                                //          }
                                //      });
                                //  }
                                // document.addEventListener('click', function(){
                                //     var close_view = document.querySelector('.cmr-close-btn');
                                //     var par = close_view.parentElement.parentElement.parentElement;
                                //     if(par.classList.contains('compareOn')){
                                //         par.classList.remove('compareOn');
                                //         close_view.parentElement.parentElement.remove();
                
                                //     }
                                    
                                // })
                            },
                            error: function(errorThrown){
                                console.log(errorThrown);
                            },
                        });

                        }
                    
                    });
                    
                    
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                },
            });
        }
    
    });
    
}

jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-slider.default', ProductFeatureCompare);
});

jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-grid.default', ProductFeatureCompare);
});