const fn = function ($scope, $) {
	const wId = $scope.data("id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	const outerWrapper = wrapper.querySelector(".ennova-outer-wrapper");

	if (!outerWrapper) return;

	const widgetId = outerWrapper.getAttribute("data-wid");

	const sliderWrapper = document.querySelector(`#ennova_slider_${widgetId}`);

	if (!sliderWrapper) return;

	const slideToShow = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show")
	);
	const slideToShowMobile = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show-mobile")
	);
	const slideToShowTablet = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show-tablet")
	);
	const slideToScroll = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll")
	);
	const slideToScrollMobile = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll-mobile")
	);
	const slideToScrollTablet = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll-tablet")
	);
	const slideSpaceBetween = sliderWrapper.getAttribute(
		"data-slides-space-between"
	);
	const slideSpaceBetweenMobile = sliderWrapper.getAttribute(
		"data-slides-space-between-mobile"
	);
	const slideSpaceBetweenTablet = sliderWrapper.getAttribute(
		"data-slides-space-between-tablet"
	);

	const autoplay = sliderWrapper.getAttribute("data-autoplay");
	const autoplaySpeed = sliderWrapper.getAttribute("data-autoplay-speed");

	const transitionBetweenSlides = parseInt(
		sliderWrapper.getAttribute("data-transition_between_slides")
	);
	
	const loop = sliderWrapper.getAttribute("data-loop");
	const mousewheel = sliderWrapper.getAttribute("data-mousewheel");
	const keyboardControl = sliderWrapper.getAttribute("data-keyboard_control");
	const clickable = sliderWrapper.getAttribute("data-clickable");

	const swiperClass = `.swiper-${widgetId}`;

	const swiper = new Swiper(swiperClass, {
		loop,
		autoplay: autoplay
			? {
					delay: autoplaySpeed,
					disableOnInteraction: false,
			  }
			: false,
		mousewheel: mousewheel
			? {
					enable: true,
			  }
			: false,
		keyboardControl,
		speed: transitionBetweenSlides,
		scrollbar: {
			el: ".swiper-scrollbar",
			draggable: true,
			hide: true,
			snapOnRelease: true,
		},
		// If we need pagination
		pagination: {
			el: ".swiper-pagination",
			clickable,
		},
		// Navigation arrows
		navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
		breakpoints: {
			// when window width is >= 320px
			320: {
				slidesPerView: slideToShowMobile,
				spaceBetween: slideSpaceBetweenMobile,
				slidesPerGroup: slideToScrollMobile,
				// direction: directionMobile,
			},
			// when window width is >= 480px
			767: {
				slidesPerView: slideToShowTablet,
				spaceBetween: slideSpaceBetweenTablet,
				slidesPerGroup: slideToScrollTablet,
				// direction: directionTablet,
			},
			// when window width is >= 640px
			1024: {
				slidesPerView: slideToShow,
				spaceBetween: slideSpaceBetween,
				slidesPerGroup: slideToScroll,
				// direction: direction,
			},
		},
	});
};

const tabs = ($scope, $) => {
	const wId = $scope.data("id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	const outerWrapper = wrapper.querySelector(".ennova-outer-wrapper");

	if (!outerWrapper) return;
	const widgetId = outerWrapper.getAttribute("data-wid");
	const sliderWrapper = document.querySelector(`#ennova_slider_${widgetId}`);

	const swiperClass = `.swiper-${widgetId}`;
	const tabs = $scope.find(".ennova-product-tabs-grid");

	const change = (id) => {
		if (!id) return;
		if (sliderWrapper) swiper();
	};

	if (!sliderWrapper) {
		const prodGrid = document.querySelector(".ennova-product-grid-wrapper");
		change(prodGrid.getAttribute("data-first_tab_id"));
	}

	if (tabs.length > 0) {
		tabs.each(function (index, tab) {
			$(tab)
				.find(".tabs li")
				.click(function (e) {
					e.preventDefault();
					const id = $(this).data("id");
					const sliders = document.querySelectorAll(
						`.ennova_product_wrapper.ennova-${widgetId}`
					);
					const selectedTab = document.querySelector(
						`.ennova_product_wrapper.${id}`
					);
					[...sliders].forEach((slider) => {
						slider.classList.add("ennova_hide");
					});
					selectedTab.classList.remove("ennova_hide");
					change(id);
					$(this).siblings().removeClass("active");
					$(this)
						.parents(".ennova-product-tabs-grid")
						.find(".products")
						.removeClass("active");

					$(this).addClass("active");
					$(this)
						.parents(".ennova-product-tabs-grid")
						.find(`#${id}`)
						.addClass("active");
				});
		});
	}

	if (!sliderWrapper) return;
	const firstTabId = sliderWrapper.getAttribute("data-first_tab_id");

	const slideToShow = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show")
	);
	const slideToShowMobile = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show-mobile")
	);
	const slideToShowTablet = parseInt(
		sliderWrapper.getAttribute("data-slide-to-show-tablet")
	);
	const slideToScroll = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll")
	);
	const slideToScrollMobile = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll-mobile")
	);
	const slideToScrollTablet = parseInt(
		sliderWrapper.getAttribute("data-slides-to-scroll-tablet")
	);
	const slideSpaceBetween = sliderWrapper.getAttribute(
		"data-slides-space-between"
	);
	const slideSpaceBetweenMobile = sliderWrapper.getAttribute(
		"data-slides-space-between-mobile"
	);
	const slideSpaceBetweenTablet = sliderWrapper.getAttribute(
		"data-slides-space-between-tablet"
	);
	const autoplay = sliderWrapper.getAttribute("data-autoplay");
	const autoplaySpeed = sliderWrapper.getAttribute("data-autoplay-speed");

	const transitionBetweenSlides = parseInt(
		sliderWrapper.getAttribute("data-transition_between_slides")
	);
	const loop = sliderWrapper.getAttribute("data-loop");
	const mousewheel = sliderWrapper.getAttribute("data-mousewheel");
	const keyboardControl = sliderWrapper.getAttribute("data-keyboard_control");
	const clickable = sliderWrapper.getAttribute("data-clickable");

	const swiper = () => {
		const swiper = new Swiper(swiperClass, {
			loop,
			autoplay: autoplay
				? {
						delay: autoplaySpeed,
						disableOnInteraction: false,
				  }
				: false,
			mousewheel: mousewheel
				? {
						enable: true,
				  }
				: false,
			keyboardControl,
			speed: transitionBetweenSlides,
			scrollbar: {
				el: ".swiper-scrollbar",
				draggable: true,
				hide: true,
				snapOnRelease: true,
			},
			// If we need pagination
			pagination: {
				el: ".swiper-pagination",
				clickable,
			},
			// Navigation arrows
			navigation: {
				nextEl: ".swiper-button-next",
				prevEl: ".swiper-button-prev",
			},
			breakpoints: {
				// when window width is >= 320px
				320: {
					slidesPerView: slideToShowMobile,
					spaceBetween: slideSpaceBetweenMobile,
					slidesPerGroup: slideToScrollMobile,
					// direction: directionMobile,
				},
				// when window width is >= 480px
				767: {
					slidesPerView: slideToShowTablet,
					spaceBetween: slideSpaceBetweenTablet,
					slidesPerGroup: slideToScrollTablet,
					// direction: directionTablet,
				},
				// when window width is >= 640px
				1024: {
					slidesPerView: slideToShow,
					spaceBetween: slideSpaceBetween,
					slidesPerGroup: slideToScroll,
					// direction: direction,
				},
			},
		});
	};
	change(firstTabId);
};

jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-slider.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-category-slider.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-slider-widget.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-product-category-tab.default",
		tabs
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-blog-carousel.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-service-carousel.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-testimonial-carousel.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-portfolio-carousel.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-team-carousel.default",
		fn
	);
});
jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-product-slider.default",
		fn
	);
});