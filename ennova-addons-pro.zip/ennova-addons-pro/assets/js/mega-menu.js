jQuery(document).ready(function( $ ) {
	"use strict";

    var EnnovaMegaMenuSettings = {

        getLiveSettings: EnnovaMegaMenuSettingsData.settingsData,

        init: function() {
            EnnovaMegaMenuSettings.initSettingsButtons();
        },

        initSettingsButtons: function() {
            $( '#menu-to-edit .menu-item' ).each( function() {
                var $this = $(this),
                    id = EnnovaMegaMenuSettings.getNavItemId($this),
                    depth = EnnovaMegaMenuSettings.getNavItemDepth($this);
                    
                // Settings Button
                $this.find(".ennova-mm-settings-btn").length < 1 && $(".item-title", $this).append('<a class="ennova-mm-settings-btn" data-id="'+ id +'" data-depth="'+ depth +'">Mega Menu</a>');
            });
            
            // Open Popup
            $('.ennova-mm-settings-btn').on( 'click', EnnovaMegaMenuSettings.openSettingsPopup );
        },

        openSettingsPopup: function() {
            // Set Settings
            EnnovaMegaMenuSettings.setSettings( $(this) );

            // Show Popup
            $('.ennova-mm-settings-popup-wrap').fadeIn();

            // Close Temmplate Editor Popup
            EnnovaMegaMenuSettings.closeTemplateEditorPopup();

            // Menu Width
            EnnovaMegaMenuSettings.initMenuWidthToggle();

            // Mobile Content
            EnnovaMegaMenuSettings.initMobileContentToggle();

            // Color Pickers
            EnnovaMegaMenuSettings.initColorPickers();

            // Icon Picker
            EnnovaMegaMenuSettings.initIconPicker();

            // Close Settings Popup
            EnnovaMegaMenuSettings.closeSettingsPopup();

            // Save Settings
            EnnovaMegaMenuSettings.saveSettings( $(this) );

            // Edit Menu Button
            EnnovaMegaMenuSettings.initEditMenuButton( $(this) );

            // Set Tite
            $('.ennova-mm-popup-title').find('span').text( $(this).closest('li').find('.menu-item-title').text() );
        },

        closeSettingsPopup: function() {
            $('.ennova-mm-settings-close-popup-btn').on('click', function() {
                $('.ennova-mm-settings-popup-wrap').fadeOut();
            });

            $('.ennova-mm-settings-popup-wrap').on('click', function(e) {
                if(e.target !== e.currentTarget) return;
                $(this).fadeOut();
            });

            // Unbind Click
            $('.ennova-save-mega-menu-btn').off('click');
            $('.ennova-edit-mega-menu-btn').off('click');
        },

        initEditMenuButton: function( selector ) {
            $('.ennova-edit-mega-menu-btn').on('click', function() {
                var id = selector.attr('data-id'),
                    depth = selector.attr('data-depth');

                EnnovaMegaMenuSettings.createOrEditMenuTemplate(id, depth);
            });
        },

		createOrEditMenuTemplate: function(id, depth) {
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'ennova_create_mega_menu_template',
                    nonce: EnnovaMegaMenuSettingsData.nonce,
                    item_id: id,
                    item_depth: depth
				},
				success: function( response ) {
                    console.log(response.data['edit_link']);
                    EnnovaMegaMenuSettings.openTemplateEditorPopup(response.data['edit_link']);
				}
			});
		},

        openTemplateEditorPopup: function( editorLink ) {
            $('.ennova-mm-editor-popup-wrap').fadeIn();

            if ( !$('.ennova-mm-editor-popup-iframe').find('iframe').length ) {
                $('.ennova-mm-editor-popup-iframe').append('<iframe src="'+ editorLink +'" width="100%" height="100%"></iframe>');
            }

            // $('body').css('overflow','hidden');
        },

        closeTemplateEditorPopup: function() {
            $('.ennova-mm-editor-close-popup-btn').on('click', function() {
                $('.ennova-mm-editor-popup-wrap').fadeOut();
                setTimeout(function() {
                    $('.ennova-mm-editor-popup-iframe').find('iframe').remove();
                    // $('body').css('overflow','visible');
                }, 1000);
            });
        },

        initColorPickers: function() {
            $('.ennova-mm-setting-color').find('input').wpColorPicker();

            // Fix Color Picker
            if ( $('.ennova-mm-setting-color').length ) {
                $('.ennova-mm-setting-color').find('.wp-color-result-text').text('Select Color');
                $('.ennova-mm-setting-color').find('.wp-picker-clear').val('Clear');
            }
        },

        initIconPicker: function() {
            $('#ennova_mm_icon_picker').iconpicker();

            // Bind iconpicker events to the element
            $('#ennova_mm_icon_picker').on('iconpickerSelected', function(event) {
                $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                $('.ennova-mm-setting-icon div span:last-child').addClass('ennova-mm-active-icon');
                $('.ennova-mm-setting-icon div span:last-child i').removeAttr('class');
                $('.ennova-mm-setting-icon div span:last-child i').addClass(event.iconpickerValue);
            });

            // Bind iconpicker events to the element
            $('#ennova_mm_icon_picker').on('iconpickerHide', function(event) {
                setTimeout(function() {
                    if ( 'ennova-mm-active-icon' == $('.ennova-mm-setting-icon div span:first-child').attr('class') ) {
                        $('#ennova_mm_icon_picker').val('')
                    }

                    $('.ennova-mm-settings-wrap').removeAttr('style');
                },100);
            });

            $('.ennova-mm-setting-icon div span:first-child').on('click', function() {
                $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                $(this).addClass('ennova-mm-active-icon');
            });

            $('.ennova-mm-setting-icon div span:last-child').on('click', function() {
                $('#ennova_mm_icon_picker').focus();
                $('.ennova-mm-settings-wrap').css('overflow', 'hidden');
            });
        },

        saveSettings: function( selector ) {
            var $saveButton = $('.ennova-save-mega-menu-btn');

            // Reset
            $saveButton.text('Save');

            $saveButton.on('click', function() {
                var id = selector.attr('data-id'),
                    depth = selector.attr('data-depth'),
                    settings = EnnovaMegaMenuSettings.getSettings();

                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: {
                        action: 'ennova_save_mega_menu_settings',
                        nonce: EnnovaMegaMenuSettingsData.nonce,
                        item_id: id,
                        item_depth: depth,
                        item_settings: settings
                    },
                    success: function( response ) {
                        $saveButton.text('Saved');
                        $saveButton.append('<span class="dashicons dashicons-yes"></span>');

                        setTimeout(function() {
                            $saveButton.find('.dashicons').remove();
                            $saveButton.text('Save');
                            $saveButton.blur();
                        }, 1000);

                        // Update Settings
                        EnnovaMegaMenuSettings.getLiveSettings[id] = settings;
                    }
                });
            });
            
        },

        getSettings: function() {
            var settings = {};

            $('.ennova-mm-setting').each(function() {
                var $this = $(this),
                    checkbox = $this.find('input[type="checkbox"]'),
                    select = $this.find('select'),
                    number = $this.find('input[type="number"]'),
                    text = $this.find('input[type="text"]');

                // Checkbox
                if ( checkbox.length ) {
                    let id = checkbox.attr('id');
                    settings[id] = checkbox.prop('checked') ? 'true' : 'false';
                }

                // Select
                if ( select.length ) {
                    let id = select.attr('id');
                    settings[id] = select.val();
                }
                
                // Multi Value
                // if ( $this.hasClass('ennova-mm-setting-radius') ) {
                //     let multiValue = [],
                //         id = $this.find('input').attr('id');

                //     $this.find('input').each(function() {
                //         multiValue.push($(this).val());
                //     });

                //     settings[id] = multiValue;
                // }

                // Number
                if ( number.length ) {
                    let id = number.attr('id');
                    settings[id] = number.val();
                }
                
                // Text
                if ( text.length ) {
                    let id = text.attr('id');

                    if ( 'ennova_mm_icon_picker' !== id ) {
                        settings[id] = text.val();
                    } else {
                        let icon_class = $('.ennova-mm-setting-icon div span.ennova-mm-active-icon').find('i').attr('class');
                        settings[id] = 'fas fa-ban' !== icon_class ? icon_class : '';
                    }
                }
            });

            return settings;
        },

		getNavItemId: function( item ) {
			var id = item.attr( 'id' );
			return id.replace( 'menu-item-', '' );
		},

		getNavItemDepth: function( item ) {
			var depthClass = item.attr( 'class' ).match( /menu-item-depth-\d/ );

			if ( ! depthClass[0] ) {
				return 0;
			} else {
                return depthClass[0].replace( 'menu-item-depth-', '' );
            }
		},

        initMenuWidthToggle: function() {
            var select = $('#ennova_mm_width'),
                option = $('#ennova_mm_custom_width').closest('.ennova-mm-setting');
            
            if ( 'custom' === select.val() ) {
                option.show();
            } else {
                option.hide();
            }

            select.on('change', function() {
                if ( 'custom' === select.val() ) {
                    option.show();
                } else {
                    option.hide();
                }            
            });
        },

        initMobileContentToggle: function() {
            var select = $('#ennova_mm_mobile_content'),
                option = $('#ennova_mm_render').closest('.ennova-mm-setting');
            
            if ( 'mega' === select.val() ) {
                option.show();
            } else {
                option.hide();
            }

            select.on('change', function() {
                if ( 'mega' === select.val() ) {
                    option.show();
                } else {
                    option.hide();
                }            
            });
        },

        setSettings: function( selector ) {
            var id = selector.attr('data-id'),
                settings = EnnovaMegaMenuSettings.getLiveSettings[id];

            if ( ! $.isEmptyObject(settings) ) {
                // General
                if ( 'true' == settings['ennova_mm_enable'] ) {
                    $('#ennova_mm_enable').prop( 'checked', true );
                } else {
                    $('#ennova_mm_enable').prop( 'checked', false );
                }
                $('#ennova_mm_position').val(settings['ennova_mm_position']).trigger('change');
                $('#ennova_mm_width').val(settings['ennova_mm_width']).trigger('change');
                $('#ennova_mm_custom_width').val(settings['ennova_mm_custom_width']);
                $('#ennova_mm_render').val(settings['ennova_mm_render']).trigger('change');
                $('#ennova_mm_mobile_content').val(settings['ennova_mm_mobile_content']).trigger('change');

                // Icon
                if ( '' !== settings['ennova_mm_icon_picker'] ) {
                    $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:last-child').addClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:last-child i').removeAttr('class');
                    $('.ennova-mm-setting-icon div span:last-child i').addClass(settings['ennova_mm_icon_picker']);
                } else {
                    $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:first-child').addClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:last-child i').removeAttr('class');
                    $('.ennova-mm-setting-icon div span:last-child i').addClass('fas fa-angle-down');
                }
                $('#ennova_mm_icon_color').val(settings['ennova_mm_icon_color']).trigger('keyup');
                $('#ennova_mm_icon_size').val(settings['ennova_mm_icon_size']);

                // Badge
                $('#ennova_mm_badge_text').val(settings['ennova_mm_badge_text']);
                $('#ennova_mm_badge_color').val(settings['ennova_mm_badge_color']).trigger('keyup');
                $('#ennova_mm_badge_bg_color').val(settings['ennova_mm_badge_bg_color']).trigger('keyup');
                if ( 'true' == settings['ennova_mm_badge_animation'] ) {
                    $('#ennova_mm_badge_animation').prop( 'checked', true );
                } else {
                    $('#ennova_mm_badge_animation').prop( 'checked', false );
                }

            // Default Values
            } else {
                // General
                $('#ennova_mm_enable').prop( 'checked', false );
                $('#ennova_mm_position').val('default').trigger('change');
                $('#ennova_mm_width').val('default').trigger('change');
                $('#ennova_mm_custom_width').val('600');
                $('#ennova_mm_render').val('default').trigger('change');
                $('#ennova_mm_mobile_content').val('mega').trigger('change');

                // Icon
                if ( '' !== settings['ennova_mm_icon_picker'] ) {
                    $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:first-child').addClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:last-child i').removeAttr('class');
                    $('.ennova-mm-setting-icon div span:last-child i').addClass('fas fa-angle-down');
                }
                $('#ennova_mm_icon_color').val('').trigger('change');
                $('#ennova_mm_icon_size').val('');

                // Badge
                $('#ennova_mm_badge_text').val('');
                $('#ennova_mm_badge_color').val('#ffffff').trigger('keyup');
                $('#ennova_mm_badge_bg_color').val('#000000').trigger('keyup');
                $('#ennova_mm_badge_animation').prop( 'checked', false );
            }

            if ( 'false' === $('.ennova-mm-settings-wrap').attr('data-pro-active') ) {
                $('#ennova_mm_render').val('default').trigger('change');
                $('#ennova_mm_mobile_content').val('mega').trigger('change');

                // Icon
                if ( '' !== settings['ennova_mm_icon_picker'] ) {
                    $('.ennova-mm-setting-icon div span').removeClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:first-child').addClass('ennova-mm-active-icon');
                    $('.ennova-mm-setting-icon div span:last-child i').removeAttr('class');
                    $('.ennova-mm-setting-icon div span:last-child i').addClass('fas fa-angle-down');
                }
                $('#ennova_mm_icon_color').val('').trigger('change');
                $('#ennova_mm_icon_size').val('');

                // Badge
                $('#ennova_mm_badge_text').val('');
                $('#ennova_mm_badge_color').val('#ffffff').trigger('keyup');
                $('#ennova_mm_badge_bg_color').val('#000000').trigger('keyup');
                $('#ennova_mm_badge_animation').prop( 'checked', false );
            }
        }
    }

    // Init
    EnnovaMegaMenuSettings.init();

});