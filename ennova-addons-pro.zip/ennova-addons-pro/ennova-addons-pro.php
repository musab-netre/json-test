<?php
/**
 * Plugin Name: Ennova Addons for Elementor - Pro
 * Description: High quality addons for elementor
 * Author: Themeansar
 * Author URI: https://themeansar.com/
 * Version: 0.0.1
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ennova-addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once plugin_dir_path( __FILE__ ) . "ennova-constant.php";
if ( !class_exists('ENNOVA_ADDONS') ) {
	// die("pro");
	  
	class ENNOVA_ADDONS {

		private static $instance;

		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new ENNOVA_ADDONS();
				self::$instance->init();
			}
			return self::$instance;
		}
		//Empty Construct
		public function __construct() {     }

		//initialize Plugin
		public function init() {
			$this->include_files();
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_hf_create_category' ] ); // Add a custom header footer category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_create_category' ] ); // Add a custom category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_blog_create_category' ] ); // Add a custom blog category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_woo_create_category' ] ); // Add a custom woo category for panel widgets
			add_filter( 'elementor/elements/categories', [ $this, 'set_custom_widget_category_priority' ] );

			add_action( 'admin_init', function() {
				if ( ennova_is_free_active() ) {
					deactivate_plugins('ennova-addons/ennova-addons.php' );
				}
			} );
		}

		//Include all files
		public function include_files() {
			require_once ENNOVA_PATH . 'inc/ennova-mega-menu-walker.php';
			require_once ENNOVA_PATH . 'inc/ennova-custom-navwalker.php';
			require_once ENNOVA_PATH . 'inc/classes/utils.php';
			require_once ENNOVA_PATH . 'inc/bootstrap.php';
		}
		
		//Elementor new category register method
		// add category for header & footer
		public function wc_hf_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-hf-element',
				[
					'title' => __( 'Ennova Header & Footer', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		// add category for Blog
		public function wc_blog_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-blog-element',
				[
					'title' => __( 'Ennova Blog', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		// add category for woocommerce
		public function wc_woo_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-woo-element',
				[
					'title' => __( 'Ennova Woocommerce', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		public function wc_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-element',
				[
					'title' => __( 'Ennova Addons', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		function set_custom_widget_category_priority( $categories ) {
			
			if ( isset( $categories['wc-hf-element'] ) ) {
				$categories['wc-hf-element']->set_priority( 1 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-blog-element'] ) ) {
				$categories['wc-blog-element']->set_priority( 2 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-woo-element'] ) ) {
				$categories['wc-woo-element']->set_priority( 3 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-element'] ) ) {
				$categories['wc-element']->set_priority( 4 ); // Set priority to 1 for top position
			}
			return $categories;
		}

		// prevent the instance from being cloned
		public function __clone() {     }

		// prevent from being unserialized
		public function __wakeup() {    }
	}
	require_once plugin_dir_path( __FILE__ ) . '/inc/class-ennova-header-footer-elementor.php';
	function ennova_addons_register_function() {
		$WPCE_SLIDER = ENNOVA_ADDONS::get_instance();
		Ennova_Header_Footer_Elementor::instance();
	}
	add_action( 'plugins_loaded', 'ennova_addons_register_function' );

	function ennova_addons_activate() {
		set_transient('ennova_addons_do_activation_redirect', true, 60);
	}
	
	function ennova_addons_redirect() {
		if (get_transient('ennova_addons_do_activation_redirect')) {
			delete_transient('ennova_addons_do_activation_redirect');
	
			if ( !isset($_GET['activate-multi']) ) {
				wp_redirect('admin.php?page=ennova_admin_menu');
			}
		}
	}
	
	if ( did_action( 'elementor/loaded' ) ) {
		register_activation_hook(__FILE__, 'ennova_addons_activate');
		add_action('admin_init', 'ennova_addons_redirect');
	} 
} else {

	if (
		! function_exists( 'ennova_is_free_active' )
	) {
		function ennova_is_free_active() {
			return is_plugin_active(plugin_dir_url( __FILE__ ).'ennova-addons/ennova-addons.php');
		}
	}

	if (
		! function_exists( 'ennova_show_disable_free_notice' )
	) {
		function ennova_show_disable_free_notice() {
			$deactivate_url = wp_nonce_url( self_admin_url( 'plugins.php?action=deactivate&plugin=ennova-addons/ennova-addons.php' ), 'deactivate-plugin_ennova-addons/ennova-addons.php' );
			$classnames = '';

			?>
				<div class="notice notice-info is-dismissible <?php echo $classnames ?>">
					<p>
					You have <b>Ennova Pro</b> installed you can disable and delete the <b>free</b> plugin.
					<a href="<?php echo esc_url( $deactivate_url ); ?>" class="button-primary">Deactivate free plugin</a>
					</p>
				</div>
			<?php
		}
	}

	add_action( 'admin_init', function() {
		if ( ennova_is_free_active() ) {
			deactivate_plugins( plugin_dir_url( __FILE__ ).'ennova-addons/ennova-addons.php' );
			// ennova_show_disable_free_notice();
		}
	} );
}

// Add Cetegory Image  
if ( ! class_exists( 'ENN_CT_TAX_META' ) ) {

	class ENN_CT_TAX_META {
	
		public function __construct() {
			//
		}
	 
		/*
		* Initialize the class and start calling our hooks and filters
		* @since 1.0.0
		*/
		public function init() {
			add_action( 'category_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
			add_action( 'created_category', array ( $this, 'save_category_image' ), 10, 2 );
			add_action( 'category_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
			add_action( 'edited_category', array ( $this, 'updated_category_image' ), 10, 2 );
			add_action( 'admin_enqueue_scripts', array( $this, 'load_media' ) );
			add_action( 'admin_footer', array ( $this, 'add_script' ) );
		}
	
		public function load_media() {
			wp_enqueue_media();
		}
	 
		/*
		* Add a form field in the new category page
		* @since 1.0.0
		*/
		public function add_category_image ( $taxonomy ) { ?>
		<div class="form-field term-group">
				<label for="category-image-id"><?php _e('Add Category Image', 'ennova-addons'); ?></label>
				<input type="hidden" id="category-image-id" name="category-image-id" class="custom_media_url" value="">
				<div id="category-image-wrapper"></div>
				<p>
				<input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'ennova-addons' ); ?>" />
				<input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'ennova-addons' ); ?>" />
				</p>
            	<p><?php _e('Select Image for this category','ennova-addons');?></p>
		</div>
		<?php
		}
	 
		/*
		* Save the form field
		* @since 1.0.0
		*/
		public function save_category_image ( $term_id, $tt_id ) {
			if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
				$image = $_POST['category-image-id'];
				add_term_meta( $term_id, 'category-image-id', $image, true );
			}
		}
	 
		/*
		* Edit the form field
		* @since 1.0.0
		*/
		public function update_category_image ( $term, $taxonomy ) { ?>
			<tr class="form-field term-group-wrap">
				<th scope="row">
				<label for="category-image-id"><?php _e( 'Add Category Image', 'ennova-addons' ); ?></label>
				</th>
				<td>
				<?php $image_id = get_term_meta ( $term -> term_id, 'category-image-id', true ); ?>
				<input type="hidden" id="category-image-id" name="category-image-id" value="<?php echo $image_id; ?>">
				<div id="category-image-wrapper">
					<?php if ( $image_id ) { ?>
					<?php echo wp_get_attachment_image ( $image_id, 'thumbnail' ); ?>
					<?php } ?>
				</div>
				<p>
					<input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'ennova-addons' ); ?>" />
					<input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'ennova-addons' ); ?>" />
				</p>
            	<p class="description"><?php _e('Select Image for this category','ennova-addons');?></p>
				</td>
			</tr>
		<?php
		}

		/*
		* Update the form field value
		* @since 1.0.0
		*/
		public function updated_category_image ( $term_id, $tt_id ) {
			if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
				$image = $_POST['category-image-id'];
				update_term_meta ( $term_id, 'category-image-id', $image );
			} else {
				update_term_meta ( $term_id, 'category-image-id', '' );
			}
		}
	
		/*
		* Add script
		* @since 1.0.0
		*/
		public function add_script() { ?>
			<script>
			jQuery(document).ready( function($) {
				function ct_media_upload(button_class) {
					var _custom_media = true,
					_orig_send_attachment = wp.media.editor.send.attachment;
					$('body').on('click', button_class, function(e) {
					var button_id = '#'+$(this).attr('id');
					var send_attachment_bkp = wp.media.editor.send.attachment;
					var button = $(button_id);
					_custom_media = true;
					wp.media.editor.send.attachment = function(props, attachment){
						if ( _custom_media ) {
						$('#category-image-id').val(attachment.id);
						$('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
						$('#category-image-wrapper .custom_media_image').attr('src',attachment.url).css('display','block');
						} else {
						return _orig_send_attachment.apply( button_id, [props, attachment] );
						}
					}
					wp.media.editor.open(button);
					return false;
				});
				}
				ct_media_upload('.ct_tax_media_button.button'); 
				$('body').on('click','.ct_tax_media_remove',function(){
				$('#category-image-id').val('');
				$('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
				});
				// Thanks: http://stackoverflow.com/questions/15281995/wordpress-create-category-ajax-response
				$(document).ajaxComplete(function(event, xhr, settings) {
				var queryStringArr = settings.data.split('&');
				if( $.inArray('action=add-tag', queryStringArr) !== -1 ){
					var xml = xhr.responseXML;
					$response = $(xml).find('term_id').text();
					if($response!=""){
					// Clear the thumb image
					$('#category-image-wrapper').html('');
					}
				}
				});
			});
			</script>
		<?php }
	}
	 
	$ENN_CT_TAX_META = new ENN_CT_TAX_META();
	$ENN_CT_TAX_META -> init();
	 
}

// Add Video URL on Post 

function add_enn_custom_meta_box() {
    add_meta_box("enn-meta-box", "Ennova Meta Box", "custom_enn_meta_box_markup", "post", "normal", "high");
}

add_action("add_meta_boxes", "add_enn_custom_meta_box");

function custom_enn_meta_box_markup()
{
	global $post;
	wp_nonce_field(basename(__FILE__), "enn-meta-box-nonce");

    ?>
        <div>
            <label for="enn-meta-box-text">Youtube Video ID:</label>
            <input name="enn_video_url" type="text" value="<?php echo get_post_meta($post->ID, "enn_video_url", true); ?>">
			<p class="description"><?php _e('e.g. 255CSHjfFJU','ennova-addons');?></p>
        </div>
    <?php  

}

function save_custom_enn_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["enn-meta-box-nonce"]) || !wp_verify_nonce($_POST["enn-meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "post";
    if($slug != $post->post_type)
        return $post_id;

    $meta_enn_video_url = "";

    if(isset($_POST["enn_video_url"]))
    {
        $meta_enn_video_url = $_POST["enn_video_url"];
    }   
    update_post_meta($post_id, "enn_video_url", $meta_enn_video_url);

}

add_action("save_post", "save_custom_enn_meta_box", 10, 3); ?>