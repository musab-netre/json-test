<?php
/**
* Plugin Name: Ennova Addons for Elementor - Lite
* Description: High quality addons for elementor
* Author: SRK
* Author URI: https://srk.com/
* Version: 0.0.1
* License: GPLv2
* License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: ennova-addons
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once plugin_dir_path( __FILE__ ) . "ennova-constant.php";
if ( !class_exists('ENNOVA_ADDONS') ) {
	class ENNOVA_ADDONS {


		private static $instance;

		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new ENNOVA_ADDONS();
				self::$instance->init();
			}
			return self::$instance;
		}
		//Empty Construct
		public function __construct() {     }

		//initialize Plugin
		public function init() {
			$this->include_files();
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_hf_create_category' ] ); // Add a custom header footer category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_create_category' ] ); // Add a custom category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_blog_create_category' ] ); // Add a custom blog category for panel widgets
			add_action( 'elementor/elements/categories_registered', [ $this, 'wc_woo_create_category' ] ); // Add a custom woo category for panel widgets
			add_filter( 'elementor/elements/categories', [ $this, 'set_custom_widget_category_priority' ] );
		}

		//Include all files
		public function include_files() {
			require_once ENNOVA_PATH . 'inc/ennova-custom-navwalker.php';
			require_once ENNOVA_PATH . 'inc/classes/utils.php';
			require_once ENNOVA_PATH . 'inc/bootstrap.php';
		}

		//Elementor new category register method
		// add category for header & footer
		public function wc_hf_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-hf-element',
				[
					'title' => __( 'Ennova Header & Footer', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		// add category for Blog
		public function wc_blog_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-blog-element',
				[
					'title' => __( 'Ennova Blog', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		// add category for woocommerce
		public function wc_woo_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-woo-element',
				[
					'title' => __( 'Ennova Woocommerce', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		//Elementor new category register method
		public function wc_create_category() {
			\Elementor\Plugin::$instance->elements_manager->add_category(
				'wc-element',
				[
					'title' => __( 'Ennova Addons', 'ennova-addons' ),
					'icon'  => 'fa fa-plug', //default icon
				],
				1 // position
			);
		}

		function set_custom_widget_category_priority( $categories ) {
			
			if ( isset( $categories['wc-hf-element'] ) ) {
				$categories['wc-hf-element']->set_priority( 1 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-blog-element'] ) ) {
				$categories['wc-blog-element']->set_priority( 2 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-woo-element'] ) ) {
				$categories['wc-woo-element']->set_priority( 3 ); // Set priority to 1 for top position
			}
			if ( isset( $categories['wc-element'] ) ) {
				$categories['wc-element']->set_priority( 4 ); // Set priority to 1 for top position
			}
			return $categories;
		}

		// prevent the instance from being cloned
		public function __clone() {     }

		// prevent from being unserialized
		public function __wakeup() {    }
	}
	require_once plugin_dir_path( __FILE__ ) . '/inc/class-ennova-header-footer-elementor.php';
	function ennova_addons_register_function() {
		$WPCE_SLIDER = ENNOVA_ADDONS::get_instance();
		Ennova_Header_Footer_Elementor::instance();
	}
	add_action( 'plugins_loaded', 'ennova_addons_register_function' );

}
