/**
  * Woocommerce product quickview js
 **/

  var ProductFeatureQuickView = function( $scope, $ ){ 
    const wId = $scope.data("id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	const outerWrapper = wrapper.querySelector(".ennova-outer-wrapper");
    const SwipeExists = wrapper.querySelector('.swiper-container') !== null;
    const PoponeExists = $scope.find('.ennova-popup') !== null;
    console.log('yes it is working');
    $scope.find('.quick-cls').click(function() {
        if(PoponeExists == true){
            $scope.find('.ennova-popup').remove();
        }
        console.log('quick is clicked');
        if(SwipeExists !== true){
            console.log('Swiper not Exist');
            var thisEl = $(this);
            thisEl.parent().parent().toggleClass("popup");
            var product_id = $(this).find('.enn-tooltip').attr('data-prod-id');
            var data = {action: 'woo_quickview', product: product_id};
    
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) {
                    
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    thisEl.parent().parent().append(jsdata);
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('popup')){
                            par.classList.remove('popup');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                    console.log('quick view ajax error');
                },
            });
        }else{
            console.log('Swiper Exist');
            var thisEl = $(this);
            $scope.toggleClass("on_Pup");
            var product_id = $(this).find('.enn-tooltip').attr('data-prod-id');
            var data = {action: 'woo_quickview', product: product_id};
    
        
            $.ajax({
                url: myajax.ajaxurl,
                type: "POST",
                data: data,
                success: function (response) {
                    
                    var jsdata = JSON.parse(response.data);
                    // console.log(jsdata);
                    $scope.append(jsdata);
                },
                complete: function() {
                    var quick_view = document.querySelectorAll('.close-btn');
                    for (var i = 0; i < quick_view.length; i++) {
                        quick_view[i].addEventListener('click', function(event) {
                            
                            var par = this.parentElement.parentElement.parentElement;
                            if(par.classList.contains('on_Pup')){
                            par.classList.remove('on_Pup');
                            this.parentElement.parentElement.remove();
    
                            }
                        });
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                    console.log('quick view ajax error');
                },
            });
        }
    
    });
    
}



jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-slider.default', ProductFeatureQuickView);
});

jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-product-grid.default', ProductFeatureQuickView);
});

/**
	* Search widget JS
	*/
	var WidgetennovaWooSearchButton = function( $scope, $ ){

		if ( 'undefined' == typeof $scope )
			return;

			var $input = $scope.find( "input.ennova_search_input" );
			var $clear = $scope.find( "button#clear" );
			var $clear_with_button = $scope.find( "button#clear-with-button" );
			var $search_button = $scope.find( ".ennova-search-submit" );
			var $toggle_search = $scope.find( ".ennova-search-icon-toggle input" );
			var $search_wrap = $scope.find( ".ennova-search-wrapper" );

		$scope.find( '.search-btn i.fa-search' ).on( 'click', function( ){
			$scope.find( ".ennova-search-wrapper" ).toggleClass( "ennova-input-focus" );					
		});	



		$toggle_search.css( 'padding-right', $toggle_search.next().outerWidth() + 'px' );

	
		$input.on( 'keyup', function(){
			$clear.style = (this.value.length) ? $clear.css('visibility','visible'): $clear.css('visibility','hidden');
			$clear_with_button.style = (this.value.length) ? $clear_with_button.css('visibility','visible'): $clear_with_button.css('visibility','hidden');
			$clear_with_button.css( 'right', $search_button.outerWidth() + 'px' );
		});

		$clear.on("click",function(){
			this.style = $clear.css('visibility','hidden');
			$input.value = "";
		});
		$clear_with_button.on("click",function(){
			this.style = $clear_with_button.css('visibility','hidden');
			$input.value = "";
		});

	var searchRequest;	

	  $input.autocomplete({
		source: function(term, suggest){
			var term1 = $scope.find( "input.ennova_search_input" ).val();
			try { searchRequest.abort(); } catch(e){}
			searchRequest = $.post(myajax.ajaxurl, { srchwoo: term1, action: 'search_woo_site' }, function(res) {
				var rspns = eval(res.data);
				var na = [];
				$.map(rspns, function(item) {
				let result = item.toLowerCase().includes(term1.toLowerCase());
					if(result == true){
						na.push(item);
					}	
				});
					suggest(na);
			});
		}
	  });

	}

	jQuery(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/ennova-woo-search.default', WidgetennovaWooSearchButton );
	});
