(function ($) {

  /**
   * Nav widgets JS
   */
  var WidgetennovaNavMenu = function( $scope, $ ){ 
  
    if ( 'undefined' == typeof $scope ) {
        return;
    }
  
    var $main = $scope.find( ".main-nav" );
  
    $scope.find('.toggle-icon.open').on("click", function() {
      $main.toggleClass('open-nav');
      $scope.find('.ennova-collapse').toggleClass('responsiv_nav');
    });

    $scope.find('#main-menu').smartmenus({
      subMenusSubOffsetX: 1,
      subMenusSubOffsetY: -8
    });
     

  const content_right = document.querySelector(".boxy");
  const bs_sidebar = document.querySelector(".mn-stick");
  const observer = new IntersectionObserver(
    (entries) => {
      const ent = entries[0];
      ent.isIntersecting == false
      ? bs_sidebar.classList.add("head-is-stuck")
      : bs_sidebar.classList.remove("head-is-stuck");
    },
    {
      root: null,
      rootMargin: "",
      threshold:"",
    }
  );
  observer.observe(content_right);
  
  }


  jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/ennova-nav-menu.default', WidgetennovaNavMenu);
  });
  
} )( jQuery );
  
var WidgetProgressBar = function( $scope, $ ){
  const wId = $scope.data("id");

	const wrapper = document.querySelector(`.elementor-element-${wId}`);
  let suffdiv = wrapper.querySelector('.ennova-progress-items');

  let suffix =  suffdiv.getAttribute("prog-suffix");
  const progress_bars = wrapper.querySelector('.enn-pro-percentage');

    let SPEED = 25;

    let limit = parseInt(progress_bars.innerHTML, 10);

    for(let i = 0; i <= limit; i++) {
        setTimeout(function () {
          progress_bars.innerHTML = i + suffix;
        }, SPEED * i);
    }


}
jQuery(window).on('elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction('frontend/element_ready/ennova-progress-bar.default', WidgetProgressBar);
});

const imageHotspot = function( $scope, $ ){

  const wId = $scope.data("id");

	const wrapper = document.querySelector(`.elementor-element-${wId}`);

  let suffdiv = wrapper.querySelector('.enn-image-hotspots');

  let suffix =  suffdiv.getAttribute("tigger");

  if ( suffix === 'by_click' ) {
    $scope.find('.enn-hotspot-item').each(function(){
      $(this).on("click", function() {
        $(this).find('.enn-hotspot-tooltip').toggleClass('enn-tooltip-trigger');
      });
    });
    
  }

};

jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-image-hotspot.default",imageHotspot
	);
});


var WidgetTimeline = function( $scope, $ ){ 
  // -------------------- TIMELINE ---------------------------- 
  var items = $scope.find(".enn-timeline-items .timeline-dot"),
  timelineHeight = $scope.find(".enn-timeline-items").height(),
  greyLine = $scope.find('.timeline-line'),
  lineToDraw = $scope.find('.timeline-inner-line');

  // sets the height that the greyLine (.default-line) should be according to `.timeline ul` height

  // run this function only if draw line exists on the page
  if(lineToDraw.length) {
    $(window).on('scroll', function () {

      // Need to constantly get '.draw-line' height to compare against '.default-line'
      var redLineHeight = lineToDraw.height(),
      greyLineHeight = greyLine.height(),
      windowDistance = $(window).scrollTop(),
      windowHeight = $(window).height() / 2,
      timelineDistance = $scope.find(".enn-timeline-items").offset().top;

      if(windowDistance >= timelineDistance - windowHeight) {
        line = windowDistance - timelineDistance + windowHeight;

        if(line <= greyLineHeight) {
          lineToDraw.css({
            'height' : line + 8 + 'px'
          });
        }
      }

      // This takes care of adding the class in-view to the li:before items
      var bottom = lineToDraw.offset().top + lineToDraw.outerHeight(true);
      items.each(function(index){
        var circlePosition = $(this).offset();

        if(bottom > circlePosition.top) {				
          $(this).addClass('highlighted-dot');
        } else {
          $(this).removeClass('highlighted-dot');
        }
      });	
    });
  }  
}

jQuery(window).on('elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction('frontend/element_ready/ennova-timeline.default', WidgetTimeline);
});

jQuery(window).on('elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction('frontend/element_ready/ennova-post-blog-timeline.default', WidgetTimeline);
});

// Product Banner
const pos = document.documentElement;
pos.addEventListener("mousemove", e =>{
pos.style.setProperty('--x', e.clientX + "px");
pos.style.setProperty('--y', e.clientY + "px");
});

