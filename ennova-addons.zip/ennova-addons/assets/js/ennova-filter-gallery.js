window.onload = () => {};

const run = (filter , scope) => {
	let selectedFilter = filter.getAttribute("data-filter");
	console.log(selectedFilter);
	let itemsToHide = scope.querySelectorAll(
		`.ennova-fg-projects .ennova-fg-project:not([data-filter='${selectedFilter}'])`
	);

	let itemsToShow = scope.querySelectorAll(
		`.ennova-fg-projects [data-filter='${selectedFilter}']`
	);

	console.log({ itemsToHide });

	if (selectedFilter === "All") {
		itemsToHide = [];
		itemsToShow = scope.querySelectorAll(
			".ennova-fg-projects [data-filter]"
		);
	}

	itemsToHide.forEach((el) => {
		el.classList.add("ennova-fg-hide");
		el.classList.remove("ennova-fg-show");
	});

	itemsToShow.forEach((el) => {
		el.classList.remove("ennova-fg-hide");
		el.classList.add("ennova-fg-show");
	});
};

const load = ($scope, $) => {
	const wId = $scope.attr("data-id");
	const wrapper = document.querySelector(`.elementor-element-${wId}`);
	console.clear();
	const filters = wrapper.querySelectorAll(".ennova-fg-filter");
	console.log({ wrapper });
	if (filters.length > 0) {
		run(filters[0], wrapper);
	}
	filters.forEach((filter) => {
		filter.addEventListener("click", function () {
			run(filter, wrapper);
		});
	});

	// Add Active Class

	var selector = $scope.find('.ennova-fg-filter');

	jQuery(selector).on('click', function(){
		jQuery(selector).removeClass('active');
		jQuery(this).addClass('active');
	});

};




jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/ennova-filter-gallery.default",
		load
	);
});
