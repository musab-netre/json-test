<?php  //Defined all constants for the plugin
if(!defined('ENNOVA')){
    define( 'ENNOVA', __FILE__);
    define( 'ENNOVA_DOAMIN', 'ennova-addons' ); //Pro Link
    define( 'ENNOVA_PATH', plugin_dir_path( __FILE__ ) );
    define( 'ENNOVA_URL', plugin_dir_url( __FILE__ ) );
    define( 'ENNOVA_VERSION', '1.0.0' ); //Plugin Version
    define( 'ENNOVA_MIN_ELEMENTOR_VERSION', '2.0.0' ); //MINIMUM ELEMENTOR Plugin Version
    define( 'ENNOVA_MIN_PHP_VERSION', '5.4' ); //MINIMUM PHP Plugin Version
    define( 'ENNOVA_PRO_LINK', 'https://wpennova.com/addons/' ); //Pro Link
    define( 'ENNOVA_GO_PRO_HTML', '<span class="ennova-pro-feature"> Get the  <a href="'.ENNOVA_PRO_LINK.'" target="_blank">Pro version</a> for more stunning elements.</span>' ); //Pro Link
}
?>