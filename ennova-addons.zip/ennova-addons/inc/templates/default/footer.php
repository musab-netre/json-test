<?php do_action( '_ennova_foot_' );?>
<?php wp_footer(); ?>
</body>
</html>