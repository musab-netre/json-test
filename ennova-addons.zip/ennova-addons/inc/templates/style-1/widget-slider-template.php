<?php
// phpcs:ignoreFile


$slides = $settings['slides'];

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . '>';
$class = 'ennova_slider_wrapper';
echo '<div

        		class="' . $class .'"
        		id="' . esc_attr( $element_id ) . '"
        		data-slide-to-show="' . esc_html( $slide_to_show ) . '"
				data-slide-to-show-mobile="' . esc_html( $slide_to_show_mobile ) . '"
				data-slide-to-show-tablet="' . esc_html( $slide_to_show_tablet ) . '"
        		data-slides-to-scroll="' . esc_html( $slides_to_scroll ) . '"
				data-slides-to-scroll-mobile="' . esc_html( $slides_to_scroll_mobile ) . '"
				data-slides-to-scroll-tablet="' . esc_html( $slides_to_scroll_tablet ) . '"
        		data-slides-space-between="' . esc_html( $slides_space_between ) . '"
				data-slides-space-between-mobile="' . esc_html( $slides_space_between_mobile ) . '"
				data-slides-space-between-tablet="' . esc_html( $slides_space_between_tablet ) . '"
				data-autoplay="' . esc_html( $autoplay ) . '"
				data-autoplay-speed="' . esc_html( $autoplay_speed ) . '"

				data-transition_between_slides="' . esc_html( $transition_between_slides ) . '"
				data-loop="' . esc_html( $loop ) . '"
				data-mousewheel="' . esc_html( $mousewheel ) . '"
				data-keyboard_control="' . esc_html( $keyboard_control ) . '"
				data-clickable="' . esc_html( $dot_clickable ) . '"

        	>';

$swiper_container_class = 'swiper-container swiper-' . $this->get_id();
if (
			$slides
		) {
			?>
			<!-- Slider main container -->
			<div class="<?php echo esc_html( $swiper_container_class ); ?>">
				<!-- Additional required wrapper -->
				<div class="swiper-wrapper">
					<?php
						$image_size = isset( $settings['slider_image_size'] ) ? $settings['slider_image_size'] : 'large';

foreach ($slides as $slide) {

?>
	<div class="swiper-slide ennova-single-item">
		<?php
			if( isset( $slide['image']['url'] ) ) {
				$image_url = $slide['image']['url'];
				if( $slide['image']['id'] ) {
					$image = wp_get_attachment_image_src( $slide['image']['id'], $image_size );
					$image_url = $image[0];
				}
				?>
					<div class="ennova-slide <?php echo $enable_overlay ? 'ennova-slider-overlay' : '' ?> <?php echo esc_attr( $slide_height ); ?>"

					style="background-image: url('<?php echo $image_url ?>')"
					>

                                <div class="ennova-slide-content">

                                    <?php if( $slide['subtitle'] ) : ?>
                                        <span class="ennova-slide-subtitle"><?php echo esc_html( $slide['subtitle'] ); ?></span>
                                    <?php endif; ?>

                                    <?php if( $slide['title'] ) : ?>
                                        <span class="ennova-slide-title">
                                            <?php
                                                echo wp_kses( $slide['title'], array(
                                                    'strong' => array(),
                                                    'br' => array()
                                                ) );
                                            ?>
                                        </span>
                                    <?php endif; ?>

                                    <p class="ennova-slide-description"><?php echo wp_kses( $slide['content'], array( 'br' => array() ) ); ?></p>
                                    <?php if( $slide['btn_text'] && $slide['btn_link']['url'] ) : ?>
                                        <a class="ennova-slide-btn" href="<?php echo esc_url( $slide['btn_link']['url'] ); ?>"><?php echo esc_html( $slide['btn_text'] ); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
				<?php
			}
		?>
	</div>
<?php
}


					?>

				</div>

				<?php
				if ( $settings['display_dots'] === 'yes' ) {
					?>
					<!-- If we need pagination -->
					<div class="swiper-pagination"></div>
					<?php
				}
				?>
				<?php
				if ( $settings['show_navigation_arrow'] === 'yes' ) {
					?>
					<!-- If we need navigation buttons -->
					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
					<?php
				}
				?>
				<?php
				if ( $settings['show_scroll_bar'] === 'yes' ) {
					?>
					<!-- If we need scrollbar -->
					<div class="swiper-scrollbar"></div>
					<?php
				}
				?>
			</div>
			<?php
		} else {
			echo 'No slides Found!';
		}

		echo '</div>';
		echo '</div>';
