<?php
// phpcs:ignoreFile

$category_class = '';

if ($display_title_absolute === 'yes' ) {
	$category_class = 'ennova-category-name-absolute';
}

foreach ($categories_list as $category) {

	$cat_thumb_id = get_term_meta( $category->term_id, 'thumbnail_id', true );
    $cat_thumb_url = wp_get_attachment_thumb_url( $cat_thumb_id );
    $term_link = get_term_link( $category, 'product_cat' );
	$category_name = $category->name;
	$category_count = $category->count;

?>
	<div class="swiper-slide ennova-single-category <?php if( !$cat_thumb_id )
	{echo 'ennova-no-category-image';}  ?> ">

		<?php
			if ( $cat_thumb_id && $settings['display_image'] ) {
				?>
					<div class="ennova-category-image">
						<a href="<?php echo $term_link; ?>">
							<?php
								$image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src($cat_thumb_id, 'thumbnail_size', $settings);
								echo sprintf('<img src="%s" title="%s" alt="%s"%s />', esc_attr($image_src), get_the_title($cat_thumb_id), ennova_get_attachment_alt($cat_thumb_id), '');
							?>
						</a>
					</div>
				<?php
			}

			if ( $settings['display_title'] || ! $cat_thumb_id || ! $settings['display_image']) {
				?>
				<div class="ennova-category-name <?php echo $category_class ?> ">
					<a href="<?php echo $term_link; ?>">
						<?php
							if ( $settings['display_category_count'] ) {
								echo $category_name . '(' . $category_count . ')';
							} else {
								echo $category_name;
							}
						?>
					</a>
				</div>
				<?php
			}
		?>
	</div>

<?php
}
wp_reset_query();
