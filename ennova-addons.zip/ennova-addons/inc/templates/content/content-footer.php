<footer id="ennova-footer" class="ennova-site-footer">
	<div class="ennova-footer-inner">
		<?php the_content(); ?>
	</div>
</footer>