<header id="ennova-head" class="ennova-site-header">
	<?php the_content(); ?>
</header>
