<?php /*Admin and Theme Builder Page Main Hook */
function  ennova_admin_page_init() {

  $customMenu = add_menu_page('ennova-addons','Ennova Addons','manage_options','ennova_admin_menu','ennova_admin_page', ENNOVA_URL.'assets/images/addon-icon.png',30 );

  add_submenu_page(
    'ennova_admin_menu',
    __('Theme Builder'),
    __('Theme Builder'),
    'manage_options',
    'edit.php?post_type=ennova-header-footer'
  );

  add_action( 'admin_print_styles-' . $customMenu, 'ennova_admin_styles' );

  add_action( 'admin_init', 'ennova_register_addons_settings' );
}

add_action('admin_menu','ennova_admin_page_init');

function ennova_admin_styles() {

  wp_enqueue_style('admin_assets',ENNOVA_URL.'assets/css/admin.css');
}

function registered_widgets(){
  
  $widgets = [

    "wc-hf-element" => array(
      "widget_cat" => "Ennova Header & Footer",
      "widgets" => array(
        array( 'ver' => 'lite', 'icon' => 'eicon-site-logo', 'slug' => 'Site Logo', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVASiteLogo' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-site-title', 'slug' => 'Site Title', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVASiteTitle' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-text-area', 'slug' => 'Site Tagline', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVASiteTagline' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-alert', 'slug' => 'Copyright', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVACopyright' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-site-search', 'slug' => 'Search', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVASearch' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-nav-menu', 'slug' => 'Menus', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVANavMenu' ),
        
        array( 'ver' => 'pro', 'icon' => 'eicon-mega-menu', 'slug' => 'Mega Menu', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/mega-menus/' , 'name' => 'ENNOVAMegaMenu' ),
      )
    ),

    "wc-element" => array(
      "widget_cat" => "Ennova Addons",
      "widgets" => array(
        array( 'ver' => 'lite', 'icon' => 'eicon-info-box', 'slug' => 'Service ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/service-box/' , 'name' => 'ENNOVAService' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-gallery-grid', 'slug' => 'Portfolio ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/portfolio/' , 'name' => 'ENNOVAPortfolio' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-gallery-masonry', 'slug' => 'Filter Gallery', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/filter-gallery/' , 'name' => 'ENNOVAFilterGalley' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-price-table', 'slug' => 'Price Table', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/price-table/' , 'name' => 'ENNOVAPrice' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-featured-image', 'slug' => 'Team ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/team/' , 'name' => 'ENNOVATeam' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-icon-box', 'slug' => 'Feature ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/features/' , 'name' => 'ENNOVAFeature' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-testimonial', 'slug' => 'Testimonial ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/testimonial/' , 'name' => 'ENNOVATestimonial' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-person', 'slug' => 'Author', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/author/' , 'name' => 'ENNOVAAuthor' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-post-list', 'slug' => 'Author List', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/author-list/' , 'name' => 'ENNOVAAuthorlist' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-hotspot', 'slug' => 'Image Hotspot', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/image-hotspot/' , 'name' => 'ENNOVAImageHotspot' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-price-list', 'slug' => 'Price List', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/price-list/' , 'name' => 'ENNOVAPriceList' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-nav-menu', 'slug' => 'Price Menu', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/price-menu/' , 'name' => 'ENNOVAPriceMenu' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-counter', 'slug' => 'Number ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/number-item/' , 'name' => 'ENNOVANumberItems' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-animated-headline', 'slug' => 'Dual Color Heading', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/dual-heading/' , 'name' => 'ENNOVADualHeading' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-image-rollover', 'slug' => 'Call to Action ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/call-to-action/' , 'name' => 'ENNOVACalltoaction' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-download-button', 'slug' => 'Creative Button ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/creative-button/' , 'name' => 'ENNOVACreativeButton' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-flip-box', 'slug' => 'Flip Box ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/flip-box/' , 'name' => 'ENNOVAFlipbox' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-skill-bar', 'slug' => 'Progress Bar', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/progress-bar/' , 'name' => 'ENNOVAProgressBar' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-dual-button', 'slug' => 'Dual Button ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/dual-button/' , 'name' => 'ENNOVADualbutton' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-time-line', 'slug' => 'Content Timeline', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/timeline/' , 'name' => 'ENNOVAContentTimeline' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-table-of-contents', 'slug' => 'Business Hours', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/business-hours/' , 'name' => 'ENNOVABusinessHours' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-slider-full-screen', 'slug' => 'Slider ', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/slider/' , 'name' => 'ENNOVASlider' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-slider-3d', 'slug' => 'Service Carousel', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/service-carousel/' , 'name' => 'ENNOVAServiceCarousel' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-testimonial-carousel', 'slug' => 'Testimonial Carousel', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/testimonial-carousel/' , 'name' => 'ENNOVATestimonialCarousel' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-carousel-loop', 'slug' => 'Portfolio Carousel', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/portfolio-carousel/' , 'name' => 'ENNOVAPortfolioCarousel' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-slider-3d', 'slug' => 'Team Carousel', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/team-carousel/' , 'name' => 'ENNOVATeamCarousel' ),
        
        array( 'ver' => 'lite', 'icon' => 'eicon-image-before-after', 'slug' => 'Image Comparison', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/image-comparison/' , 'name' => 'ENNOVAImageComparison' ),
      )
    ),

    "wc-blog-element" => array(
      "widget_cat" => "Ennova Blog",
      "widgets" => array(
        array( 'ver' => 'lite', 'icon' => 'eicon-posts-grid', 'slug' => 'Post Blog', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/blog/' , 'name' => 'ENNOVAPostBlog' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-post-list', 'slug' => 'Post Blog List', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/blog-post-list/' , 'name' => 'ENNOVAPostBlogList' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-post-slider', 'slug' => 'Post Blog Carousel', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/blog-carousel/' , 'name' => 'ENNOVABlogCarousel' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-posts-group', 'slug' => 'Featured Post Blog', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/featured-blog-post/' , 'name' => 'ENNOVAFeaturedBlog' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-posts-masonry', 'slug' => 'Express Post Blog', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/express-blog-post/' , 'name' => 'ENNOVAExpressBlog' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-bullet-list', 'slug' => 'Blog Category List', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/blog-post-category-list/' , 'name' => 'ENNOVACategoryList' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-column', 'slug' => 'Blog Single Category', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/single-category/' , 'name' => 'ENNOVASingleColumnCate' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-tabs', 'slug' => 'Post Category Tab', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/post-category-tab/' , 'name' => 'ENNOVAPostCategoryTabWidget' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-posts-ticker', 'slug' => 'Post Ticker', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/post-ticker/' , 'name' => 'ENNOVAPostTicket' ),

        array( 'ver' => 'pro', 'icon' => 'eicon-video-playlist', 'slug' => 'Video Post', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/video-blog-post/' , 'name' => 'ENNOVAVideoPost' ),

        array( 'ver' => 'lite', 'icon' => 'eicon-time-line', 'slug' => 'Blog Timeline', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/blog-timeline/' , 'name' => 'ENNOVAPostBlogTimeline' ),
      )
    ),

    "wc-woo-element" => array(
      "widget_cat" => "Ennova Woocommerce",
      "widgets" => array(
        array('id' => 'woocommerce', 'ver' => 'lite' , 'icon' => 'eicon-product-images', 'slug' => 'Product Slider', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-slider/' , 'name' => 'ENNOVAProductSlider' ),
     
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-product-related', 'slug' => 'Product Grid', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-grid/' , 'name' => 'ENNOVAProductGrid' ),
    
        array('id' => 'woocommerce', 'ver' => 'pro' ,  'icon' => 'eicon-product-categories', 'slug' => 'Product Category Slider', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-category-slider/' , 'name' => 'ENNOVAProductCategorySlider' ),
    
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-product-add-to-cart', 'slug' => 'Product Category Grid', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-category-grid/' , 'name' => 'ENNOVAProductCategoryGrid' ),
    
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-product-breadcrumbs', 'slug' => 'Product Banner', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-banner/' , 'name' => 'ENNOVAProductBanner' ),
    
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-tabs', 'slug' => 'Product Category Tab', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-category-tab/' , 'name' => 'ENNOVAProductCategoryTabWidget' ),
        
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-products', 'slug' => 'Products Grid with Nav', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/product-grid-with-nav/' , 'name' => 'ENNOVAProductGridWithNav' ),
    
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-cart', 'slug' => 'Cart', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/cart/' , 'name' => 'ENNOVACart' ),

        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-woo-cart', 'slug' => 'Cart Page', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/cart-page/' , 'name' => 'ENNOVACartPage' ),
        
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-form-horizontal', 'slug' => 'Checkout Page', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/checkout-page/' , 'name' => 'ENNOVACheckoutPage' ),
    
        array('id' => 'woocommerce', 'ver' => 'lite' ,  'icon' => 'eicon-search-results', 'slug' => 'Woo Search', 'doc' => 'https://docs.wpennova.com/', 'demo' => 'https://wpennova.com/addons/woo-search/' , 'name' => 'ENNOVAWooSearch' ),
       
      )
    ),

  ];

  return $widgets;
} 

function third_party_widgets(){

  $widgets = [
    
    array( 'ver' => 'lite',  'id' => 'contact-form-7', 'icon' => 'eicon-form-horizontal', 'slug' => 'Contact Form 7', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVAContactForm7' ),

    array( 'ver' => 'lite',  'id' => 'everest-forms', 'icon' => 'eicon-form-horizontal', 'slug' => 'Everest Form', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVAEverestForms' ),

    array('ver' => 'lite', 'id' => 'ninja-forms', 'icon' => 'eicon-form-horizontal', 'slug' => 'Ninja Forms', 'doc' => 'https://docs.wpennova.com/', 'demo' => '/demo' , 'name' => 'ENNOVANinjaForms' ),

  ];
  
  return $widgets;
  
}

function ennova_register_addons_settings() { 
  foreach (registered_widgets() as $widgets) {
    foreach ($widgets['widgets'] as $widget_setting) { 
      $widget_id = explode(" ",$widget_setting['slug']);
      $widget_id = implode("-ennova-",$widget_id);
      register_setting( 'ennova_elements_settings', $widget_id, [ 'default' => true ] );
    }
  }

  foreach (third_party_widgets() as $widget_setting) {
    $widget_id = explode(" ",$widget_setting['slug']);
    $widget_id = implode("-ennova-",$widget_id);
    register_setting( 'ennova-3rd-elements-settings', $widget_id, [ 'default' => true ] );
  }
  register_setting( 'ennova_elements_settings', 'ennova_tab_settings' );
  register_setting( 'ennova-3rd-elements-settings', 'ennova_tab2_settings' );
}

function ennova_admin_page() {    
  $All_Widgets = registered_widgets();
  $Third_party_widgets = third_party_widgets(); ?>
      <div class="enn-amin-wrapper">
        <div class="enn-admin-tabs-area"> 
            <nav id="enn_admin_tabs" class="enn-admin-tabs">
                <li class=" active" data-tab="tab1"><a ><i class="fas fa-home"></i><?php echo esc_html('Dashboard'); ?></a></li>
                <li data-tab="tab2"><a ><i class="fas fa-box"></i><?php echo esc_html('Widgets'); ?></a></li>
                <li data-tab="tab3"><a ><i class="fab fa-dropbox"></i><?php echo esc_html('3rd Party Widgets');?></a></li><span class="glider"></span>
                <li data-tab="tab4"><a><i class="fas fa-crown"></i><?php echo esc_html('Get Pro'); ?></a></li><span class="glider"></span>
            </nav>
            <div id="tab-contents"> 
              <!-- enn-admin-tab-content -->
              <div id="tab1" class="enn-admin-tab-content active">
                <div class="enn-admin-grid-card">
                  <div class="enn-admin-grid one">
                     <!-- enn-admin-widget -->
                      <div class="enn-admin-card" data-item="pro">
                        <div class="enn-admin-card-tittle-area enn-admin-f-center">
                            <h3 class="tittle tag">On your plate we need to dialog around your choice of work attire, and cross pollination across our domains.</h3>
                        </div>
                        <p>Golden goose helicopter view, nor re-inventing the wheel, but deliverables, so we want to empower the team with the right tools and guidance </p>
                        <ul>
                          <li>It is all exactly as i said, but i don't like it can you slack</li>
                          <li>It is all exactly as i said, but i don't like it can you slack</li>
                          <li>It is all exactly as i said, but i don't like it can you slack</li>
                        </ul>
                      </div>
                      <!-- /enn-admin-widget -->
                  </div>
                  <div class="enn-admin-grid two">
                    <!-- enn-admin-widget -->
                    <div class="enn-admin-card ser" data-item="pro">
                      <div class="enn-admin-wid-icon-area enn-admin-f-center">
                        <i class="far fa-file-alt"></i>
                      </div>
                      <div class="enn-admin-card-body">
                        <h5>View Knowledgebase</h5>
                        <p>Slipstream we need to follow protocol, but cadence.</p>
                      </div>
                    </div>
                    <!-- /enn-admin-widget -->
                    <!-- enn-admin-widget -->
                    <div class="enn-admin-card ser" data-item="pro">
                      <div class="enn-admin-wid-icon-area enn-admin-f-center">
                        <i class="far fa-file-alt"></i>
                      </div>
                      <div class="enn-admin-card-body">
                        <h5>View Knowledgebase</h5>
                        <p>Slipstream we need to follow protocol, but cadence.</p>
                      </div>
                    </div>
                    <!-- /enn-admin-widget -->
                    <!-- enn-admin-widget -->
                    <div class="enn-admin-card ser" data-item="pro">
                      <div class="enn-admin-wid-icon-area enn-admin-f-center">
                        <i class="far fa-file-alt"></i>
                      </div>
                      <div class="enn-admin-card-body">
                        <h5>View Knowledgebase</h5>
                        <p>Slipstream we need to follow protocol, but cadence.</p>
                      </div>
                    </div>
                    <!-- /enn-admin-widget -->
                    <!-- enn-admin-widget -->
                    <div class="enn-admin-card ser" data-item="pro">
                      <div class="enn-admin-wid-icon-area enn-admin-f-center">
                        <i class="far fa-file-alt"></i>
                      </div>
                      <div class="enn-admin-card-body">
                        <h5>View Knowledgebase</h5>
                        <p>Slipstream we need to follow protocol, but cadence.</p>
                      </div>
                    </div>
                    <!-- /enn-admin-widget -->
                  </div>
                  <div class="enn-admin-grid three">
                     <!-- enn-admin-widget -->
                      <div class="enn-admin-card">
                        <div class="enn-admin-wid-icon-area enn-admin-f-center">
                          <i class="far fa-file-alt"></i>
                        </div>
                        <div class="enn-admin-card-body">
                          <h3 class="">Join Our Facebook Group</h3>
                          <p>Synergize productive mindfulness paddle on both sides design thinking.</p>
                        </div>
                      </div>
                     <!-- /enn-admin-widget -->
                  </div>
                  <div class="enn-admin-grid three">
                    <!-- enn-admin-widget -->
                     <div class="enn-admin-card">
                       <div class="enn-admin-wid-icon-area enn-admin-f-center">
                         <i class="far fa-file-alt"></i>
                       </div>
                       <div class="enn-admin-card-body">
                         <h3 class="">Join Our Facebook Group</h3>
                         <p>Synergize productive mindfulness paddle on both sides design thinking.</p>
                       </div>
                     </div>
                    <!-- /enn-admin-widget -->
                 </div>
                 <div class="enn-admin-grid three">
                  <!-- enn-admin-widget -->
                   <div class="enn-admin-card">
                     <div class="enn-admin-wid-icon-area enn-admin-f-center">
                       <i class="far fa-file-alt"></i>
                     </div>
                     <div class="enn-admin-card-body">
                       <h3 class="">Join Our Facebook Group</h3>
                       <p>Synergize productive mindfulness paddle on both sides design thinking.</p>
                     </div>
                   </div>
                  <!-- /enn-admin-widget -->
               </div>

                 
              </div> 

              </div>
                <!-- /enn-admin-tab-content -->  
                <!-- enn-admin-tab-content -->
              <div id="tab2" class="enn-admin-tab-content">
              <form method="post" action="options.php">
                    <!-- enn-admin-grid-3 -->
                    <?php // Settings
                    settings_fields( 'ennova_elements_settings' );
                    do_settings_sections( 'ennova_elements_settings' );
                    $All_in_one_toggle = get_option('ennova_tab_settings', 'on');
                    $All_in_one_toggle1 = get_option('ennova_tab_settings');
                    ?>
                    <div class="enn-admin-filter-nav">
                        <div class="navigation__inner">
                            <button class="btn pri" data-filter="all"><?php echo esc_html('All'); ?></button>
                            <button class="btn success free" data-filter="free"><?php echo esc_html('Free'); ?></button>
                            <button class="btn pro" data-filter="pro"><?php echo esc_html('Pro'); ?></button>
                        </div>
                        <div class="search-wrapper">
                          <div class="search-bar">
                            <input type="text" class="search" placeholder="Search..">
                            <a href="#"><i class="fas fa-search"></i></a>
                          </div>
                          <fieldset class="slide-btn">
                            <input type="radio" id="radio-1" name="ennova_tab_settings" <?php $All_in_one_toggle == 'on' ? esc_attr_e('checked="checked"') : checked( '0', get_option( 'ennova_tab_settings' ) ); ?> value="0">
                            <label class="tab active" for="radio-1"><?php echo esc_html('Activate All'); ?></label>
                            <input type="radio" id="radio-2" name="ennova_tab_settings" <?php checked( '1', get_option( 'ennova_tab_settings' ) ); ?> value="1">
                            <label class="tab" for="radio-2"><?php echo esc_html('Deactivate All'); ?></label>
                            <span class="glider"></span>
                          </fieldset>
                        </div>
                    </div>
                    <?php foreach($All_Widgets as $cats){
                      
                      if( $cats['widget_cat'] !== 'Ennova Woocommerce'){ ?>
                      <div class="heading">
                        <h3 class="tittle"><?php echo $cats['widget_cat'] ?> </h3>
                      </div>
                      <?php }else{
                         if ( class_exists( 'woocommerce' ) ) { ?>
                          <div class="heading">
                        <h3 class="tittle"><?php echo $cats['widget_cat'] ?> </h3>
                      </div>
                      <?php }else{ ?>
                        <div class="heading">
                        <h3 class="tittle"><?php echo $cats['widget_cat'] ?> </h3>
                        <p class="enn-install-activate-woocommerce">
                        <span class="dashicons dashicons-info-outline"></span> 
                        <?php echo esc_html('Install and activate WooCommerce to use these widgets'); ?>
                        </p>
                      </div>
                   <?php   } } ?>
                      <div class="enn-admin-grid-3 mb-2">
                      
                      <?php foreach ($cats['widgets'] as $widget) { 
                        
                        if($widget['ver'] == 'lite') {

                       
  
                        $widget_id = explode(" ",$widget['slug']);
                        $widget_id = implode("-ennova-",$widget_id); 
                        if( $cats['widget_cat'] !== 'Ennova Woocommerce'){ ?>
                            <!-- enn-admin-widget -->
                            <div class="enn-admin-widget free" data-item="free">
                              <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                                  <div class="enn-admin-wid-title-icon enn-admin-f-center">
                                    <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                                  </div>
                                  <h5 class="tittle"><a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank"><?php echo esc_html($widget['slug']); ?></a></h5>
                              </div>
                              <div class="enn-admin-wid-btn-area enn-admin-f-center">
                                  <a href="<?php echo esc_url($widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                                  <a href="<?php echo esc_url($widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                                  <div class="form-input">
                                    <input type="checkbox" name="<?php echo esc_attr($widget_id); ?>" <?php checked($widget_id, get_option($widget_id , $widget_id ) , $widget_id);?> value="<?php echo esc_attr($widget_id); ?>" class= "toggleable"  />
                                  </div>
                              </div>
                          </div>
                          <!-- /enn-admin-widget -->
                        <?php } else{
                          
                          $plug_path = get_plugin_path($widget['id']); ?>
                     
                     <?php if(!is_plugin_active($plug_path)){ ?>
                      <!-- enn-admin-widget -->
                     <div class="enn-admin-widget free"  data-item="free">
                      <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                          <div class="enn-admin-wid-title-icon enn-admin-f-center">
                            <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                          </div>
                          <h5 class="tittle"><a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank"><?php echo esc_html( $widget['slug']); ?></a></h5>
                      </div>
                      <div class="enn-admin-wid-btn-area enn-admin-f-center">
                          <a href="<?php echo esc_url( $widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                          <a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                          <div class="form-input">
                            <a href="#" id="<?php echo esc_attr( $widget['id']); ?>"  class="downloder plug-btn" ><i class="fas fa-download"></i></a>
                          </div>
                      </div>
                    </div>
                    <!-- /enn-admin-widget --> 
                    <?php } else {
                      $widget_id = explode(" ",$widget['slug']);
                      $widget_id = implode("-ennova-",$widget_id); ?>
                          <!-- enn-admin-widget -->
                          <div class="enn-admin-widget free" data-item="free">
                            <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                                <div class="enn-admin-wid-title-icon enn-admin-f-center">
                                  <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                                </div>
                                <h5 class="tittle"><a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank"><?php echo esc_html( $widget['slug']); ?></a></h5>
                            </div>
                            <div class="enn-admin-wid-btn-area enn-admin-f-center">
                                <a href="<?php echo esc_url( $widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                                <a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                                <div class="form-input">
                                  <input type="checkbox" name="<?php echo esc_attr($widget_id); ?>" <?php checked($widget_id, get_option($widget_id , $widget_id ) , $widget_id);?> value="<?php echo esc_attr($widget_id); ?>" class= "toggleable" />
                                </div>
                            </div>
                        </div>
                        <!-- /enn-admin-widget -->

                   <?php } 

                        }} else{ ?>
                          
                            <!-- enn-admin-widget -->
                            <div class="enn-admin-widget pro" data-item="pro">
                                <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                                    <div class="enn-admin-wid-title-icon enn-admin-f-center">
                                      <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                                    </div>
                                    <h5 class="tittle"><a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank"><?php echo esc_html( $widget['slug']); ?></a></h5>
                                </div>
                                <div class="enn-admin-wid-btn-area enn-admin-f-center">
                                    <a href="<?php echo esc_url( $widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                                    <a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                                    <div class="form-input">
                                      <input type="checkbox" class="rea">
                                      <a href="https://wpennova.com/addons/" class="overlay" target="_blank"></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /enn-admin-widget -->

                          <?php } ?>
  
                       <?php   } ?>
                                               
                        </div> 
                      <?php } ?>

                      <?php submit_button(__( 'Save Settings', 'ennova-addons' ), 'submit pri', 'save-set1', true); ?>
                    </form>
              </div>
                <!-- /enn-admin-tab-content -->
                <!-- enn-admin-tab-content -->
                <div id="tab3" class="enn-admin-tab-content">
                  <form method="post" action="options.php">
                  <?php // Settings
                    settings_fields( 'ennova-3rd-elements-settings' );
                    do_settings_sections( 'ennova-3rd-elements-settings' ); 
                    $All_in_one_toggle2 = get_option('ennova_tab2_settings', 'on');
                    $All_in_one_toggle3 = get_option('ennova_tab2_settings');
                    ?>
                  <div class="enn-admin-filter-nav">
                    <div class="search-wrapper">
                      <div class="search-bar">
                        <input type="text" class="search" placeholder="Search..">
                        <a href="#"><i class="fas fa-search"></i></a>
                      </div>
                      <div class="slide-btn">
                        <input type="radio" id="radio-3" name="ennova_tab2_settings" <?php $All_in_one_toggle2 == 'on' ? esc_attr_e('checked="checked"') : checked( '0', get_option( 'ennova_tab2_settings' ) ); ?> value="0" />
                        <label class="tab" for="radio-3"><?php echo esc_html('Activate All'); ?></label>
                        <input type="radio" id="radio-4" name="ennova_tab2_settings" <?php checked( '1', get_option( 'ennova_tab2_settings' ) ); ?> value="1" />
                        <label class="tab" for="radio-4"><?php echo esc_html('Deactivate All'); ?></label>
                        <span class="glider"></span>
                      </div>   
                    </div>
                </div>
                
                <!-- enn-admin-grid-3 -->
              <div class="enn-admin-grid-3 mb-2">
              <?php foreach ($Third_party_widgets as $widget) {
                $plug_path = get_plugin_path($widget['id']); ?>
                     
                     <?php if(!is_plugin_active($plug_path)){ ?>
                      <!-- enn-admin-widget -->
                     <div class="enn-admin-widget free"  data-item="free">
                      <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                          <div class="enn-admin-wid-title-icon enn-admin-f-center">
                            <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                          </div>
                          <h5 class="tittle"><a href="<?php echo esc_attr( $widget['demo']); ?>" target="_blank"><?php echo esc_html( $widget['slug']); ?></a></h5>
                      </div>
                      <div class="enn-admin-wid-btn-area enn-admin-f-center">
                          <a href="<?php echo esc_url( $widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                          <a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                          <div class="form-input">
                            <a href="#" id="<?php echo esc_attr( $widget['id']); ?>"  class="downloder plug-btn" ><i class="fas fa-download"></i></a>
                          </div>
                      </div>
                    </div>
                    <!-- /enn-admin-widget --> 
                    <?php } else {
                      $widget_id = explode(" ",$widget['name']);
                      $widget_id = implode("-ennova-",$widget_id); ?>
                          <!-- enn-admin-widget -->
                          <div class="enn-admin-widget free" data-item="free">
                            <div class="enn-admin-wid-tittle-area enn-admin-f-center">
                                <div class="enn-admin-wid-title-icon enn-admin-f-center">
                                  <i class="<?php echo esc_attr( $widget['icon']); ?>"></i>
                                </div>
                                <h5 class="tittle"><a href="<?php echo esc_url( $widget['demo']); ?>" target="_blank"><?php echo esc_html($widget['slug']); ?></a></h5>
                            </div>
                            <div class="enn-admin-wid-btn-area enn-admin-f-center">
                                <a href="<?php echo esc_url($widget['doc']); ?>" target="_blank" class="doc"><i class="far fa-file-alt"></i></a>
                                <a href="<?php echo esc_url($widget['demo']); ?>" target="_blank" class="edit"><i class="fas fa-external-link-alt"></i></a> 
                                <div class="form-input">
                                  <input type="checkbox" name="<?php echo esc_attr($widget_id); ?>" <?php checked($widget_id, get_option($widget_id , $widget_id ) , $widget_id);?> value="<?php echo esc_attr($widget_id); ?>" class= "toggleable" />
                                </div>
                            </div>
                        </div>
                        <!-- /enn-admin-widget -->

                   <?php } ?>  
                <?php } ?>        
                </div> 
                <?php submit_button(__( 'Save Settings', 'ennova-addons' ), 'submit pri', 'save-set2', true); ?>
                    </form>
              </div>
                <!-- /enn-admin-tab-content -->
                 <!-- enn-admin-tab-content -->
                 <div id="tab4" class="enn-admin-tab-content">
                  <div class="enn-admin-tb-heading">
                    <h3 class="tittle">WHY GO WITH PRO?</h3>
                    <span>Just Compare With Element Pack Lite Vs Pro</span>
                  </div>
                    <div class="enn-admin-table">
                       <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle pri">
                        <div class="header">
                           <h4>Features</h4> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <h5>Free</h5>
                          </div>
                          <div class="checkable">
                            <h5>Pro</h5>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                       <!-- enn-admin-feature-table -->
                       <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Core Widgets</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Theme Compatibility</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Dynamic Content & Custom Fields Capabilities</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Proper Documentation</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Updates & Support</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Header & Footer Builder</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Rooten Theme Pro Features</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class="enn-admin-tb-list">
                           <span>Priority Support</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>WooCommerce Widgets</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Ready Made Pages</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Ready Made Blocks</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Ready Made Header & Footer</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Elementor Extended Widgets</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Asset Manager</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Live Copy or Paste</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Essential Shortcodes</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-times"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Template Library (in Editor)</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                      <!-- enn-admin-feature-table -->
                      <div class="enn-admin-tb-tittle">
                        <div class=" enn-admin-tb-list">
                           <span>Context Menu</span> 
                        </div>
                        <div class="enn-admin-tb-offer">
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                          <div class="checkable">
                            <i class="fas fa-check"></i>
                          </div>
                        </div> 
                      </div>
                      <!-- /enn-admin-feature-table -->
                    </div>
                 </div>
                 <!-- /enn-admin-tab-content -->

            </div>
        </div>   
    </div>

<?php }

function get_plugin_path($plugin_slug) {
  include_once ABSPATH . 'wp-admin/includes/plugin.php';
  $all_plugins = get_plugins();
  foreach($all_plugins as $key => $wp_plugin) {
      $folder_arr = explode("/", $key);
      $folder = $folder_arr[0];
      if($folder == $plugin_slug) {
          return (string)$key;
          break;
      }
  }
  return false;
}

function install_plugin( $plugin ) {

  if ( ! isset( $plugin ) || empty( $plugin ) ) {
       return esc_html__( 'Invalid plugin slug', 'ennova-addons' );
  }

  include_once ABSPATH . 'wp-admin/includes/plugin.php';
  include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
  include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

  $api = plugins_api(
      'plugin_information',
      array(
          'slug'   => sanitize_key( wp_unslash( $plugin ) ),
          'fields' => array(
              'sections' => false,
          ),
      )
  );

  if ( is_wp_error( $api ) ) {
       $status['errorMessage'] = $api->get_error_message();
       return $status;
  }

  $skin     = new WP_Ajax_Upgrader_Skin();
  $upgrader = new Plugin_Upgrader( $skin );
  $result   = $upgrader->install( $api->download_link );

  if ( is_wp_error( $result ) ) {
       return $result->get_error_message();
  } elseif ( is_wp_error( $skin->result ) ) {
       return $skin->result->get_error_message();
  } elseif ( $skin->get_errors()->has_errors() ) {
       return $skin->get_error_messages();
  } elseif ( is_null( $result ) ) {
       global $wp_filesystem;

    // Pass through the error from WP_Filesystem if one was raised.
    if ( $wp_filesystem instanceof WP_Filesystem_Base && is_wp_error( $wp_filesystem->errors ) && $wp_filesystem->errors->has_errors() ) {
            return esc_html( $wp_filesystem->errors->get_error_message() );
    }

    return esc_html__( 'Unable to connect to the filesystem. Please confirm your credentials.', 'ennova-addons' );
  }

  /* translators: %s plugin name. */
  return sprintf( __( 'Successfully installed "%s" plugin!', 'ennova-addons' ), $api->name );
}

add_action('admin_enqueue_scripts', 'ins_plug_js', 999);

function ins_plug_js() {   
  $screen = get_current_screen();
  if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu') {
    wp_enqueue_script( 'ins-plug', ENNOVA_URL . 'assets/js/ins-plug.js', array( 'jquery' ), '', true );
    wp_localize_script( 'ins-plug', 'ins_plug_ajax_obj', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
  }
}

/* Plugin Install */

function is_plugin_installed($plugin_slug) {
  $all_plugins = get_plugins();
  foreach ($all_plugins as $key => $wp_plugin) {
      $folder_arr = explode("/", $key);
      $folder = $folder_arr[0];
      if ($folder == $plugin_slug) {
          return true;
      }
  }
  return false;
}

add_action( 'wp_ajax_install_act_plugin', 'ennova_install_plugin' );

function ennova_install_plugin() {
  if ( isset($_POST) ) {
      $plugs = $_POST['plugs'];
  }
  // Activate plugin.
  if ( current_user_can( 'activate_plugin' ) ) {
    if(is_plugin_installed($plugs)){
      $plug_path = get_plugin_path($plugs);
      $result = activate_plugin($plug_path);
      if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
      } else {
        wp_send_json_success('Plugin activate successfully.');
      }
    }else{
      $result = install_plugin($plugs);
      if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
      }

      $result = activate_plugin( get_plugin_path($plugs));
      if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
      }else {
        wp_send_json_success('Plugin install & activate successfully.');
      }
    }
  }
    
}