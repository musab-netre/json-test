<?php // phpcs:disable WordPress.Security.NonceVerification.Recommended
// phpcs:disable WordPress.WP.I18n.MissingTranslatorsComment
namespace EnnovaAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Plugin {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {

		// Remove All Third Party Notices
		add_action( 'admin_enqueue_scripts',  [ $this, 'remove_notices' ]);

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// if ( ! class_exists( 'woocommerce' ) ) {
		// 	add_action( 'admin_notices', [ $this, 'admin_notice_missing_wc_plugin' ] );
		// }

		$this->file_include();	
		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, ENNOVA_MIN_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, ENNOVA_MIN_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Enqueue Styles
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts_styles' ] );
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_styles' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );

		// Enqueue Scripts
		add_action(
			'elementor/frontend/after_register_scripts',
			[ $this, 'enqueue_scripts' ] , 999
		);
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] , 999 );

		// Register widget
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action('elementor/controls/register', [$this, 'init_controls']);
		add_action('elementor/editor/after_enqueue_styles', [$this, 'ennova_editor_enqueue_scripts']);

		add_action('wp_ajax_search_site',[ $this,'ajax_search'] );
		add_action('wp_ajax_nopriv_search_site',[ $this,'ajax_search'] 	);
        add_action('wp_ajax_search_woo_site',[ $this,'ajax_woo_search'] );
        add_action('wp_ajax_nopriv_search_woo_site',[ $this,'ajax_woo_search'] );
		add_shortcode('ennova_year', array( $this, 'get_year' ) );
		add_shortcode('ennova_site_tile', array( $this, 'get_site_name' ) );
		
		add_action('wp_ajax_woo_quickview', array( $this, 'woo_quickview' ));
		add_action('wp_ajax_nopriv_woo_quickview', array( $this, 'woo_quickview' ));
		// Refresh the cart fragments.
		if ( class_exists( 'woocommerce' ) ) {
			add_filter( 'woocommerce_add_to_cart_fragments', [ $this, 'cart_refresh' ] );
		}
		add_action( 'elementor/frontend/after_register_scripts',[ $this,'enqueue_custom_widget_assets'] );
	}

	function enqueue_custom_widget_assets() {
		wp_enqueue_style('font-awesome-5', ENNOVA_URL . 'assets/css/all.css', null, ENNOVA_VERSION );
		wp_enqueue_script(
            'ennova-swiper',
            ELEMENTOR_ASSETS_URL . 'lib/swiper/swiper.min.js',
            ['jquery'],
            ENNOVA_VERSION, true 
        );

		if ( class_exists( 'woocommerce' ) ) {
			wp_enqueue_script( 'wc-checkout', WC()->plugin_url() . '/assets/js/frontend/checkout.js', array( 'jquery' ), WC_VERSION, true );
		}

		wp_enqueue_style( 'ennova-swiper-css', 'https://unpkg.com/swiper/swiper-bundle.min.css', null, ENNOVA_VERSION );
		
	}

	public function ajax_search() {
		
        if ( isset($_POST) ) {
    
            $results = new \WP_Query( array(
                'post_type'     => array( 'post', 'page' ),
                's'             =>  $_POST['srch1'],
            ) );
    
        }  
    
        $items = array();
    
        if ( !empty( $results->posts ) ) {
            foreach ( $results->posts as $result ) {
                $items[] = $result->post_title;
            }
        }

        $items =  json_encode($items);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }

    }

	public function ajax_woo_search() {

        if ( isset($_POST) ) {
    
            $results = new \WP_Query( array(
                'post_type' => 'product',
                's'             =>  $_POST['srchwoo'],
            ) );
    
        }  
    
        $items = array();
    
        if ( !empty( $results->posts ) ) {
            foreach ( $results->posts as $result ) {
                $items[] = $result->post_title;
            }
        }

        $items =  json_encode($items);

        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        } 

    }

	public function woo_quickview() {
		global $post, $product, $woocommerce;
	
		$prod_id = $_POST["product"];
		$product = get_product( $prod_id );

		// If the WC_product Object is not defined globally
		if ( ! is_a( $product, 'WC_Product' ) ) {
			$product = wc_get_product( $prod_id );
		}

		$terms = get_the_terms( $prod_id, 'product_cat' );
		$product_cats = '';
		if ( $terms && ! is_wp_error( $terms ) ) {
			$product_cats .= '<span class="posted_in">Category:';
			foreach ( $terms as $term ) {
				$term_link = get_term_link( $term );
				$product_cats .= '<a href="' . esc_url( $term_link ) . '">' . $term->name . '</a>';
			}
			$product_cats .= '</span>';
		}

		$sku = !$product->get_sku()== '' ? $product->get_sku() : "N/A";

		$quick_view = '';

		$quick_view .= '<div class="ennova-popup">
					<div class="overlay">
					<div class="close-btn">&times;</div>
					<div class="popup-img">
						<img src="'.wp_get_attachment_url( $product->get_image_id() ).'" alt="">
					</div>
					<div class="popup-content">
					<h2 class="enn_product_title">'.$product->get_name().'</h2>
					<p class="price">'.$product->get_price_html().'</p>
						<p>'.$product->get_description().'</p> 
						<div class="woocommerce"><div class="woocommerce-notices-wrapper"></div>'.ob_start().woocommerce_template_single_add_to_cart( array(), $product ).ob_get_clean().'</div>
					<div class="product_meta">
					<span class="sku_wrapper">SKU: <span class="sku">'.$sku.'</span></span>'.$product_cats.'</div>
						</div>
					</div>
				</div>'; 
		
		$items =  json_encode($quick_view);
		
        if(!empty($items)){
            wp_send_json_success($items);
        }else{
            wp_send_json_success( array( 'no' => 'no' ) );
        }
	}

	public function cart_refresh( $fragments ) {

		$has_cart = is_a( WC()->cart, 'WC_Cart' );
		if ( ! $has_cart ) {
			return $fragments;
		}
		$product_count = WC()->cart->get_cart_contents_count();
		$sub_total = WC()->cart->get_cart_subtotal();
		
		if ( null !== WC()->cart ) {

			$fragments['span.cart-total'] = '<span class="cart-total">' . $sub_total . '</span>';

			$fragments['span.counter'] = '<span class="counter">' . $product_count . '</span>';

			
		}
		return $fragments;
	}

	public function remove_notices() {
		$screen = get_current_screen();
        if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu' || isset( $screen->post_type ) && $screen->post_type == 'ennova-header-footer') {
            remove_all_actions( 'admin_notices' );
        }
	}

	 // editor styles
	 public function ennova_editor_enqueue_scripts()
	 {
		 // editor style
		 wp_enqueue_style(
			 'ennova-editor',
			 ENNOVA_URL . 'assets/css/editor-css.css',
			 false
		 );
	 }

	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			__( '"%1$s" requires "%2$s" to be installed and activated.', 'ennova-addons' ),
			'<strong>' . __( 'WC Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'Elementor', 'ennova-addons' ) . '</strong>'
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}

	public function admin_notice_missing_wc_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			__( '"%1$s" requires "%2$s" to be installed and activated.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'WooCommerce', 'ennova-addons' ) . '</strong>'
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			__( '"%1$s" requires "%2$s" version %3$s or greater.', 'ennova-addons' ),
			'<strong>' . __( 'Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'Elementor', 'ennova-addons' ) . '</strong>',
			ENNOVA_MIN_ELEMENTOR_VERSION
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			__( '"%1$s" requires "%2$s" version %3$s or greater.', 'ennova-addons' ),
			'<strong>' . __( ' Ennova', 'ennova-addons' ) . '</strong>',
			'<strong>' . __( 'PHP', 'ennova-addons' ) . '</strong>',
			ENNOVA_MIN_PHP_VERSION
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf( '<div class="notice notice-error"><p>%1$s</p></div>', $message );
	}

	public function enqueue_styles() {

		wp_register_style( 'ennova-swiper-custom-css', ENNOVA_URL . 'assets/css/ennova-widget-css.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-image-compare-css', ENNOVA_URL . 'assets/css/juxtapose.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-filter-gallery', ENNOVA_URL . 'assets/css/filter-gallery.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-post-blog-css', ENNOVA_URL . 'assets/css/ennova-post-blog.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-woo-widgets-css', ENNOVA_URL . 'assets/css/ennova-woo-widgets.css', [], ENNOVA_VERSION );

		wp_register_style( 'ennova-bootstrap-css', ENNOVA_URL . 'assets/css/bootstrap.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-styles-css', ENNOVA_URL . 'assets/css/style.css', [], ENNOVA_VERSION );
		wp_register_style( 'ennova-google-fonts', 'https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,200&display=swap', null, ENNOVA_VERSION );

		wp_enqueue_style( 'ennova-filter-gallery' );
		wp_enqueue_style( 'ennova-woo-widgets-css' );
		wp_enqueue_style( 'ennova-post-blog-css' );
		wp_enqueue_style('ennova-bootstrap-css');
		wp_enqueue_style('ennova-styles-css');
		wp_enqueue_style('ennova-google-fonts');
		// wp_enqueue_style( 'ennova-swiper-css' );
		wp_enqueue_style( 'ennova-swiper-custom-css' );
		wp_enqueue_style( 'ennova-image-compare-css' );

		wp_enqueue_style( 'sm-clean-css', ENNOVA_URL . 'assets/css/sm-clean.css');
        wp_enqueue_style( 'sm-core-css', ENNOVA_URL . 'assets/css/sm-core-css.css');
		wp_enqueue_style( 'jquery-auto-complete-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css', array(), '1.13.2' );
		if(defined('ELEMENTOR_ASSETS_URL')) {
			wp_enqueue_style( 'font-awesome', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/all.min.css', array(), null );
		}

	}

	public function enqueue_scripts() {
		// wp_register_script( 'ennova-swiper-js', 'https://unpkg.com/swiper/swiper-bundle.min.js', null, ENNOVA_VERSION, true );
		wp_register_script( 'ennova-swiper-custom-js', ENNOVA_URL . 'assets/js/ennova-widget-js.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-filter-gallery-js', ENNOVA_URL . 'assets/js/ennova-filter-gallery.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-image-compare-js', ENNOVA_URL . 'assets/js/image-compare.js', [], ENNOVA_VERSION, true );
		wp_register_script( 'jquery-smartmenus-js', ENNOVA_URL.'assets/js/jquery.smartmenus.js', ['jquery'], '1.1.1', true );
        wp_register_script( 'ennova-custom-js', ENNOVA_URL.'assets/js/custom.js', ['jquery', 'jquery-smartmenus-js'], ENNOVA_VERSION, true );
        wp_register_script( 'ennova-woo-js', ENNOVA_URL.'assets/js/ennova-woo.js', ['jquery'], ENNOVA_VERSION, true );
		wp_register_script( 'ennova-search-js', ENNOVA_URL . 'assets/js/search.js', [], ENNOVA_VERSION, true );
		wp_enqueue_script('jquery-auto-complete-js','https://code.jquery.com/ui/1.13.2/jquery-ui.js', array( 'jquery' ),'1.13.2',true);

		wp_enqueue_script( 'ennova-filter-gallery-js' );
		wp_enqueue_script( 'ennova-swiper-js' );
		wp_enqueue_script( 'ennova-swiper-custom-js' );
		wp_enqueue_script( 'ennova-image-compare-js' );
		wp_enqueue_script( 'jquery-smartmenus-js' );
        wp_enqueue_script( 'ennova-custom-js' );
        wp_enqueue_script( 'ennova-woo-js' );
		wp_localize_script( 'ennova-woo-js', 'myajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
        wp_enqueue_script( 'ennova-search-js' );
		wp_localize_script(
            'ennova-search-js',
            'search',
            array(
                'ajax' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'woo_tittle_nonce' ),
            )
        );
	}

	public function get_site_name() {
        return '<a class="ennova-copyright-info" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
    }

    public function get_year() {
        return esc_html( date( 'Y' ) );
    }

	public function admin_scripts_styles($hook) {
		$screen = get_current_screen();
        if ( isset( $screen->base ) && $screen->base == 'toplevel_page_ennova_admin_menu') {
            wp_enqueue_script ( 'ennova-admin-js', ENNOVA_URL . 'assets/js/admin.js', [], ENNOVA_VERSION, true );
        }
	}

	public function register_widgets() {
		$this->includes();
		$this->register_slider_widgets();
	}

	public function includes() {
		require_once ENNOVA_PATH . 'inc/widgets/widget-utils.php';

		require_once ENNOVA_PATH . 'inc/widgets/site-logo.php';
		require_once ENNOVA_PATH . 'inc/widgets/site-title.php';
		require_once ENNOVA_PATH . 'inc/widgets/site-tagline.php';
		require_once ENNOVA_PATH . 'inc/widgets/copyright.php';
		require_once ENNOVA_PATH . 'inc/widgets/search.php';
		require_once ENNOVA_PATH . 'inc/widgets/menus.php';

		require_once ENNOVA_PATH . 'inc/widgets/creative-button.php';
		require_once ENNOVA_PATH . 'inc/widgets/dual-button.php';
		require_once ENNOVA_PATH . 'inc/widgets/team.php';
		require_once ENNOVA_PATH . 'inc/widgets/testimonial.php';
		require_once ENNOVA_PATH . 'inc/widgets/feature.php';
		require_once ENNOVA_PATH . 'inc/widgets/dual-heading.php';
		require_once ENNOVA_PATH . 'inc/widgets/flip-box.php';
		require_once ENNOVA_PATH . 'inc/widgets/progress-bar.php';
		require_once ENNOVA_PATH . 'inc/widgets/calltoaction.php';

		require_once ENNOVA_PATH . 'inc/widgets/service.php';
		require_once ENNOVA_PATH . 'inc/widgets/timeline.php';
		require_once ENNOVA_PATH . 'inc/widgets/number-box.php';
		require_once ENNOVA_PATH . 'inc/widgets/portfolio.php';
		require_once ENNOVA_PATH . 'inc/widgets/price.php';
		require_once ENNOVA_PATH . 'inc/widgets/business-hours.php';
		require_once ENNOVA_PATH . 'inc/widgets/price-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/heading.php';
		require_once ENNOVA_PATH . 'inc/widgets/filter-gallery.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-blog-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-blog.php';
		require_once ENNOVA_PATH . 'inc/widgets/post-timeline.php';
		require_once ENNOVA_PATH . 'inc/widgets/author.php';
		require_once ENNOVA_PATH . 'inc/widgets/author-list.php';
		require_once ENNOVA_PATH . 'inc/widgets/image-hotspot.php';
		require_once ENNOVA_PATH . 'inc/widgets/image-comparison.php';

		require_once ENNOVA_PATH . 'inc/widgets/woo-product-slider.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-product-grid.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-category-grid.php';
		require_once ENNOVA_PATH . 'inc/widgets/product-category-tab.php';
		require_once ENNOVA_PATH . 'inc/widgets/product-grid-with-nav.php';
		require_once ENNOVA_PATH . 'inc/widgets/cart.php';
		require_once ENNOVA_PATH . 'inc/widgets/cart-page.php';
		require_once ENNOVA_PATH . 'inc/widgets/checkout.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo-banner.php';
		require_once ENNOVA_PATH . 'inc/widgets/woo_search.php';

		require_once ENNOVA_PATH . 'inc/widgets/cf7.php';
		require_once ENNOVA_PATH . 'inc/widgets/everest-forms.php';
		require_once ENNOVA_PATH . 'inc/widgets/ninja-forms.php';

	}
	public function total_widgets(){
		$All_Widgets = [];
		foreach (registered_widgets() as $widget_setting) {
			foreach ( $widget_setting['widgets'] as $widget) {

				$widget_id = explode(" ",$widget['slug']);
				$widget_id = implode("-ennova-",$widget_id);
			   
				$All_Widgets[] .= get_option($widget_id, $widget_id) == "" ? false : true ;
			}
		}

		return $All_Widgets;
	}
	public function total_TP_widgets(){
		$All_Widgets = [];
		foreach (third_party_widgets() as $widget_setting) {
		  $widget_id = explode(" ",$widget_setting['name']);
		  $widget_id = implode("-ennova-",$widget_id);
		 
		  $All_Widgets[] .= get_option($widget_id, $widget_id) == "" ? false : true ;
		}

		return $All_Widgets;
	}
	public function register_slider_widgets() {
		$header_scripts = get_option('Copyright',true);
		define("WIDGETS", $this->total_widgets());
		define("TP_WIDGETS", $this->total_TP_widgets());
		$widget_manager = \Elementor\Plugin::instance()->widgets_manager;
		$i = 0;
		foreach ( registered_widgets() as $widgets ) {

			if($widgets['widget_cat'] == 'Ennova Woocommerce'){

				foreach ( $widgets['widgets'] as $widget ) {
					$class_name = '\EnnovaAddons\\'. $widget['name'];
					
					if($widget['ver'] == 'lite') {
						if( !$widget['name'] == '' && !WIDGETS[$i] == false ){
							if(array_key_exists('id', $widget ) && $widget['id'] == 'woocommerce' && class_exists( 'woocommerce' ) ){
								$widget_manager->register( new $class_name() );
							}
						}
					}
					$i++;
					
				}

			}else{
				foreach ( $widgets['widgets'] as $widget ) {
					$class_name = '\EnnovaAddons\\'. $widget['name'];
				
					if($widget['ver'] == 'lite') {		
						if( !$widget['name'] == '' && !WIDGETS[$i] == false ){
							$widget_manager->register( new $class_name() );
						}
					}
					$i++;
					
				}
			}

		}
		$j = 0;
		foreach ( third_party_widgets() as $widget ) {
			$class_name = '\EnnovaAddons\\'. $widget['name'];
			$plug_path = get_plugin_path($widget['id']);
			 if(is_plugin_active($plug_path)){ 
				if( !$widget['name'] == '' && !TP_WIDGETS[$j] == '' ){
					$widget_manager->register( new $class_name() );
				}
			}
			$j++;
		}
	}

	public function init_controls() {
		require_once ENNOVA_PATH . 'inc/controls/class-selectize-control.php';
		\Elementor\Plugin::instance()->controls_manager->register_control('meta-store-selectize', new Selectize_Control() );
	}

	public function file_include(){
		require_once ENNOVA_PATH . 'inc/admin.php';
		require_once ENNOVA_PATH . 'inc/widgets/scroll-to-top.php';
	}
}

Plugin::instance();
