<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;

class ENNOVAProductGridWithNav extends \Elementor\Widget_Base {

	private $product_class = 'ennova-product-grid-nav-item';
	private $product_img = 'ennova-product-grid-nav-image';
	private $product_title = 'ennova-product-grid-nav-title';
	private $product_price = 'ennova-product-grid-nav-price';
	private $product_btn = 'ennova-product-grid-nav-button';
	private $product_icon = 'ennova-product-grid-nav-icon';
	private $product_tag = 'ennova-product-grid-nav-tag';
	private $product_rating = 'ennova-product-grid-nav-rating';
	private $product_category = 'ennova-product-grid-nav-category';

	public function get_name() {
		return 'ennova-product-grid-with-nav';
	}

	public function get_title() {
		return __( 'Products Grid with Nav', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-woo-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-products';
	}

	public function get_style_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-post-blog',
		];
	}

	public function get_keywords() {
		return [
			'product grid with nav',
			'sorting',
			'product filter',
			'ennova addons',
			'enn',
			'woo',
		];
	}

	protected function render() {
		$settings                    = $this->get_settings_for_display();

		$template_style = $settings['template_style'];

		
		$category_class = '';
		$hide = '';

		$args['status'] = 'publish';
		$args['limit']  = 10;

		if ( isset( $settings['posts_per_page'] ) && intval( $settings['posts_per_page'] ) > 0 ) {
			$args['limit'] = $settings['posts_per_page'];
		}


		if ( isset( $settings['product_category'] ) && is_array( $settings['product_category'] ) && ! empty( $settings['product_category'] ) ) {
			$args['category'] = $settings['product_category'];
		}
		if ( isset( $settings['product_tags'] ) && is_array( $settings['product_tags'] ) && ! empty( $settings['product_tags'] ) ) {
			$args['tag'] = $settings['product_tags'];
		}
		if ( isset( $settings['include_featured'] ) && ! empty( $settings['include_featured'] ) && $settings['include_featured'] === 'yes' ) {
			$args['featured'] = true;
		}
		if ( isset( $settings['latest_product'] ) && ! empty( $settings['latest_product'] ) && $settings['latest_product'] === 'yes' ) {
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
		}

		$title = '';
		if ( isset( $settings['title'] ) && ! empty( $settings['title'] ) ) {
			$title = $settings['title'];
		}

		$this->add_render_attribute( 'wrapper', 'class', 'ennova-outer-wrapper' );
		$this->add_render_attribute( 'wrapper', 'data-wid', $this->get_id() );
		$is_best_rated = $settings['only_best_rated_product'];
		$best_rated_count = $settings['best_rated_count'];
		$display_title = $settings['display_title'];
		$product_design = $settings['product_design'];

		$display_rating = array_key_exists('display_rating', $settings) ? $settings['display_rating'] : false;
		$display_category = array_key_exists('display_category', $settings) && $settings['display_category'] === 'yes' ? true : false;
		$display_price  = array_key_exists('display_price', $settings) ? $settings['display_price'] : false;
		// $display_image  = array_key_exists('display_image', $settings) ? $settings['display_image'] : false;
		$on_sales_ids = wc_get_product_ids_on_sale();
		$only_on_sale = false;
		$only_best_sale = false;
		$best_sale_count = 0;
		$show_cart_button = true;
		if (isset($settings['only_on_sale']) && !empty($settings['only_on_sale']) && $settings['only_on_sale'] === 'yes') {
			$only_on_sale = true;
		}
		if (isset($settings['display_add_to_cart_button']) && empty($settings['display_add_to_cart_button']) && $settings['display_add_to_cart_button'] !== 'yes') {
			$show_cart_button = false;
		}

		$show_wishlist_button = true;
		if (isset($settings['show_wishlist_button']) && empty($settings['show_wishlist_button']) && $settings['show_wishlist_button'] !== 'yes') {
			$show_wishlist_button = false;
		}
		$show_quickview_button = true;
		if (isset($settings['show_quickview_button']) && empty($settings['show_quickview_button']) && $settings['show_quickview_button'] !== 'yes') {
			$show_quickview_button = false;
		}

		if (isset($settings['only_best_sale']) && !empty($settings['only_best_sale']) && $settings['only_best_sale'] === 'yes') {
			$only_best_sale = true;
			if ( isset( $settings['best_sale_count'] ) && intval( $settings['best_sale_count'] ) > 0 ) {
				$best_sale_count = $settings['best_sale_count'];
			}
		}

		$thumbnail_size_key = 'thumbnail_size';
		$swiper_div_tabs = false;

		$cat_details = [];
		$counter     = 0;
		if ( $cat_details ) {
			$args['category'] = [
				$cat_details['slug']
			];
		}



		if(!function_exists('wc_get_products')) {
			return;
		  }

		  $paged                   = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;
		  $ordering                = WC()->query->get_catalog_ordering_args();
		  $temp = explode(' ', $ordering['orderby']);
		  $ordering['orderby']     = array_shift($temp);
		  $ordering['orderby']     = stristr($ordering['orderby'], 'price') ? 'meta_value_num' : $ordering['orderby'];
		  $products_per_page       = apply_filters('loop_shop_per_page', wc_get_default_products_per_row() * wc_get_default_product_rows_per_page());


		  $args['page'] = $paged;
		  $args['orderby'] =  $ordering['orderby'];
		  $args['order'] =  $ordering['order'];


		$pagination_type = $settings['pagination_type'];
		if ( $pagination_type !== 'none' ) {
			$args['paginate'] = true;
		}else{
			$args['paginate'] = false;
		}

		$featured_products = wc_get_products( $args );
		
		  wc_set_loop_prop('current_page', $paged);
		  wc_set_loop_prop('is_paginated', wc_string_to_bool(true));
		  wc_set_loop_prop('page_template', get_page_template_slug());
		  wc_set_loop_prop('per_page', $products_per_page);
		  if (is_array($featured_products)) {
			wc_set_loop_prop('total', count($featured_products));
			wc_set_loop_prop('total_pages', ceil(count($featured_products) / $products_per_page));
		} else {
			wc_set_loop_prop('total', $featured_products->total);
			wc_set_loop_prop('total_pages', $featured_products->max_num_pages);
		}

		  if($featured_products) {
			do_action('woocommerce_before_shop_loop');
			woocommerce_product_loop_start();
			if (is_array($featured_products)) {
				$products = $featured_products;
				require ENNOVA_PATH . 'inc/templates/style-1/product-slider-grid-template.php';
			} else {
				$products = $featured_products->products;
				require ENNOVA_PATH . 'inc/templates/style-1/product-slider-grid-template.php';
			}
			wp_reset_postdata();
			woocommerce_product_loop_end();
			if ( $pagination_type !== 'none' ) {
				if ( $pagination_type === 'previous/next' ) {
					$this->ennova_pagi_previous_next( $featured_products->max_num_pages );
				}
			}
		  } else {
			do_action('woocommerce_no_products_found');
		  }

		  return;






		$all_products = wc_get_products( $args );
		$products = $all_products->products;;

		echo $all_products->total . ' products found\n';
		echo 'Page 1 of ' . $all_products->max_num_pages . '\n';
		require ENNOVA_PATH . 'inc/templates/style-1/product-slider-grid-template.php';


	}

	function ennova_pagi_number_pre_next( $max_num_pages ) {
		$big = 999999999; // need an unlikely integer
		echo '<div class=" ennova-navigation navigation">' . "\n";
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var('paged') ),
			'total' => $max_num_pages,
			'show_all' => true,
			'type'       => 'list',
			'mid_size'   => 1,
		) );
		echo '</div>' . "\n";
	}

	function ennova_numeric_posts_pagination( $max_num_pages ) {
		$big = 999999999; // need an unlikely integer
		echo '<div class="ennova-navigation navigation">' . "\n";
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var('paged') ),
			'total' => $max_num_pages,
			'show_all' => true,
			'type'       => 'list',
			'mid_size'   => 1,
			'prev_next'  => false,
		) );
		echo '</div>' . "\n";
	}

	function ennova_pagi_previous_next( $max_num_pages ) {

		if( $max_num_pages <= 1 )
			return;

		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
		$max   = intval( $max_num_pages );

		/** Add current page to the array */
		if ( $paged >= 1 )
			$links[] = $paged;

		/** Add the pages around the current page to the array */
		if ( $paged >= 3 ) {
			$links[] = $paged - 1;
			$links[] = $paged - 2;
		}

		if ( ( $paged + 2 ) <= $max ) {
			$links[] = $paged + 2;
			$links[] = $paged + 1;
		}

		echo '<div class="ennova-navigation navigation ennova-pagi-p-n"><ul>' . "\n";
		echo "<li><a href='". get_previous_posts_page_link() ."' class='ennova-pagi-pre-btn page-numbers'>Previous</a></li>";
		echo "<li><a href='". get_next_posts_page_link() ."' class='page-numbers'>Next</a></li>";
		echo '</ul></div>' . "\n";

	}

	protected function register_controls() {

		$this->start_controls_section(
			'query_configuration',
			[
				'label' => __( 'Content Settings 1', 'ennova-addons' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'product_design',
			[
				'label'       => esc_html__( 'Product Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Style from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'card',
				'options'     => [
					'card'      => esc_html__( 'Card ', 'ennova-addons' ),
					'overlay' => esc_html__( 'Overlay', 'ennova-addons' ),
				],
			]
		);
		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2 (Pro)', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_woo_product_nav_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1'],
                ],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'product_category',
				'label'       => 'Product Category',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_product_category(),
				'multiple'    => true,
			]
		);
		
		create_select2(
			$this,
			[
				'key'         => 'product_tags',
				'label'       => 'Product Tags',
				'placeholder' => 'Choose Tags to Include',
				'options'     => ennova_get_product_tags(),
				'multiple'    => true,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'include_featured',
				'label'     => 'Include Only Featured Products',
				'on_label'  => 'Yes',
				'off_label' => 'No',

			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'only_best_rated_product',
				'label'     => 'Include Only Best Rated Products',
				'on_label'  => 'Yes',
				'off_label' => 'No',

			]
		);

		create_number(
			$this,
			[
				'key'         => 'best_rated_count',
				'label'       => 'Rating Count',
				'placeholder' => 'Default is 0',
				'min'         => 0,
				'max'         => 5,
				'default'     => 0,
				'condition'   => [
					'only_best_rated_product' => 'yes',
				],
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'only_on_sale',
				'label'     => 'Only On Sale Products',
				'on_label'  => 'Yes',
				'off_label' => 'No',

			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'only_best_sale',
				'label'     => 'Only Best Selling Products',
				'on_label'  => 'Yes',
				'off_label' => 'No',

			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'latest_product',
				'label'     => 'Latest Products First',
				'on_label'  => 'Yes',
				'off_label' => 'No',

			]
		);

		create_number(
			$this,
			[
				'key'         => 'best_sale_count',
				'label'       => 'Selling Products Count',
				'placeholder' => 'Default is 0',
				'min'         => -1,
				'default'     => 0,
				'condition'   => [
					'only_best_sale' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_configuration',
			[
				'label' => __( 'Item Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_number(
			$this,
			[
				'key'         => 'posts_per_page',
				'label'       => 'Limit',
				'placeholder' => 'Default is 8',
				'min'         => 1,
				'max'         => 10,
				'default'     => 8,
			]
		);

		$this->add_responsive_control(
			'grid_column_count',
			[
				'label' => esc_html__( 'Grid Column Count', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>' ,
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'4' => esc_html__( '4', 'ennova-addons' ),
				],
				'classes' => 'ennova-pro-popup-notice',
			]
		);

		$this->add_responsive_control(
			'grid_column_gap',
			[
				'label'           => __( 'Grid Column Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 15,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} .ennova-product-grid-wrapper ' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			'grid_row_gap',
			[
				'label'           => __( 'Grid Row Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 15,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 30,
					'unit' => 'px',
				], 
				'selectors'   => [
					'{{WRAPPER}} .ennova-product-grid-wrapper ' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		// slider title

			create_switcher(
				$this,
				[
					'key'       => 'display_title',
					'label'     => 'Show Title',
					'on_label'  => 'Yes',
					'off_label' => 'No',
					'default'   => 'yes',
				]
			);

		// slider title ends

		// slider price

		create_switcher(
			$this,
			[
				'key'       => 'display_price',
				'label'     => 'Show Price',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		// slider price ends

		// slider rating

		create_switcher(
			$this,
			[
				'key'       => 'display_rating',
				'label'     => 'Show Rating',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		// slider rating ends

		create_switcher(
			$this,
			[
				'key'       => 'display_category',
				'label'     => 'Show Category',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		// slider button

		create_switcher(
			$this,
			[
				'key'       => 'display_add_to_cart_button',
				'label'     => 'Show Add to Cart Button',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		// slider button ends

		create_switcher(
			$this,
			[
				'key'       => 'show_wishlist_button',
				'label'     => 'Show Wishlist Button',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_quickview_button',
				'label'     => 'Show Quick View Button',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'show_compare_button',
				'label'     => 'Show Compare Button',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'No',
				'classes' => 'ennova-pro-popup-notice',
				'escape' => false,
			]
		);

		// slider image

		create_image_size_control(
			$this,
			[
				'name'      => 'thumbnail_size',
				'default'   => 'thumbnail',
			]
		);

		// slider ends
		$this->end_controls_section();

		$this->start_controls_section(
			'pagination',
			[
				'label' => __( 'Pagination', 'ennova-addons' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'pagination_type',
				'label'       => 'Pagination',
				'placeholder' => 'Choose pagination to include',
				'options'     => [
					'none' => 'None',
					'previous/next' => 'Previous/Next',
					'numbers' => 'Numbers (Pro)',
					'numbers+previous/next' => 'Numbers + Previous/Next (Pro)',
				],
				'default' => 'previous/next',
				'multiple'    => false,
			]
		);

		$this->add_control(
			'ennova_woo_product_pagination_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'pagination_type!' => ['none', 'previous/next'],
                ],
			]
		);

		create_alignment(
			$this,
			[
				'key'       => 'pagination_align',
				'label'     => 'Alignment',
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .navigation,{{WRAPPER}} .woocommerce-pagination .page-numbers' => 'justify-content: {{VALUE}}',
				],
				'condition'   => [
					'pagination_type' => 'previous/next',
				],
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);

		// style item
		$this->start_controls_section(
			'section_nav_style',
			[
				'label' => __( 'Nav Style', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,

			]
		);

        $this->add_control(
            'heading_result',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => __( 'Showing Result', 'ennova-addons' ),
                'separator' => 'before',
            ]
        );

		create_color_control(
			$this,
			[
				'key'       => 'nav_result_count_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-result-count' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'nav_result_count_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .woocommerce-result-count',
			]
		);

        $this->add_control(
            'heading_shorting',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => __( 'Shorting', 'ennova-addons' ),
                'separator' => 'before',
            ]
        );

		create_color_control(
			$this,
			[
				'key'       => 'nav_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'nav_text_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'nav_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .woocommerce-ordering .orderby',
			]
		);

        $this->add_control(
            'heading_shorting_option',
            [
                'type'      => Controls_Manager::HEADING,
                'label'     => __( 'Shorting Options', 'ennova-addons' ),
                'separator' => 'before',
            ]
        );

		create_color_control(
			$this,
			[
				'key'       => 'nav_options_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby option' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => 'nav_options_text_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby option' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'nav_options_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .woocommerce-ordering .orderby option',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'nav_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .woocommerce-ordering .orderby',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'nav_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'nav_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'nav_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .woocommerce-ordering .orderby' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'nav_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .woocommerce-ordering .orderby',
				'separator' => 'after',
				
			]
		);

		$this->end_controls_section();
		// style item ends

		// style item
		$this->start_controls_section(
			'section_item_style',
			[
				'label' => __( 'Item Box', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
	
			]
			);
		$slug = 'section_iteam';

		create_color_control(
		$this,
		[
			'key'       => $slug.'_bg_color',
			'label'     => 'Background Color',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_class => 'background-color: {{VALUE}};',
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_class,
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_radius',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_padding',
			'label'     => 'Padding',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_box_shadow_control(
		$this,
		[
			'key'      => $slug.'_box_shadow',
			'label'    => 'Box Shadow',
			'selector' => '{{WRAPPER}} .'.$this->product_class,
		]
		);

		$this->end_controls_section();
		// style item ends

		// styles image

		$this->start_controls_section(
		'section_image_style',
		[
			'label'     => __( 'Image Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
		]
		);

		$slug = 'product_image';

		$this->add_group_control(
		Group_Control_Background::get_type(),
		[
			'name'      => $slug.'_image_overlay_color',
			'types'          => [ 'classic', 'gradient' ],
			'exclude'        => [ 'image' ],
			'fields_options' => [
				'background' => [
					'label'     => __( 'Background ', 'ennova-addons' ),
					'default' => 'classic',
				],
			],
			'selector'  => '{{WRAPPER}} .ennova_thumbnail:before',
			'condition'   => [
				'template_style' => 'layout_1',
				'product_design' => 'overlay',
			],
		]
		);

		$this->add_responsive_control(
		$slug.'_overlay_opacity',
		[
			'label' => esc_html__( 'Opacity', 'ennova-addons' ),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'max' => 1,
					'step' => 0.01,
				],
			],
			'selectors'  => [
				'{{WRAPPER}} .ennova_thumbnail:before' => 'opacity: {{SIZE}};',
			],
			'condition'   => [
				'template_style' => 'layout_1',
				'product_design' => 'overlay',
			],
		]
		);

		$this->add_responsive_control(
		$slug.'_image_width',
		[
			'label'           => __( 'Image Width', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px', '%' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 1200,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' =>'' ,
				'unit' => '%',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => '%',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => '%',
			],
			'selectors'       => [
				'{{WRAPPER}} .'.$this->product_img.' img' => 'width: {{SIZE}}{{UNIT}};', 
			],
		],
		);

		$this->add_responsive_control(
		$slug.'_image_height',
		[
			'label'           => __( 'Image Height', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px', '%' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 1200,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'selectors'       => [
				'{{WRAPPER}} .'.$this->product_img.' img' => 'height: {{SIZE}}{{UNIT}};', 
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_img.' img',
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_radius',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_img.' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_img.' img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();
		// styles image ends

		// Icon Settings
		$this->start_controls_section(
		'product_icon_settings',
		[
			'label' => __( 'Icon Settings', 'ennova-addons' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		]
		);
		$slug = 'product_icon';

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		$slug.'_width',
		[
			'label'           => __( 'Icon Width', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px', '%' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 150,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'selectors'       => [
				'{{WRAPPER}} .'.$this->product_icon.' a' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		$slug.'_size',
		[
			'label'           => __( 'Icon Size', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px', '%' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 120,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'selectors'       => [
				'{{WRAPPER}} .'.$this->product_icon.' a i' => 'font-size: {{SIZE}}{{UNIT}};',
			],
		]
		);

		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
		$slug.'_normal_style',
		[
			'label' => __( 'Normal', 'ennova-addons' ),
		]
		);

		$this->add_control(
		$slug.'_bg_color',
		[
			'label'     => __( 'Background Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_icon.' a' => 'background-color: {{VALUE}}',
			],
		]
		);

		$this->add_control(
		$slug.'_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_icon.' a i' => 'color: {{VALUE}}',
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_icon. ' a',
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_type',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
		$slug.'_style_hover',
		[
			'label' => __( 'Hover', 'ennova-addons' ),

		]
		);

		$this->add_control(
		$slug.'_before_bg_color_hover',
		[
			'label'     => __( 'Background Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a:before' => 'background-color: {{VALUE}}',
			],
			'condition' => [
				'template_style' => ['layout_1']
			]
		]
		);

		$this->add_control(
		$slug.'_color_hover',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a:hover i' => 'color: {{VALUE}}',
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type_hover',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_icon.':hover a' ,
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_radius_hover',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.':hover a' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .'.$this->product_icon.' a:before' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();
		// end item icon

		// styles tooltip
		$this->start_controls_section(
		'section_item_tooltip_style',
		[
			'label'     => __( 'Tooltip Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
		]
		);
		$slug = 'product_tooltip';

		$this->add_control(
		$slug.'_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_icon.' a .enn-tooltip' => 'color: {{VALUE}}',
			],
		]
		);

		$this->add_control(
		$slug.'_bg_color',
		[
			'label'     => __( 'Background Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_icon.' a .enn-tooltip' => 'background-color: {{VALUE}}',
				'{{WRAPPER}}  .'.$this->product_icon.' a .enn-tooltip::after' => 'background-color: {{VALUE}}',
			],
		]
		);

		create_typography_control(
		$this,
		[
			'name'     => $slug.'_typography',
			'label'    => 'Typography',
			'selector' => '{{WRAPPER}}  .'.$this->product_icon.' a .enn-tooltip',
		]
		);

		$this->add_responsive_control(
		$slug.'_spacing',
		[
			'label'           => __( 'Cart Size', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 20,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'selectors'       => [
				'{{WRAPPER}} .'.$this->product_icon.' a .enn-tooltip::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			],
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_radius',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a .enn-tooltip' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_padding',
			'label'     => 'Padding',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_icon.' a .enn-tooltip' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_section();
		// style tooltip ends

		// style sale label 
		$this->start_controls_section(
			'section_item_label_settings',
			[
				'label' => __( 'Sale Tag Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE, 
			]
		);

		$slug = 'product_label';
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->product_tag.' span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->product_tag.' span' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->product_tag.' span',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_tag.' span',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_tag.' span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_tag.' span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_tag.' span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// style sale label ends

		// styles item title
		$this->start_controls_section(
		'section_item_title_style',
		[
			'label'     => __( 'Title Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
		]
		);

		$slug = 'product_title';

		$this->add_responsive_control(
		$slug.'_alignment',
		[
			'label'     => __( 'Alignment', 'ennova-addons' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'left' => [
					'title' => __( 'Left', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-left',
				],
				'center' => [
					'title' => __( 'Center', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-center',
				],
				'right' => [
					'title' => __( 'Right', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-right',
				],
			],
			'toggle'    => true,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_title => 'text-align: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		$slug.'_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_title.' a' => 'color: {{VALUE}}',
			],
		]
		);

		$this->add_control(
		$slug.'_color_hover',
		[
			'label'     => __( 'Hover Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_class.' .'.$this->product_title.' a:hover' => 'color: {{VALUE}}',
			],
		]
		);

		create_typography_control(
		$this,
		[
			'name'     => $slug.'_typography',
			'label'    => 'Typography',
			'selector' => '{{WRAPPER}}  .'.$this->product_title,
		]
		); 

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_title => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();
		// style item title ends

		// styles item rating
		$this->start_controls_section(
		'section_item_rating_style',
		[
			'label'     => __( 'Rating Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [
				'display_rating' => 'yes',
			],
		]
		);

		create_alignment(
		$this,
		[
			'key'       => 'product_rating_text_align',
			'label'     => 'Alignment',
			'options'   => [
				'flex-start' => [
					'title' => __( 'Left', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-left',
				],
				'center' => [
					'title' => __( 'Center', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-center',
				],
				'flex-end' => [
					'title' => __( 'Right', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-right',
				],
			],
			'default'   => '',
			'selectors' => [
				'{{WRAPPER}} .ennova-outer-wrapper  .ennova-rating' => 'justify-content: {{VALUE}};',
			],
		]
		);

		$slug = 'product_rating';

		create_color_control(
		$this,
		[
			'key'       => 'product_rating_color',
			'label'     => 'Star Color',
			'selectors' => [
				'{{WRAPPER}} .ennova-outer-wrapper  .ennova-rating .ennova-star-rating i::before' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_responsive_control(
		$slug.'_size',
		[
			'label'           => __( 'Size', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px', '%' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 50,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => 'px',
				'size' => '',
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'condition'   => [
				'template_style' => 'product_grid',
			],
			'selectors'   => [
				'{{WRAPPER}} .ennova-outer-wrapper  .ennova-rating .ennova-star-rating' => 'font-size: {{SIZE}}{{UNIT}};',
			],
		],
		);

		$this->add_responsive_control(
		$slug.'_spacing',
		[
			'label'           => __( 'Spacing', 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'size_units'      => [ 'px' ],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 20,
				],
			],
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => [
				'size' => '',
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'mobile_default'  => [
				'size' => '',
				'unit' => 'px',
			],
			'selectors'       => [
				'{{WRAPPER}} .ennova-outer-wrapper  .ennova-rating .ennova-star-rating i' => 'margin-right: {{SIZE}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => 'product_rating_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .ennova-outer-wrapper  .ennova-rating .ennova-star-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();
		// style item rating ends

		// styles item price
		$this->start_controls_section(
		'section_item_price_style',
		[
			'label'     => __( 'Price Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [
				'display_price' => 'yes',
			],
		]
		);


		$slug = 'product_price';

		$this->add_responsive_control(
		$slug.'_alignment',
		[
			'label'     => __( 'Alignment', 'ennova-addons' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'left' => [
					'title' => __( 'Left', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-left',
				],
				'center' => [
					'title' => __( 'Center', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-center',
				],
				'right' => [
					'title' => __( 'Right', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-right',
				],
			],
			'toggle'    => true,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_price => 'text-align: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		$slug.'_ragular_heading',
		[
			'label' => esc_html__( 'Ragular', 'ennova-addons' ),
			'type' => \Elementor\Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		$slug.'_ragular_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_price.'' => 'color: {{VALUE}}',
				'{{WRAPPER}}  .'.$this->product_price.' del bdi' => 'color: {{VALUE}}',
			],
		]
		);

		create_typography_control(
		$this,
		[
			'name'     => $slug.'_ragular_typography',
			'label'    => 'Typography',
			'selector' => '{{WRAPPER}}  .'.$this->product_price.' bdi',
		]
		); 

		$this->add_control(
		$slug.'_sale_heading',
		[
			'label' => esc_html__( 'Sale ', 'ennova-addons' ),
			'type' => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		]
		);

		$this->add_control(
		$slug.'_sale_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_price.' ins bdi' => 'color: {{VALUE}}',
			],
		]
		);

		create_typography_control(
		$this,
		[
			'name'     => $slug.'_sale_typography',
			'label'    => 'Typography',
			'selector' => '{{WRAPPER}}  .'.$this->product_price.' ins bdi',
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_price.' bdi'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();
		// style item price ends

		// styles item add to cart button
		$this->start_controls_section(
		'section_item_add_to_cart_btn_style',
		[
			'label'     => __( 'Button Settings', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [
				'display_add_to_cart_button' => 'yes',
			],
		]
		);

		$slug = 'product_btn';
		$this->add_responsive_control(
		$slug.'_alignment',
		[
			'label'     => __( 'Alignment', 'ennova-addons' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'start' => [
					'title' => __( 'Left', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-left',
				],
				'center' => [
					'title' => __( 'Center', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-center',
				],
				'end' => [
					'title' => __( 'Right', 'ennova-addons' ),
					'icon'  => 'eicon-text-align-right',
				],
			],
			'toggle'    => true,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_btn => 'text-align: {{VALUE}};',
				
			]
		],
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
		$slug.'_normal_style',
		[
			'label' => __( 'Normal', 'ennova-addons' ),
		]
		);

		$this->add_control(
		$slug.'_color',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_btn.' a' => 'color: {{VALUE}}',
			],
		]
		);

		$this->add_control(
		$slug.'_bg_color',
		[
			'label'     => __( 'Background Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}  .'.$this->product_btn.' a' => 'background-color: {{VALUE}}',
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_btn.' a',
		]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
		$slug.'_style_hover',
		[
			'label' => __( 'Hover', 'ennova-addons' ),

		]
		);

		$this->add_control(
		$slug.'_color_hover',
		[
			'label'     => __( 'Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_btn.' a:hover' => 'color: {{VALUE}}',
			],
		]
		);

		$this->add_control(
		$slug.'_bg_color_hover',
		[
			'label'     => __( 'Background Color', 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_btn.' a:after' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .'.$this->product_btn.' a:before' => 'background-color: {{VALUE}}',
			],
		]
		);

		create_border_control(
		$this,
		[
			'name'     => $slug.'_border_type_hover',
			'label'    => 'Border Type',
			'selector' => '{{WRAPPER}} .'.$this->product_btn.' a:hover',
		]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 

		$this->add_control(
		'hr',
		[
			'type' => Controls_Manager::DIVIDER,
		]
		);

		create_typography_control(
		$this,
		[
			'name'     => $slug.'_typography',
			'label'    => 'Typography',
			'selector' => '{{WRAPPER}}  .'.$this->product_btn.' a',
		]
		);

		create_border_radius_control(
		$this,
		[
			'key'       => $slug.'_border_radius',
			'label'     => 'Border Radius',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_btn.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_padding',
			'label'     => 'Padding',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_btn.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_dimensions_control(
		$this,
		[
			'key'       => $slug.'_margin',
			'label'     => 'Margin',
			'selectors' => [
				'{{WRAPPER}} .'.$this->product_btn.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		create_box_shadow_control(
		$this,
		[
			'key'      => $slug.'_box_shadow',
			'label'    => 'Box Shadow',
			'selector' => '{{WRAPPER}}  .'.$this->product_btn.' a',
		]
		);

		$this->end_controls_section();
		// style item add to cart btn ends

		// style item pagination
		$this->start_controls_section(
			'pagination_style',
			[
				'label' => __( 'Pagination Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'pagination';
		$this->start_controls_tabs( $slug.'_style_tabs' );
		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);
		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_background_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova-navigation li .page-numbers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow_hover',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .ennova-navigation li .page-numbers',
			]
		);
		$this->end_controls_section();
		// style item pagination ends

	}
}
