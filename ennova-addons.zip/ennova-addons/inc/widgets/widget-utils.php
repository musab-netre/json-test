<?php use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

if (
	! function_exists( 'ennova_pro_promotion_controls' )
) {
	function ennova_pro_promotion_controls( $obj )
    {
        $obj->start_controls_section(
			'ennova_section_pro',
			[
				'label' => __('Go Premium for More Features', 'ennova-addons'),
			]
		);

		$obj->add_control(
			'ennova_control_get_pro',
			[
				'label'       => __('Unlock more elements', 'ennova-addons'),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'1' => [
						'title' => '',
						'icon' => 'eicon-lock',
					],
				],
				'default'     => '1',
				'description' => ENNOVA_GO_PRO_HTML,
			]
		);

		$obj->end_controls_section();
    }
}

function create_select2( $obj, $params ) {
	$label       = $params['label'];
	$placeholder = $params['placeholder'];
	$key         = $params['key'];
	$default   = array_key_exists( 'default', $params ) ? $params['default'] : '';
	$classes   = array_key_exists( 'classes', $params ) ? $params['classes'] : '';
	$label = array_key_exists( 'escape', $params ) && $params['escape'] == false ? esc_html__( $label, 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>'  : esc_html__( $label, 'ennova-addons' );
	return $obj->add_control(
		$key,
		[
			'label'       => $label,
			'placeholder' => esc_html__( $placeholder, 'ennova-addons' ),
			'type'        => Controls_Manager::SELECT2,
			'label_block' => true,
			'multiple'    => $params['multiple'],
			'default'     => $default,
			'options'     => $params['options'],
			'classes'   => $classes,
		]
	);
}

function create_switcher( $obj, $params ) {
	$label     = $params['label'];
	$on_label  = $params['on_label'];
	$off_label = $params['off_label'];
	$key       = $params['key'];
	$default   = array_key_exists( 'default', $params ) ? $params['default'] : 'no';
	$description   = array_key_exists( 'description', $params ) ? $params['description'] : '';
	$classes   = array_key_exists( 'classes', $params ) ? $params['classes'] : '';
	$label = array_key_exists( 'escape', $params ) && $params['escape'] == false ? esc_html__( $label, 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>'  : esc_html__( $label, 'ennova-addons' );
	return $obj->add_control(
		$key,
		[
			'label'        =>  $label,
			'type'         => Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( $on_label, 'ennova-addons' ),
			'label_off'    => esc_html__( $off_label, 'ennova-addons' ),
			'return_value' => 'yes',
			'default'      => $default,
			'description' => $description,
			'classes' => $classes,
		]
	);
}

function create_number( $obj, $params ) {
	$label     = $params['label'];
	$placeholder = $params['placeholder'];
	$key         = $params['key'];
	$min         = array_key_exists( 'min', $params ) ? $params['min'] : '';
	$max         = array_key_exists( 'max', $params ) ? $params['max'] : '';
	$default     = $params['default'];
	$condition   = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$description   = array_key_exists( 'description', $params ) ? $params['description'] : '';
	$classes   = array_key_exists( 'classes', $params ) ? $params['classes'] : '';
	$label = array_key_exists( 'escape', $params ) && $params['escape'] == false ? esc_html__( $label, 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>'  : esc_html__( $label, 'ennova-addons' );

	return $obj->add_control(
		$key,
		[
			'label'       => $label,
			'placeholder' => esc_html__( $placeholder, 'ennova-addons' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => $min,
			'max'         => $max,
			'default'     => $default,
			'condition'   => $condition,
			'description' => $description,
			'classes' => $classes,
		]
	);
}

function create_responsive_number( $obj, $params ) {
	$label       = $params['label'];
	$placeholder = $params['placeholder'];
	$key         = $params['key'];
	$min         = $params['min'];
	$default     = $params['default'];
	$condition   = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$selectors   = array_key_exists( 'selectors', $params ) ? $params['selectors'] : [];

	$fields = [
			'label'       => esc_html__( $label, 'ennova-addons' ),
			'placeholder' => esc_html__( $placeholder, 'ennova-addons' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => $min,
			'condition'   => $condition,
			'selectors'   => $selectors,
	];

	if ( $default ) {
		$fields['default'] = $default;
	}

	return $obj->add_responsive_control(
		$key,
		$fields
	);
}


function create_number_responsive_control( $obj, $params ) {
	$label       = $params['label'];
	$placeholder = $params['placeholder'];
	$key         = $params['key'];
	$min         = $params['min'];
	$max         = array_key_exists( 'max', $params ) ? $params['max'] : [];
	$default     = $params['default'];
	$condition   = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$selectors   = array_key_exists( 'selectors', $params ) ? $params['selectors'] : [];
	$description   = array_key_exists( 'description', $params ) ? $params['description'] : [];
	$classes   = array_key_exists( 'classes', $params ) ? $params['classes'] : '';
	$label = array_key_exists( 'escape', $params ) && $params['escape'] == false ? esc_html__( $label, 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>'  : esc_html__( $label, 'ennova-addons' );
	return $obj->add_responsive_control(
		$key,
		[
			'label'       => $label,
			'placeholder' => esc_html__( $placeholder, 'ennova-addons' ),
			'type'        => Controls_Manager::NUMBER,
			'max'         => $max,
			'min'         => $min,
			'default'     => $default,
			'condition'   => $condition,
			'selectors'   => $selectors,
			'description'   => $description,
			'classes'   => $classes,
		]
	);
}

function create_image_size_control( $obj, $params ) {
	$name      = $params['name'];
	$default   = $params['default'];
	$condition = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	return $obj->add_group_control(
		Group_Control_Image_Size::get_type(),
		[
			'name'      => $name,
			'default'   => $default,
			'condition' => $condition,
		]
	);
}

function create_alignment( $obj, $params ) {
	$left  = ! is_rtl() ? 'left' : 'right';
	$right = ! is_rtl() ? 'right' : 'left';

	$label     = $params['label'];
	$options   = $params['options'];
	$default   = $params['default'];
	$selectors =  array_key_exists( 'selectors', $params ) ? $params['selectors'] : [];
	$key       = $params['key'];
	$condition = array_key_exists( 'condition', $params ) ? $params['condition'] : [];

	return $obj->add_responsive_control(
		$key,
		[
			'label'                => __( $label, 'ennova-addons' ),
			'type'                 => Controls_Manager::CHOOSE,
			'options'              => $options,
			'selectors_dictionary' => [
				'left'  => $left,
				'right' => $right,
			],
			'default'              => $default,
			'toggle'               => true,
			'selectors'            => $selectors,
			'condition' => $condition,
		]
	);
}

function create_border_control( $obj, $params ) {
	$name     = $params['name'];
	$label    = array_key_exists( 'label', $params ) ? $params['label'] : [];
	$selector = $params['selector'];
	$condition = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$fields_options = array_key_exists( 'fields_options', $params ) ? $params['fields_options'] : [];
	$exclude = array_key_exists( 'exclude', $params ) ? $params['exclude'] : [];

	return $obj->add_group_control(
		Group_Control_Border::get_type(),
		[
			'label'    => __( $label, 'ennova-addons' ),
			'name'     => $name,
			'selector' => $selector,
			'condition' => $condition,
			'fields_options' => $fields_options,
			'exclude' => $exclude,
		]
	);
}

function create_border_radius_control( $obj, $params ) {
	$key       = $params['key'];
	$label     = $params['label'];
	$selectors = $params['selectors'];
	$condition = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$separator = array_key_exists( 'separator', $params ) ? $params['separator'] : '';

	return $obj->add_responsive_control(
		$key,
		[
			'label'      => __( $label, 'ennova-addons' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%' ],
			'selectors'  => $selectors,
			'condition' => $condition,
			'separator' => $separator,
		]
	);
}

function create_box_shadow_control( $obj, $params ) {
	$key      = $params['key'];
	$label    = $params['label'];
	$selector = $params['selector'];
	$separator = array_key_exists( 'separator', $params ) ? $params['separator'] : '';


	return $obj->add_group_control(
		Group_Control_Box_Shadow::get_type(),
		[
			'name'     => $key,
			'label'    => __( $label, 'ennova-addons' ),
			'selector' => $selector,
			'separator'=> $separator,
		]
	);
}

function create_text_shadow_control( $obj, $params ) {
	$key      = $params['key'];
	$label    = $params['label'];
	$selector = $params['selector'];

	return $obj->add_group_control(
		Group_Control_Text_Shadow::get_type(),
		[
			'name'     => $key,
			'label'    => __( $label, 'ennova-addons' ),
			'selector' => $selector,
		]
	);
}

function create_color_control( $obj, $params ) {
	$key       = $params['key'];
	$label     = $params['label'];
	$selectors = array_key_exists( 'selectors', $params ) ? $params['selectors'] : '';
	$separator = array_key_exists( 'separator', $params ) ? $params['separator'] : '';

	return $obj->add_control(
		$key,
		[
			'label'     => __( $label, 'ennova-addons' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => $selectors,
			'separator' => $separator,
		]
	);
}

function create_typography_control( $obj, $params ) {
	$name     = $params['name'];
	$label    = $params['label'];
	$selector = $params['selector'];

	return $obj->add_group_control(
		Group_Control_Typography::get_type(),
		[
			'label'    => __( $label, 'ennova-addons' ),
			'name'     => $name,
			'selector' => $selector,

		]
	);
}

function create_dimensions_control( $obj, $params ) {
	$key       = $params['key'];
	$label     = $params['label'];
	$selectors = $params['selectors'];
	$condition = array_key_exists( 'condition', $params ) ? $params['condition'] : [];
	$default = array_key_exists('default', $params) ? $params['default'] : [];

	return $obj->add_responsive_control(
		$key,
		[
			'label'      => __( $label, 'ennova-addons' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em' ],
			'selectors'  => $selectors,
			'default' => $default,
			'condition' => $condition,
		]
	);
}

function create_slider_control( $obj, $params ) {
	$key             = $params['key'];
	$label           = $params['label'];
	$range           = $params['range'];
	$default_desktop = $params['default_desktop'];
	$tablet_default  = $params['tablet_default'];
	$mobile_default  = $params['mobile_default'];
	$separator       = array_key_exists( 'separator', $params ) ? $params['separator'] : '';
	$size_units       = array_key_exists( 'size_units', $params ) ? $params['size_units'] : '';
	$classes   = array_key_exists( 'classes', $params ) ? $params['classes'] : '';
	$label = array_key_exists( 'escape', $params ) && $params['escape'] == false ? esc_html__( $label, 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>'  : esc_html__( $label, 'ennova-addons' );
	$selectors       = $params['selectors'];

	return $obj->add_responsive_control(
		$key,
		[
			'label'           => __( $label, 'ennova-addons' ),
			'type'            => Controls_Manager::SLIDER,
			'range'           => $range,
			'devices'         => [ 'desktop', 'tablet', 'mobile' ],
			'desktop_default' => $default_desktop,
			'tablet_default'  => $tablet_default,
			'mobile_default'  => $mobile_default,
			'separator'       => $separator,
			'size_units'       => $size_units,
			'selectors'       => $selectors,
			'classes'       => $classes,
		]
	);
}

function create_text_control( $obj, $params ) {
	$label       = $params['label'];
	$key         = $params['key'];
	$placeholder = $params['placeholder'];
	$default     = $params['default'];

	return $obj->add_control(
		$key,
		[
			'label'       => __( $label, 'ennova-addons' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => $default,
			'placeholder' => __( $placeholder, 'ennova-addons' ),
		]
	);
}

function create_navigation_style( $obj, $params ) {
	$conditions = array_key_exists( 'conditions', $params ) ? $params['conditions'] : [];
	//  Navigation styles
	$obj->start_controls_section(
		'section_navi_arrow_style',
		[
			'label'     => __( 'Navigation Style', 'ennova-addons' ),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => $conditions,
		],
	);

		$obj->start_controls_tabs( 'navi_arrow_btn_tabs' );

		$obj->start_controls_tab(
			'navi_arrow_btn_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),

			]
		);

		create_color_control(
			$obj,
			[
				'key'       => 'navi_arrow_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev' => 'color: {{VALUE}};background-image: none;',
					'{{WRAPPER}} .swiper-button-next' => 'color: {{VALUE}};background-image: none;',
				],
			]
		);

		create_color_control(
			$obj,
			[
				'key'       => 'navi_arrow_bg_color',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev' => 'background-color: {{VALUE}};background-image: none;',
					'{{WRAPPER}} .swiper-button-next' => 'background-color: {{VALUE}};background-image: none;',
				],
			]
		);

		create_border_control(
			$obj,
			[
				'name'     => 'navi_arrow_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-prev,{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-next',
			]
		);

		$obj->end_controls_tab();

		$obj->start_controls_tab(
			'navi_arrow_btn_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		create_color_control(
			$obj,
			[
				'key'       => 'navi_arrow_color_hover',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev:hover' => 'color: {{VALUE}};background-image: none;',
					'{{WRAPPER}} .swiper-button-next:hover' => 'color: {{VALUE}};background-image: none;',
				],
			]
		);

		create_color_control(
			$obj,
			[
				'key'       => 'navi_arrow_bg_color_hover',
				'label'     => 'Background Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev:hover' => 'background-color: {{VALUE}};background-image: none;',
					'{{WRAPPER}} .swiper-button-next:hover' => 'background-color: {{VALUE}};background-image: none;',
				],
			]
		);

		create_border_control(
			$obj,
			[
				'name'     => 'navi_arrow_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-prev:hover,{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-next:hover',
			]
		);

		$obj->end_controls_tab();

		$obj->end_controls_tabs();

		create_slider_control(
			$obj,
			[
				'key'             => 'navi_arrow_size',
				'label'           => 'Arrow Size',
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default_desktop' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 10,
					'unit' => 'px',
				],
				'separator'       => 'before',
				'selectors'       => [
					'{{WRAPPER}} .swiper-button-prev::after' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .swiper-button-next::after' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_slider_control(
			$obj,
			[
				'key'             => 'navi_arrow_width',
				'label'           => 'Arrow Width',
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default_desktop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .swiper-button-prev' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .swiper-button-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		create_border_radius_control(
			$obj,
			[
				'key'       => 'navi_arrow_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ennova_slider_wrapper  .swiper-button-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$obj->end_controls_section();
		//  Navigation styles ends

		//  Pagination styles
		$obj->start_controls_section(
			'section_pagination_arrow_style',
			[
				'label'     => __( 'Pagination Style', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => $conditions,
			],
		);

		create_color_control(
			$obj,
			[
				'key'       => 'pagination_dot_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$obj,
			[
				'key'       => 'pagination_dot_active_color',
				'label'     => 'Active Color',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background-color: {{VALUE}};',
				],
			]
		);

		create_number_responsive_control(
			$obj,
			[
				'key'         => 'pagination_dot_width',
				'label'       => 'Width',
				'min'         => -1,
				'placeholder' => '',
				'default'     => '',
				'selectors'   => [
					'{{WRAPPER}} .ennova_slider_wrapper  .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'width: {{VALUE}}px;',
				],
			]
		);

		create_number_responsive_control(
			$obj,
			[
				'key'         => 'pagination_dot_height',
				'label'       => 'Height',
				'min'         => -1,
				'placeholder' => '',
				'default'     => '',
				'selectors'   => [
					'{{WRAPPER}} .ennova_slider_wrapper  .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'height: {{VALUE}}px;',
				],
			]
		);

		create_dimensions_control(
			$obj,
			[
				'key'       => 'pagination_dot_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .ennova_slider_wrapper  .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$obj->end_controls_section();
		//  Pagination styles ends
}