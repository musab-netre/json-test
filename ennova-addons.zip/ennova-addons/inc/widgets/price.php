<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

class ENNOVAPrice extends \Elementor\Widget_Base {

	private $price_card_class = 'ennova-price-card';
	private $price_card_inner_class = 'ennova-price-inner-card';
	private $price_card_image_class = 'ennova-price-card-image';
	private $price_card_heading_class = 'ennova-price-card-heading';
	private $price_card_plan_class = 'ennova-price-card-plan';
	private $price_card_icon_class = 'ennova-price-card-icon';
	private $price_card_ribbon_class = 'ennova-price-card-ribbon';
	private $price_card_feature_class = 'ennova-price-card-feature';
	private $price_card_read_more_class  = 'ennova-price-card-read-more';
	private $price_sign  = 'ennova-price-currency-sign';
	private $price_value  = 'ennova-price-currency-value';
	private $price_duration  = 'ennova-price-duration';
	private $price_sale  = 'ennova-price-currency-sale';

	public function get_name() {
		return 'ennova-price';
	}

	public function get_title() {
		return __( 'Price Table', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-price-table';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'price table',
			'plan', 
			'price list', 
			'price menus ',
			'ennova addons',
			'enn',
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5 (Pro)', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6 (Pro)', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7 (Pro)', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 8 (Pro)', 'ennova-addons' ),
				],
			]
		);
		$this->add_control(
			'ennova_price_item_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1', 'layout_2'],
                ],
			]
		);
		$this->add_control(
			'primary_box', 
			[
				'label' => esc_html__('Main Box', 'ennova-addons') , 
				'type' => Controls_Manager::SWITCHER, 
				'return_value' => 'show', 
				'default' => ' ', 
			]
		);
		$this->add_control(
			'card_title', [
				'label' => __( 'Plan Name', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Basic Plan' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'currency_symbol', [
				'label' => __( 'Currency Symbol', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '$' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'price_amount', [
				'label' => __( 'Price Amount', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '69' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'price_per_plan', [
				'label' => __( 'Price Duration', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '/ Month' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'sale_switch', 
			[
				'label' => esc_html__('Sale', 'ennova-addons') , 
				'type' => Controls_Manager::SWITCHER, 
				'return_value' => 'show', 
				'default' => ' ', 
			]
		);
		$this->add_control(
			'price_sale_amount', [
				'label' => __( 'Original Price Amount', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '99' , 'ennova-addons' ),
				'label_block' => true,
				'condition' => [
					'sale_switch' => 'show'
				]
			]
		);
		$this->add_control(
			'card_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'solid',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						], 
					],
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'features_section',
			[
				'label' => __( 'Features', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_list_icon', 
			[
				'label' => esc_html__('List Icon', 'ennova-addons') , 
				'type' => Controls_Manager::SWITCHER, 
				'return_value' => 'show', 
				'default' => 'show', 
			]
		);
		$this->add_responsive_control(
			'features_icon_position',
			[
				'label'       => esc_html__( 'Icon Position', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'after',
				'options'     => [
					'before'      => esc_html__( 'Before', 'ennova-addons' ),
					'after'      => esc_html__( 'After', 'ennova-addons' ),
				],

			]
		);
	    $repeater = new Repeater();
        $repeater->add_control(
			'features_title', 
			[
				'label' => __('Features', 'ennova-addons') , 
				'type' => Controls_Manager::TEXT, 
				'label_block' => true, 
				'default' => __('Feature List Item', 'ennova-addons') ,
			]
		);
        $repeater->add_control(
			'features_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-check', 'library' => 'solid',
				], 
			],
		);
		$repeater->add_control(
			'features_repeater_icon_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
			]
		);
		$repeater->add_control(
			'feature_item_active', 
			[
				'label' => esc_html__('Item Active', 'ennova-addons') , 
				'type' => Controls_Manager::SWITCHER, 
				'return_value' => 'show',
				'default' => 'show',
			]
		);
		$this->add_control(
			'features_title_block', 
			[
				'label' => __('Add Features', 'ennova-addons') , 
				'type' => Controls_Manager::REPEATER, 
				'fields' => $repeater->get_controls() , 
				'default' => [
					[
						'features_title' => __('Advance Analytics', 'ennova-addons') ,
						'features_icon' => [ 'value' => 'fa fa-check', 'library' => 'solid', ],
						'feature_item_active' => 'show',
					],	[
						'features_title' => __('Change Managment', 'ennova-addons') ,
						'features_icon' => [ 'value' => 'fa fa-check', 'library' => 'solid', ],
						'feature_item_active' => 'show',
					],	[
						'features_title' => __('Corporate Finance', 'ennova-addons') ,
						'features_icon' => [ 'value' => 'fa fa-check', 'library' => 'solid', ],
						'feature_item_active' => 'show',
					],	[
						'features_title' => __('Strategy & Marketing', 'ennova-addons') ,
						'features_icon' => [ 'value' => 'fa fa-times', 'library' => 'solid', ],
						'feature_item_active' => 'show',
					],
				], 
				'title_field' => '{{{ features_title }}}', 
			]
		); 
		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_plan',
			[
				'label' => __( 'Show Plan', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);
		$this->add_control(
			'show_icon',
			[
				'label' => __( 'Show Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						], 
					],
				],

			]
		);
		$this->add_control(
			'show_feature',
			[
				'label' => __( 'Show Features', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_link',
			[
				'label' => __( 'Show Button', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'ribbon_section',
			[
				'label' => __( 'Ribbon Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_ribbon',
			[
				'label' => __( 'Show Ribbon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'ribbon_style',
			[
				'label'       => esc_html__( 'Ribbon Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Ribbon from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'one',
				'options'     => [
					'one'      => esc_html__( 'Style 1', 'ennova-addons' ),
					'two'      => esc_html__( 'Style 2 (Pro)', 'ennova-addons' ),
					'three'      => esc_html__( 'Style 3 (Pro)', 'ennova-addons' ),
					'four'      => esc_html__( 'Style 4 (Pro)', 'ennova-addons' ),
					'five'      => esc_html__( 'Style 5 (Pro)', 'ennova-addons' ),
					'six'      => esc_html__( 'Style 6 (Pro)', 'ennova-addons' ),
				],
				'condition'  => [
					'show_ribbon' => 'yes'
				],
			]
		);
		$this->add_control(
			'ennova_ribbon_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'ribbon_style!' => ['one'],
                ],
			]
		);
		$this->add_control(
			'ribbon_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Popular' , 'ennova-addons' ),
				'label_block' => true,
				'condition'  => [
					'show_ribbon' => 'yes'
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'card_link_text', [
				'label' => __( 'Link Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Choose Plan' , 'ennova-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'link_button_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-arrow-right',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'link_button_position',
			[
				'label'       => esc_html__( 'Icon Position', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'after',
				'options'     => [
					'before'      => esc_html__( 'Before', 'ennova-addons' ),
					'after'      => esc_html__( 'After', 'ennova-addons' ),
				],

			]
		);
		$this->add_responsive_control(
			'link_button_space_before',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_read_more_class.' i' => 'margin-right: {{SIZE}}{{UNIT}};',
				], 
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'link_button_position',
							'operator' => '!==',
							'value'    => 'after',
						],
					],
				],
			],
		);
		$this->add_responsive_control(
			'link_button_space_after',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_read_more_class.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'link_button_position',
							'operator' => '!==',
							'value'    => 'before',
						],
					],
				],
			]
		);
		$this->end_controls_section();
		ennova_pro_promotion_controls($this);

		$this->start_controls_section(
			'price_settings',
			[
				'label' => __( 'Price Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_class.', .'.$this->price_card_class.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_card_class,
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_card_class,
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'price_ribbon',
			[
				'label' => __( 'Ribbon', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_ribbon' => 'yes',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'price_ribbon_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  span.'.$this->price_card_ribbon_class,
			]
		);
		$this->start_controls_tabs( 'price_ribbon_tabs' );
		$this->start_controls_tab(
			'price_ribbon_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'price_ribbon_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .enn-price-ribbon span.'.$this->price_card_ribbon_class => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'price_ribbon_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .enn-price-ribbon span.'.$this->price_card_ribbon_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .enn-price-ribbon span.'.$this->price_card_ribbon_class.'::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .enn-price-ribbon span.'.$this->price_card_ribbon_class.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab(); 
		$this->start_controls_tab(
			'price_ribbon_hover_style',
			[
				'label' => __( 'Hover', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'price_ribbon_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_class.':hover span.'.$this->price_card_ribbon_class => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'price_ribbon_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_class.':hover span.'.$this->price_card_ribbon_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_card_class.':hover span.'.$this->price_card_ribbon_class.'::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_card_class.':hover span.'.$this->price_card_ribbon_class.'::before' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab(); 
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'price_heading_title',
			[
				'label' => __( 'Plan Name', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( '  Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_heading_class => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_card_heading_class,
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'price_plan_title',
			[
				'label' => __( 'Price Plan', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'card_plan_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_plan_class => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'card_currency_heading',
			[
				'label' => esc_html__( 'Currency', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'card_currency_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  span.'.$this->price_sign => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_currency_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_sign,
			]
		);
		$this->add_control(
			'card_price_heading',
			[
				'label' => esc_html__( 'Price', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'card_price_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  span.'.$this->price_value => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_price_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_value,
			]
		);
		$this->add_control(
			'card_duration_heading',
			[
				'label' => esc_html__( 'Duration ', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'card_duration_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  span.'.$this->price_duration => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_duration_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_duration,
			]
		);
		$this->add_control(
			'card_sale_heading',
			[
				'label' => esc_html__( 'Sale ', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'sale_switch' => 'show'
				],
			]
		);
		$this->add_control(
			'card_sale_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_sale => 'color: {{VALUE}}',
					'{{WRAPPER}} .active .'.$this->price_sale => 'color: {{VALUE}}',
					'{{WRAPPER}} .active .'.$this->price_sale.' span' => 'color: {{VALUE}}',
				],
				'condition' => [
					'sale_switch' => 'show'
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'card_sale_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->price_sale.', {{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_sale.' span.enn-currency-sign',
				'condition' => [
					'sale_switch' => 'show'
				],
			]
		);
		$this->add_control(
			'card_plan_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_plan_class => 'background-color: {{VALUE}}',
				], 
				'condition' => [
					'template_style' => 'layout_2',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_plan_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_plan_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => 'layout_2',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_plan_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_plan_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Icon Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'template_style',
							'operator' => '!==',
							'value'    => 'layout_2',
						], 
					],
				],
			]
		);
		$this->add_responsive_control(
			'card_heading_icon_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_icon_class => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'card_heading_icon_bg_color',
			[
				'label'     => __( 'Icon Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_icon_class.' .icon'  => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_heading_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_icon_class.' .icon' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_card_icon_class.' .icon svg' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'icon_width',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_icon_class.' .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'price_feature',
			[
				'label' => __( 'Feature Setting', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'card_heading_feature_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Start', 'ennova-addons' ),
						'icon'  => 'eicon-justify-start-h',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-justify-center-h',
					],
					'end' => [
						'title' => __( 'End', 'ennova-addons' ),
						'icon'  => 'eicon-justify-end-h',
					],
					'space-between' => [
						'title' => __( 'Space Between', 'ennova-addons' ),
						'icon'  => 'eicon-justify-space-between-h',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_feature_class => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'card_heading_feature_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_feature_class.' a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_heading_feature_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_feature_class.' i' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_feature_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_card_feature_class.' a',
			]
		);
		create_slider_control(
			$this,
			[
				'key'             => 'feature_icon_size',
				'label'           => 'Icon Size', 
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_feature_class.' i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_feature_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_card_feature_class,
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_feature_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_feature_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_feature_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_feature_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->price_card_feature_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_slider_control(
			$this,
			[
				'key'             => 'feature_content_padding_top',
				'label'           => 'Feature Top Distance ', 
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_inner_class => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		create_slider_control(
			$this,
			[
				'key'             => 'feature_content_padding_bottom',
				'label'           => 'Feature Bottom Distance',
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->price_card_inner_class => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			],
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'price_button_settings',
			[
				'label' => __( 'Button Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'card_heading_read_more_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE, 
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_read_more_class => 'text-align: {{VALUE}};',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_read_more_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a',
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_read_more_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => 'card_heading_read_more_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_heading_read_more_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a',
			]
		);
		$this->start_controls_tabs( 'card_heading_read_more_tabs' );
		$this->start_controls_tab(
			'card_heading_read_more_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_heading_read_more_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_heading_read_more_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_read_more_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_card_class.' .'.$this->price_card_read_more_class.' a',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'card_heading_read_more_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);
		$this->add_control(
			'card_heading_read_more_color_hover',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_read_more_class.' a:hover'=> 'color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->price_card_read_more_class.' a:hover i'=> 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'card_heading_read_more_bg_color_hover',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->price_card_read_more_class.' a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		create_border_control(
			$this,
			[
				'name'     => 'card_heading_read_more_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->price_card_read_more_class.' a:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$show_feature = $settings['show_feature'];
		$show_icon = $settings['show_icon'];
		$show_title = $settings['show_title'];
		$show_link = $settings['show_link'];
		$show_plan = $settings['show_plan'];
		$show_ribbon = $settings['show_ribbon'];

		$title = $settings['card_title'];
		$primary_box = $settings['primary_box'];

		$currency_symbol = $settings['currency_symbol']; 
		$price_per_plan = $settings['price_per_plan'];
		$price_amount = $settings['price_amount'];
		$link_text = $settings['card_link_text'];
		$card_icon = $settings['card_icon'];
		$ribbon_style = $settings['ribbon_style'];
		$ribbon_title = $settings['ribbon_title'];
		$features_title_block = $settings['features_title_block'];
		$features_icon_position = $settings['features_icon_position'];
		$sale_switch = $settings['sale_switch'];
		$show_list_icon = $settings['show_list_icon'];
		$price_sale_amount = $settings['price_sale_amount'];
		$link_button_icon = $settings['link_button_icon'];
		$link_button_position = $settings['link_button_position'];
		$link = $settings['card_link']['url'];
		$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : '';

		$template_style = $settings['template_style'];

		if (in_array($ribbon_style, ['two', 'three', 'four', 'five', 'six',])) {
			$ribbon_style = 'remove';
		}

		$template_path = ENNOVA_PATH . 'inc/templates/price/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
		}
	}
}