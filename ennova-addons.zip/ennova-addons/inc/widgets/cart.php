<?php namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;

class ENNOVACart extends Widget_Base {

	private $cart_button_class = 'ennova-cart-button';
	private $cart_total_class = 'ennova-cart-total';
	private $cart_icon_class = 'ennova-cart-icon';
	private $cart_counter_class = 'ennova-cart-counter';
	private $cart_offcanvas_class = 'ennova-cart-offcanvas';

	public function get_name() {
		return 'ennova-cart';
	}

	public function get_title() {
		return __( 'Cart', 'ennova-addons' );
	}

	public function get_icon() {
		return 'enn-icon eicon-cart';
	}

	public function get_categories() {
		return [ 'wc-woo-element' ];
	}

    public function get_style_depends() {
        return ['ennova-styles-css'];

    }

	public function get_script_depends() {
		return [
			'ennova-custom-js',
		];
	}

	public function get_keywords() {
		return [
			'cart',
			'wishlist',
			'favorite',
			'add to cart',
			'ennova addons',
			'enn',
			'woo',
		];
	}

	protected function register_controls() {

		$this->general_content_controls();
		$this->style_content_controls();
	}

	protected function general_content_controls() {

		$this->start_controls_section(
			'section_general_fields',
			[
				'label' => __( 'Cart', 'ennova-addons' ),
			]
		);

        $this->add_control(
			'ennova_cart_icon',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-shopping-cart',
					'library' => 'fa-solid',
				],
			]
		);


		$this->add_control(
			'items_indicator',
			[
				'label'        => __( 'Items Count', 'ennova-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'ennova-addons' ),
				'label_off'    => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_subtotal',
			[
				'label'        => __( 'Show Total Price', 'ennova-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'ennova-addons' ),
				'label_off'    => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',

			]
		);

		$this->add_responsive_control(
			'cart_align',
			[
				'label'              => __( 'Alignment', 'ennova-addons' ),
				'type'               => Controls_Manager::CHOOSE,
				'options'            => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'            => '',

                'selectors' =>[
                    '{{WRAPPER}} .ennova-cart' => 'text-align: {{VALUE}}',
                ]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cart_settings',
			[
				'label' => __( 'Cart Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cart_type_style',
			[
				'label'       => esc_html__( 'Cart Type', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>',
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'slide',
				'options'     => [
					'slide'      => esc_html__( 'Slide (Pro)', 'ennova-addons' ),
					'mini_cart' => esc_html__( 'Dropdown (Pro)', 'ennova-addons' ),
				],
				'classes' => 'ennova-pro-popup-notice',
			]
		); 
		
		$this->add_control(
			'open_cart_type',
			[
				'label'       => esc_html__( 'Open Cart', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>',
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'on_click',
				'options'     => [
					'on_click'      => esc_html__( 'On Click (Pro)', 'ennova-addons' ),
					'on_hover' => esc_html__( 'On Hover (Pro)', 'ennova-addons' ),
				],
				'classes' => 'ennova-pro-popup-notice',
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);

	}

	protected function style_content_controls() {

		$this->start_controls_section(
			'section_heading_typography',
			[
				'label' => __( 'Cart Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'toggle_button_price_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_total_class.' .woocommerce-Price-amount  bdi' => 'color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->cart_icon_class.' i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .'.$this->cart_icon_class.' svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toggle_button_background_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'background-color: {{VALUE}}',
				],
			]
		);

        create_typography_control(
			$this,
			[
				'name'     => 'toggle_button_price_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->cart_total_class,
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_size',
			[
				'label'      => __( 'Icon Size', 'ennova-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_icon_class.' i' => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .'.$this->cart_icon_class.' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'toggle_button_icon_space',
			[
				'label'           => __( 'Icon Spacing', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}}  .'.$this->cart_icon_class.' i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'toggle_button_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->cart_button_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'toggle_button_border_radius',
				'label'     => 'Border Radius',
				'selectors'  => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_margin',
				'label'     => 'Margin',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);
		
		create_dimensions_control(
			$this,
			[
				'key'       => 'toggle_button_padding',
				'label'     => 'Padding',
				'selectors'          => [
					'{{WRAPPER}} .'.$this->cart_button_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'toggle_button_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->cart_button_class,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon',
			[
				'label'     => __( 'Counter', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				
			]
		);

		$this->add_control(
			'counter_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'counter_background_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'counter_icon_size',
			[
				'label'           => __( 'Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->cart_counter_class => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		
	if ( null === WC()->cart ) {
		return;
	}
	
	$settings  = $this->get_settings_for_display(); 
	$product_count = WC()->cart->get_cart_contents_count();
	$get_cart_subtotal = WC()->cart->get_cart_subtotal();
	?>

    <div class="ennova-cart ennova-bor" >
        <div class="cart-inner">
            <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="cart <?php echo esc_attr($this->cart_button_class) ?>" >
            <?php if($settings['show_subtotal'] === 'yes' ) { ?>
                <span class='cart-total <?php echo esc_attr($this->cart_total_class) ?>'>
                    <?php echo WC()->cart->get_cart_subtotal(); ?>
                </span>
            <?php } ?>    
                <div class="cart-icon <?php echo esc_attr($this->cart_icon_class) ?>">
                   <?php \Elementor\Icons_Manager::render_icon( $settings['ennova_cart_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                   </div>
                <?php if($settings['items_indicator'] === 'yes' ) { ?>   
                <span class='counter <?php echo esc_attr($this->cart_counter_class) ?>'>
                    <?php echo $product_count; ?>
                </span>
                <?php } ?>
            </a>       
        </div>  
		
	<?php }

	protected function content_template() {
	}
}
