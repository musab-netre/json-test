<?php namespace EnnovaAddons;
if (!defined('ABSPATH')) {
    exit;
}
use \Elementor\Controls_Manager;

class EnnovaScrolltoTop
{
    private static $instance = null;
	public static function instance() {
		if ( is_null( self::$instance) ){
			self::$instance = new self();
		}
		return self::$instance;
	}
    public function __construct()
    {
        add_action('elementor/documents/register_controls', [$this, 'register_controls'], 10);
    }

    public function register_controls($element)
    {
        $global_settings = get_option('eael_global_settings');
        
        $element->start_controls_section(
            'ennova_scroll_to_top_section',
            [
                'label' => __('<i class="enn-icon"></i> Scroll to Top', 'ennova-addons'),
                'tab' => Controls_Manager::TAB_SETTINGS,
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top',
            [
                'label' => __('Enable Scroll to Top', 'ennova-addons'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __('Yes', 'ennova-addons'),
                'label_off' => __('No', 'ennova-addons'),
                'return_value' => 'yes',
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_has_global',
            [
                'label' => __('Enabled Globally?', 'ennova-addons'),
                'type' => Controls_Manager::HIDDEN,
                'default' => (isset($global_settings['ennova_scroll_to_top']['enabled']) ? $global_settings['ennova_scroll_to_top']['enabled'] : false),
            ]
        );

        if (isset($global_settings['ennova_scroll_to_top']['enabled']) && ($global_settings['ennova_scroll_to_top']['enabled'] == true) && get_the_ID() != $global_settings['ennova_scroll_to_top']['post_id'] && get_post_status($global_settings['ennova_scroll_to_top']['post_id']) == 'publish') {
            $element->add_control(
                'ennova_scroll_to_top_global_warning_text',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => __('You can modify the Global Scroll to Top by <strong><a href="' . get_bloginfo('url') . '/wp-admin/post.php?post=' . $global_settings['ennova_scroll_to_top']['post_id'] . '&action=elementor">Clicking Here</a></strong>', 'ennova-addons'),
                    'content_classes' => 'eael-warning',
                    'separator' => 'before',
                    'condition' => [
                        'ennova_scroll_to_top' => 'yes',
                    ],
                ]
            );
        } else {
            $element->add_control(
                'ennova_scroll_to_top_global',
                [
                    'label' => __('Enable Scroll to Top Globally', 'ennova-addons'),
                    'description' => __('Enabling this option will effect on entire site.', 'ennova-addons'),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'no',
                    'label_on' => __('Yes', 'ennova-addons'),
                    'label_off' => __('No', 'ennova-addons'),
                    'return_value' => 'yes',
                    'separator' => 'before',
                    'condition' => [
                        'ennova_scroll_to_top' => 'yes',
                    ],
                ]
            );

            $element->add_control(
                'ennova_scroll_to_top_global_display_condition',
                [
                    'label' => __('Display On', 'ennova-addons'),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'all',
                    'options' => [
                        'posts' => __('All Posts', 'ennova-addons'),
                        'pages' => __('All Pages', 'ennova-addons'),
                        'all' => __('All Posts & Pages', 'ennova-addons'),
                    ],
                    'condition' => [
                        'ennova_scroll_to_top' => 'yes',
                        'ennova_scroll_to_top_global' => 'yes',
                    ],
                    'separator' => 'before',
                ]
            );
        }

        $element->add_control(
            'ennova_scroll_to_top_position_text',
            [
                'label' => esc_html__('Position', 'ennova-addons'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bottom-right',
                'label_block' => false,
                'options' => [
                    'bottom-left' => esc_html__('Bottom Left', 'ennova-addons'),
                    'bottom-right' => esc_html__('Bottom Right', 'ennova-addons'),
                ],
                'separator' => 'before',
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_position_bottom',
            [
                'label' => __('Bottom', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'bottom: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_position_left',
            [
                'label' => __('Left', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'left: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                    'ennova_scroll_to_top_position_text' => 'bottom-left',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_position_right',
            [
                'label' => __('Right', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'right: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                    'ennova_scroll_to_top_position_text' => 'bottom-right',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_width',
            [
                'label' => __('Width', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_height',
            [
                'label' => __('Height', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_z_index',
            [
                'label' => __('Z Index', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 9999,
                        'step' => 10,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 9999,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'z-index: {{SIZE}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );


        $element->add_control(
            'ennova_scroll_to_top_button_opacity',
            [
                'label' => __('Opacity', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0.7,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'opacity: {{SIZE}};',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_icon_image',
            [
                'label' => esc_html__('Icon', 'ennova-addons'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-chevron-up',
                    'library' => 'fa-solid',
                ],
                'separator' => 'before',
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_icon_size',
            [
                'label' => __('Icon Size', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'default'    => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_icon_color',
            [
                'label' => __('Icon Color', 'ennova-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button i' => 'color: {{VALUE}}',
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button svg' => 'fill: {{VALUE}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_bg_color',
            [
                'label' => __('Background Color', 'ennova-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ennova_scroll_to_top_button_border_radius',
            [
                'label' => __('Border Radius', 'ennova-addons'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '.ennova-ext-scroll-to-top-wrap .ennova-ext-scroll-to-top-button' => 'border-radius: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'ennova_scroll_to_top' => 'yes',
                ],
            ]
        );

        $element->end_controls_section();
    }
}

EnnovaScrolltoTop::instance();
