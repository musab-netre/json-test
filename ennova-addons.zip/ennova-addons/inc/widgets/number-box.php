<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;

class ENNOVANumberItems extends \Elementor\Widget_Base {

	private $number_card_class = 'ennova-number-card';
	private $number_inner = 'ennova-number-inner-card'; 
	private $number_heading = 'ennova-number-card-heading';
	private $number_class = 'ennova-number-card-number';
	private $number_description = 'ennova-number-card-description';

	public function get_name() {
		return 'ennova-number';
	}

	public function get_title() {
		return __( 'Number Box ', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-counter';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'card_number',
			[
				'label' => __( 'Number', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => '1',
			]
		);

		$this->add_control(
			'card_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Card Title' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$description = 'Aenean ut turpis blandit eros convallis congue sit amet a libero.';

		$this->add_control(
			'card_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => __( $description, 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_number',
			[
				'label' => __( 'Show Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'box_settings',
			[
				'label' => __( 'Box Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->number_card_class => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->number_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};', 
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};', 
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->number_card_class,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'number_settings',
			[
				'label' => __( 'Number', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		create_alignment(
			$this,
			[
				'key'       => 'card_number_alignment',
				'label'     => 'Alignment',
				'options'   => [
					'start'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_class => 'align-self: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_heading_number_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_class => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_number_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_class => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'number_width',
			[
				'label'           => __( 'Number Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->number_class => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_size',
			[
				'label'           => __( 'Number Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->number_class => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'number_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->number_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'number_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_number_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'number_heading_title',
			[
				'label' => __( 'Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_heading => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_heading.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->number_heading,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_heading => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'number_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_description => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_heading_description_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->number_description => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->number_description,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->number_description => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$show_number = $settings['show_number'];
		$show_title = $settings['show_title'];
		$show_description = $settings['show_description']; 
		
		$number = $settings['card_number'];
		$title = $settings['card_title'];
		$description = $settings['card_description']; 
		$link = $settings['card_link']['url'];
		$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : ''; ?>

	<div class="ennova-number-wrapper number-one <?php echo esc_attr( $this->number_card_class) ?>">
		<div class="inner <?php echo esc_attr( $this->number_inner) ?>">
			<?php
			if ( $show_number === 'yes' ) {
				?>
					<div class="number <?php echo esc_attr( $this->number_class) ?>">
						<?php echo esc_html( $number )?>
					</div>
				<?php
			}
			?>
			<?php
			if ( $show_title === 'yes' ) {
				?> 
					<h3 class="title <?php echo esc_attr( $this->number_heading) ?>">
						<a href="<?php echo esc_url( $link )?>" <?php echo $target ?> <?php echo $nofollow ?>> 
							<?php echo esc_html( $title) ?>
						</a>
					</h3> 
				<?php
			}
			?>
			<?php
			if ( $show_description === 'yes' ) {
				?>
					<p class="text <?php echo esc_attr( $this->number_description) ?>"><?php echo esc_html( $description )?></p>
				<?php
			}
			?>
		
		</div> 
	</div> 
	<?php
	}
}