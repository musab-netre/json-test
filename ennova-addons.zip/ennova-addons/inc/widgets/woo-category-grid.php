<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;

class ENNOVAProductCategoryGrid extends \Elementor\Widget_Base {

	private $product_cat_card_class = 'ennova-single-category';
	private $product_cat_inner = 'ennova-product-category-inner'; 
	private $product_cat_img = 'ennova-category-image';
	private $product_cat_title = 'ennova-category-name';
	private $product_cat_count = 'ennova-category-count';

	public function get_name() {
		return 'ennova-category-grid';
	}

	public function get_title() {
		return __( ' Product Category Grid', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-woo-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-product-add-to-cart';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'product category grid',
			'category grid',
			'ennova addons',
			'enn',
			'woo',
		];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'query_configuration',
			[
				'label' => __( 'Content Settings', 'ennova-addons' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'one',
				'options'     => [
					'one'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'two'      => esc_html__( 'Layout 2 (Pro)', 'ennova-addons' ),
					'three'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
					'four'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
					'five'      => esc_html__( 'Layout 5 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_woo_category_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['one'],
                ],
			]
		);

		create_select2(
			$this,
			[
				'key'         => 'product_category',
				'label'       => 'Select Category',
				'placeholder' => 'Choose Category to Include',
				'options'     => ennova_get_product_category(),
				'multiple'    => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_configuration',
			[
				'label' => __( 'Item Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_title',
				'label'     => 'Show Title',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_category_count',
				'label'     => 'Show Category Count',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
				'condition' => [
					'template_style' =>'one',
				]
			]
		);

		create_switcher(
			$this,
			[
				'key'       => 'display_image',
				'label'     => 'Show Image',
				'on_label'  => 'Yes',
				'off_label' => 'No',
				'default'   => 'yes',
			]
		);

		create_number(
			$this,
			[
				'key'         => 'cat_per_page',
				'label'       => 'Limit',
				'placeholder' => '',
				'min'         => 6,
				'max'         => 6,
				'default'     => 6,
				'classes' => 'ennova-pro-popup-notice',
				'escape' => false,
			]
		);

		$this->add_responsive_control(
			'grid_column_count',
			[
				'label' => esc_html__( 'Grid Column Count', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>' ,
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'5' => esc_html__( '5', 'ennova-addons' ),
				],
				'classes' => 'ennova-pro-popup-notice',
			]
		);

		$this->add_responsive_control(
			'grid_column_gap',
			[
				'label'           => __( 'Grid Column Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 15,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} .ennova-product-category-grid-wrapper' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			'grid_row_gap',
			[
				'label'           => __( 'Grid Row Gap', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 15,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 30,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} .ennova-product-category-grid-wrapper' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			],
		);

		create_image_size_control(
			$this,
			[
				'name'      => 'thumbnail_size',
				'default'   => 'thumbnail',
				'condition' => [
					'display_image' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);
	
		// STYLE

		// styles image
		$this->start_controls_section(
			'section_image_style',
			[
				'label'     => __( 'Image Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'product_categroy_image';

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Overlay Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->product_cat_img.' .enn_img:before' => 'background: linear-gradient(180deg, rgba(33, 33, 33, 0.05) 0%, {{VALUE}} 100%) ',
				], 
			]
		);
		
		$this->add_responsive_control(
			$slug.'_image_width',
			[
				'label'           => __( 'Image Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'width: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_image_height',
			[
				'label'           => __( 'Image Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'height: {{SIZE}}{{UNIT}};', 
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_img.' .enn_img',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_img.' .enn_img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_img.' .enn_img',
			]
			);
			
		$this->end_controls_section();
		// styles image ends

		// styles item title
		$this->start_controls_section(
			'section_item_title_style',
			[
				'label'     => __( 'Title Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$slug = 'product_categroy_title';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_text_align',
				'label'     => 'Alignment',
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' .title' => 'text-align: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'color: {{VALUE}};',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color_hover',
				'label'     => 'Hover Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_title.' a',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_title.' a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// style item title ends

		// styles item count
		$this->start_controls_section(
			'section_item_count_style',
			[
				'label'     => __( 'Count Settings', 'ennova-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$slug = 'product_categroy_count';
		create_alignment(
			$this,
			[
				'key'       => $slug.'_text_align',
				'label'     => 'Alignment',
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'text-align: {{VALUE}}',
				],
			]
		);

		create_color_control(
			$this,
			[
				'key'       => $slug.'_text_color',
				'label'     => 'Color',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'color: {{VALUE}};',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}} .'.$this->product_cat_count.'',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->product_cat_count.'' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// style item count ends
 
	}

	protected function render() {
		$settings                    = $this->get_settings_for_display();
		$element_id                  = 'ennova_slider_' . $this->get_id();
		$template_style              = $settings['template_style'];


	 

		$select_cats = $settings['product_category'];
		
		if($select_cats == '' || empty($select_cats) ){
			$categories_list = ennova_get_all_category();
		}else{
			$categories = [];
			foreach ($select_cats as $category) {
				$categories[] = get_term_by( 'name', $category, 'product_cat' );
			}

			$categories_list = $categories;
		}

		if ( $categories_list && count( $categories_list ) > 0) {

			require ENNOVA_PATH . 'inc/templates/style-1/woo-product-category-grid.php';
			return;

		}	
	}
}
