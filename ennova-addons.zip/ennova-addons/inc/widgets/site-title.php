<?php namespace EnnovaAddons;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

class ENNOVASiteTitle extends Widget_Base {

    private $title_icon_class = 'enn-title-icon';
    private $title_icon_class_hover = 'enn-title-icon:hover';
    private $title_class = 'enn-site-title';

    public function __construct( $data = array(), $args = null ) {
        parent::__construct( $data, $args );
    }

    public function get_name() {
        return 'ennova-site-title';
    }

    public function get_title() {
        return __( 'Site Title', 'ennova-addons' );
    }

    public function get_icon() {
        return 'enn-icon eicon-site-title';
    }

    public function get_categories() {
        return array( 'wc-hf-element' );
    }

    public function get_style_depends() {
        return array( '' );
    }

    public function get_script_depends() {
        return array('');

    }

    public function get_keywords() {
        return [
            'site title',
            'title',
            'header footer', 
            'ennova eddons',
            'enn',
        ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_general_fields',
            [
                'label' => __( 'Style', 'ennova-addons' ),
            ]
        );

        $this->add_control(
            'before',
            [
                'label'   => __( 'Before Title Text', 'ennova-addons' ),
                'type'    => Controls_Manager::TEXTAREA,
                'rows'    => '1',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'after',
            [
                'label'   => __( 'After Title Text', 'ennova-addons' ),
                'type'    => Controls_Manager::TEXTAREA,
                'rows'    => '1',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'icon',
            [
                'label'       => __( 'Icon', 'ennova-addons' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => 'true',
            ]
        );

        $this->add_control(
            'icon_indent',
            [
                'label'     => __( 'Icon Spacing', 'ennova-addons' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'condition' => [
                    'icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .'.$this->title_icon_class.' ' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_text_align',
            [
                'label'              => __( 'Alignment', 'ennova-addons' ),
                'type'               => Controls_Manager::CHOOSE,
                'options'            => [
                    'left'    => [
                        'title' => __( 'Left', 'ennova-addons' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'  => [
                        'title' => __( 'Center', 'ennova-addons' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'   => [
                        'title' => __( 'Right', 'ennova-addons' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justify', 'ennova-addons' ),
                        'icon'  => 'eicon-text-align-justify',
                    ],
                ],
                'selectors'          => [
                    '{{WRAPPER}} .'.$this->title_class.' ' => 'text-align: {{VALUE}};',
                ],
                'frontend_available' => true,
            ]
        );

        $this->end_controls_section();

        ennova_pro_promotion_controls($this);
        
        $this->start_controls_section(
            'section_style',
            array(
                'label' => esc_html__( 'Site Title', 'ennova-addons' ),                    
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'tagline_typography',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
                ],
                'selector' => '{{WRAPPER}} .'.$this->title_class.' ',
            ]
        );
        $this->add_control(
            'tagline_color',
            [
                'label'     => __( 'Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_SECONDARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .'.$this->title_class.' ' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .enn-title-icon i'       => 'color: {{VALUE}};',
                    '{{WRAPPER}} .enn-title-icon svg'     => 'fill: {{VALUE}};',
                ],
            ]
        );

    

    $this->add_responsive_control(
        'icon_size',
        [
            'label'           => __( 'Icon Size', 'ennova-addons' ),
            'type'            => Controls_Manager::SLIDER,
            'size_units'      => [ 'px', '%' ],
            'range'           => [
                'px' => [
                    'min' => 0,
                    'max' => 120,
                ],
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'devices'         => [ 'desktop', 'tablet', 'mobile' ],
            'desktop_default' => [
                'size' =>  '',
                'unit' => 'px',
            ],
            'tablet_default'  => [
                'size' =>  '',
                'unit' => 'px',
            ],
            'mobile_default'  => [
                'size' =>  '',
                'unit' => 'px',
            ],
            'selectors'       => [
                '{{WRAPPER}} .'.$this->title_icon_class.' i' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

        $this->add_control(
            'icon_color',
            [
                'label'     => __( 'Icon Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'condition' => [
                    'icon[value]!' => '',
                ],
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->title_icon_class.' i'   => 'color: {{VALUE}};',
                    '{{WRAPPER}} .'.$this->title_icon_class.' svg' => 'fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icons_hover_color',
            [
                'label'     => __( 'Icon Hover Color', 'ennova-addons' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'icon[value]!' => '',
                ],
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .'.$this->title_icon_class_hover.' i'   => 'color: {{VALUE}};',
                    '{{WRAPPER}} .'.$this->title_icon_class_hover.' svg' => 'fill: {{VALUE}};',
                ],
            ]
        );
        create_dimensions_control(
            $this,
            [
                'key'       => 'site_title_padding',
                'label'     => 'Padding',
                'selectors' => [
                    '{{WRAPPER}}  .'.$this->title_class.' ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        create_dimensions_control(
            $this,
            [
                'key'       => 'site_title_margin',
                'label'     => 'Margin',
                'selectors' => [
                    '{{WRAPPER}}  .'.$this->title_class.' ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {

    $settings = $this->get_settings_for_display(); ?>
    <div class="enn-site-title enn-site-title-wrapper">
        <?php if ( '' !== $settings['icon']['value'] ) { ?>
            <span class="enn-title-icon">
                <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>					
            </span>
        <?php } ?>
        <span>
        <?php
        if ( '' !== $settings['before'] ) {
            echo wp_kses_post( $settings['before'] );
        }
        ?>
        <?php echo wp_kses_post( get_bloginfo( 'name' ) ); ?>
        <?php
        if ( '' !== $settings['after'] ) {
            echo ' ' . wp_kses_post( $settings['after'] );
        }
        ?>
        </span>
    </div>
    <?php
    }
}