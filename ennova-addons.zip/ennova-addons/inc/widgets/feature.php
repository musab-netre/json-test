<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

class ENNOVAFeature extends \Elementor\Widget_Base {

	private $feature_card_class = 'ennova-feature-card';
	private $feature_card_inner_class = 'ennova-feature-inner-card';
	private $feature_card_bg_image_class = 'ennova-feature-card-bg-image';
	private $feature_card_image_class = 'ennova-feature-card-image';
	private $feature_card_heading_class = 'ennova-feature-card-heading';
	private $feature_card_icon_class = 'ennova-feature-card-icon';
	private $feature_card_description_class = 'ennova-feature-card-description';

	public function get_name() {
		return 'ennova-feature';
	}

	public function get_title() {
		return __( 'Feature ', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-icon-box';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return ['flip box',
				'box', 
				'info box', 
				'icon box', 
				'feature service', 
				'feature', 
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5 (Pro)', 'ennova-addons' ),
					'layout_6'      => esc_html__( 'Layout 6 (Pro)', 'ennova-addons' ),
					'layout_7'      => esc_html__( 'Layout 7 (Pro)', 'ennova-addons' ),
					'layout_8'      => esc_html__( 'Layout 8 (Pro)', 'ennova-addons' ),
					'layout_9'      => esc_html__( 'Layout 9 (Pro)', 'ennova-addons' ),
					'layout_10'      => esc_html__( 'Layout 10 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_feature_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1', 'layout_2', 'layout_3'],
                ],
			]
		);

		$this->add_control(
			'card_bg_image',
			[
				'label'   => __( 'Choose Background Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
				'condition' => [
					'template_style' => ['layout_2']
				],
			],
		);

		$this->add_responsive_control(
            'choose_icon_or_img',
            [
                'label' => esc_html__('Image or Icon', 'ennova-addons'),
                'type' => Controls_Manager::CHOOSE,
				'default' => 'icon',
                'options' => [
                    'none' => [
                        'title' => esc_html__('None', 'ennova-addons'),
                        'icon' => 'eicon-ban',
                    ],
                    'icon' => [
                        'title' => esc_html__('Icon', 'ennova-addons'),
                        'icon' => 'eicon-info-circle',
                    ],
                    'img' => [
                        'title' => esc_html__('Image', 'ennova-addons'),
                        'icon' => 'eicon-image-bold',
                    ],
                ],
				'label_block' => true,
            ]
        );

		$this->add_control(
			'card_image',
			[
				'label'   => __( 'Choose Image', 'ennova-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_placeholder_image_src(),
				],
				'condition' => [
                    'choose_icon_or_img' => 'img',
                ],
			]
		);

		$this->add_control(
			'card_icon',
			[
				'label' => __( 'Icon', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'solid',
				],
				'condition' => [
                    'choose_icon_or_img' => 'icon',
                ],
			]
		);
	
		$this->add_control(
			'card_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Card Title' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$description = 'Aenean ut turpis blandit eros convallis congue sit.';

		$this->add_control(
			'card_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => __( $description, 'ennova-addons' ),
				'placeholder' => __( 'Type your description here', 'ennova-addons' ),
			]
		);
		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		
		ennova_pro_promotion_controls($this);

		$this->start_controls_section(
			'feature_settings',
			[
				'label' => __( 'Feature Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_class,
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_class.', {{WRAPPER}} .feature_five .content',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature_five .content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature_seven .content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature_five .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature_seven .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature_five .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_class.', {{WRAPPER}} .feature_five .content',
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_color_hover',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_class.':hover',
				'condition' => [
					'template_style!' => ['layout_3']
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_bg_before_color_hover',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background ', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_class.'::before',
				'condition' => [
					'template_style' => ['layout_3']
				]
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_class.':hover',
				'condition' => [
					'template_style' => ['layout_1']
				]
			]
		);

		$this->end_controls_tab(); 
		$this->end_controls_tabs();  
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __( 'Icon Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'choose_icon_or_img' => 'icon',
                ],
			]
		);
		$this->add_control(
			'feature_icon_position',
			[
				'label' => __('Position', 'elementor') , 
				'type' => Controls_Manager::CHOOSE, 
				'options' => [
					'row' => [
						'title' => __('Left', 'elementor') , 
						'icon' => 'eicon-h-align-left', 
					], 
					'column' => [
						'title' => __('Top', 'elementor') , 
						'icon' => 'eicon-v-align-top', 
					], 
					'row-reverse' => [
						'title' => __('Right', 'elementor') , 
						'icon' => 'eicon-h-align-right',
					], 
				], 
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_inner_class => 'flex-direction: {{VALUE}};',
					'{{WRAPPER}} .feature_seven .content' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'card_heading_icon_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_icon_class => 'align-self: {{VALUE}};',
				],
			]
		);

        $this->start_controls_tabs( 'card_icon_tabs' );

		$this->start_controls_tab(
			'card_heading_icon_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_heading_icon_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Icon Background Color', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon',
			]
		);

		$this->add_control(
			'card_heading_icon_color',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->feature_card_icon_class.' .icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->feature_card_icon_class.' .icon svg' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'icon_width',
			[
				'label'           => __( 'Icon Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'           => __( 'Icon Size', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_icon_class. ' .icon',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->feature_card_icon_class. ' .icon::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_icon_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_icon_class.' .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'icon_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->feature_card_icon_class . ' .icon',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_heading_icon_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_heading_icon_bg_color_hover',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Icon Background Color', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}}  .'.$this->feature_card_class.':hover .'.$this->feature_card_icon_class.' .icon',
			]
		);

		$this->add_control(
			'card_heading_icon_color_hover',
			[
				'label'     => __( 'Icon Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->feature_card_class.':hover .'.$this->feature_card_icon_class.' .icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->feature_card_class.':hover .'.$this->feature_card_icon_class.' .icon svg' => 'fill: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'icon_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_class.':hover .'.$this->feature_card_icon_class.' .icon' ,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'icon_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}}   .'.$this->feature_card_class.':hover .'.$this->feature_card_icon_class.' .icon' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'feature_image_style',
			[
				'label' => __( 'Image Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'choose_icon_or_img' => 'img',
                ],
			]
		);

		$slug = 'feature_image';

		$this->add_control(
			$slug.'_icon_position',
			[
				'label' => __('Position', 'elementor') , 
				'type' => Controls_Manager::CHOOSE, 
				'options' => [
					'row' => [
						'title' => __('Left', 'elementor') , 
						'icon' => 'eicon-h-align-left', 
					], 
					'column' => [
						'title' => __('Center', 'elementor') , 
						'icon' => 'eicon-v-align-top', 
					], 
					'row-reverse' => [
						'title' => __('Right', 'elementor') , 
						'icon' => 'eicon-h-align-right',
					], 
				], 
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_inner_class => 'flex-direction: {{VALUE}};',
					'{{WRAPPER}} .feature_seven .content' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			$slug.'_icon_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_image_class => 'align-self: {{VALUE}};',
				],
			]
		);
		$this->start_controls_tabs( $slug.'_tabs' );

		$this->start_controls_tab(
			$slug.'_normal_style',
			[
				'label' => __( 'Normal', 'ennova-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => $slug.'_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Color', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_class.' .'.$this->feature_card_image_class.' .image',
			]
		);

		create_slider_control(
			$this,
			[
				'key'             => $slug.'_image_width',
				'label'           => 'Image Background Width', 
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' =>'' ,
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->feature_card_image_class.' .image ' => 'width: {{SIZE}}{{UNIT}} ; height: {{SIZE}}{{UNIT}};', 
				],
			],
		);

		create_slider_control(
			$this,
			[
				'key'             => $slug.'_image_size',
				'label'           => 'Image Size', 
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 250,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'default_desktop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->feature_card_image_class.' img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_image_class.' .image',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_image_class.' .image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_image_class.' .image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->feature_card_image_class.' .image',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$slug.'_style_hover',
			[
				'label' => __( 'Hover', 'ennova-addons' ),

			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => $slug.'_hover_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Color', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->feature_card_class.':hover .'.$this->feature_card_image_class.' .image',
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type_hover',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->feature_card_image_class.' .image:hover',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius_hover',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_image_class.' .image:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs(); 
		$this->end_controls_section();

		$this->start_controls_section(
			'feature_heading_title',
			[
				'label' => __( 'Heading Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_title_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_heading_title_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->feature_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_title_color_hover',
			[
				'label'     => __( 'Hover Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_class.':hover .'.$this->feature_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->feature_card_heading_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_title_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'feature_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'card_heading_description_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_description_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_heading_description_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->feature_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_heading_description_color_hover',
			[
				'label'     => __( 'Hover Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_class.':hover .'.$this->feature_card_description_class.'' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_heading_description_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->feature_card_description_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_heading_description_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->feature_card_description_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$choose_icon = $settings['choose_icon_or_img'];

		$show_title = $settings['show_title'];
		$show_description = $settings['show_description'];

		$title = $settings['card_title'];
		$description = $settings['card_description'];
		$card_icon = $settings['card_icon'];
		$link = $settings['card_link']['url'];
		$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : '';

		$template_style = $settings['template_style'];
		if ( ($template_style == 'layout_2') ) {
			$image_bg_url = $settings['card_bg_image']['url'];
		}
		if ($choose_icon == 'img' ) {
			$image_url = $settings['card_image']['url'];
		}
		$template_path = ENNOVA_PATH . 'inc/templates/feature/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
			case 'layout_3':
				require $template_path. 'layout-3.php';
				break;
		}
	}
}