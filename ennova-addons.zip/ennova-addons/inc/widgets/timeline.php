<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

class ENNOVAContentTimeline extends \Elementor\Widget_Base {

	private $timeline_card_class = 'ennova-timeline-card';
	private $timeline_card_date_class = 'ennova-timeline-card-date';
	private $timeline_card_heading_class = 'ennova-timeline-card-heading';
	private $timeline_card_subtitle_class = 'ennova-timeline-card-subtitle';
	private $timeline_card_image = 'ennova-timeline-card-image';
	private $timeline_inner_line = 'ennova-timeline-inner-line';
	private $timeline_line = 'ennova-timeline-line';
	private $timeline_dot = 'ennova-timeline-dot';
	private $timeline_card_description_class = 'ennova-timeline-card-description';

	public function get_name() {
		return 'ennova-timeline';
	}

	public function get_title() {
		return __( 'Content Timeline', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-time-line';
	}

	public function get_style_depends() {
		return [
			'ennova-widget-css',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return [
			'timeline',
			'content',
			'enn',
			'ennova addons'
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2 (Pro)', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_timeline_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1'],
                ],
			]
		);
		
		$repeater = new Repeater();
		$repeater->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ), 
				'type'        => \Elementor\Controls_Manager::HIDDEN, 
			]
		);
		$repeater->add_control(
			'card_date', [
				'label' => __( 'Date', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT, 
				'default' => __( '01 jan 2008', 'ennova-addons' ),
				'label_block' => true, 
			]
		);

		$repeater->add_control(
			'card_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT, 
				'default' => __( 'Timeline item', 'ennova-addons' ),
				'label_block' => true, 
			]
		);

		$repeater->add_control(
			'card_subtitle', [
				'label' => __( 'Subtitle', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT, 
				'default' => __( 'Items', 'ennova-addons' ),
				'label_block' => true, 
			]
		);

		$description = 'Aenean ut turpis blandit eros convallis congue sit amet a libero.';

		$repeater->add_control(
			'card_description',
			[
				'label' => __( 'Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,  
				'default' => __( $description, 'ennova-addons' ),
				'label_block' => true,
			]
		);
        
		$repeater->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'timeline_block', 
			[
			'label' => __('Add Timeline', 'ennova-addons') , 
			'type' => Controls_Manager::REPEATER, 
			'fields' => $repeater->get_controls() , 
			'default' => [
				[
					'card_date' => __('01 jan 2000', 'ennova-addons') ,
					'card_title' => __('Timeline item ','ennova-addons') ,
					'card_subtitle' => __('Item-1','ennova-addons') ,
					'card_description' => __( $description,'ennova-addons') , 
				],
				[
					'card_date' => __('01 jan 2005', 'ennova-addons') ,
					'card_title' => __('Timeline item ','ennova-addons') ,
					'card_subtitle' => __('Item-2', 'ennova-addons') ,
					'card_description' => __( $description,'ennova-addons') , 
				],
				[
					'card_date' => __('01 jan 2010', 'ennova-addons') ,
					'card_title' => __('Timeline item ','ennova-addons') ,
					'card_subtitle' => __('Item-3', 'ennova-addons') ,
					'card_description' => __( $description,'ennova-addons') , 
				],
				[
					'card_date' => __('01 jan 2020', 'ennova-addons') ,
					'card_title' => __('Timeline item ','ennova-addons') ,
					'card_subtitle' => __('Item-4', 'ennova-addons') ,
					'card_description' => __( $description,'ennova-addons') , 
				],
			], 
			'title_field' => '{{{ card_title }}}', 
		]
		);

		$this->add_control(
			'ennova_timeline_repeater_pro_notice',
			[
				'raw' => 'More than 4 are available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => __( 'Settings', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_date',
			[
				'label' => __( 'Show Date', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);
		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_subtitle',
			[
				'label' => __( 'Show Subtitle', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);
		$this->add_control(
			'show_description',
			[
				'label' => __( 'Show Description', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);
		
		//STYLE
		// Box Settings
		$this->start_controls_section(
			'timeline_settings',
			[
				'label' => __( 'Timeline Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'timeline_box';
		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_class => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->timeline_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->timeline_card_class,
			]
		);

		$this->end_controls_section();

		//timeline_date
		$this->start_controls_section(
			'date_settings',
			[
				'label' => __( 'Date Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'timeline_date';
		$this->add_responsive_control(
			$slug.'_date_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_date_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			$slug.'_heading_date_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_date_class.' span' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_heading_date_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_date_class.' span' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_date_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->timeline_card_date_class.' span',
			]
		);
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->timeline_card_date_class.' span',
			]
		);
		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_type',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_date_class.' span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_date_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_date_class.' span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_date_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_date_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		//timeline_title
		$this->start_controls_section(
			'timeline_heading',
			[
				'label' => __( 'Title Setting', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'timeline_title';
		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_heading_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_heading_class.' a' => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     =>  $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->timeline_card_heading_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       =>  $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_heading_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Subtitle
		$this->start_controls_section(
			'subtitle_settings',
			[
				'label' => __( 'Subtitle Setting', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,  
				'condition' => [ 
					'show_subtitle' => 'yes',
				],
			]
		);
		
		$slug = 'timeline_subtitle';
		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_subtitle_class => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_subtitle_class.' span' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_subtitle_class.' span' => 'background-color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->timeline_card_subtitle_class.' span',
			]
		);

		
		create_border_control(
			$this,
			[
				'name'     => $slug.'_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->timeline_card_subtitle_class.' span',
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => $slug.'_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_subtitle_class.' span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_subtitle_class.' span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_subtitle_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// timeline description
		$this->start_controls_section(
			'timeline_description',
			[
				'label' => __( 'Description Setting', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
 
		$slug = 'timeline_desc';
		$this->add_responsive_control(
			$slug.'_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_description_class => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->timeline_card_description_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->timeline_card_description_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_card_description_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();

		//vertical divider
	
		$this->start_controls_section(
			'vertical_divider',
			[
				'label' => __( 'Divider', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'divider';		
		$this->add_control(
			$slug.'_heading',
			[
				'label' => esc_html__( 'Divider', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				//'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			$slug.'_line_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' , '%'],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->timeline_line => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->timeline_inner_line => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_line=> 'background-color: {{VALUE}}',
				],
			]
		); 

		$this->add_control(
			$slug.'_inner_color',
			[
				'label'     => __( 'Scroll Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_inner_line=> 'background-color: {{VALUE}}',
				],
			]
		); 
		$this->add_control(
			$slug.'_dot_heading',
			[
				'label' => esc_html__( 'Dot', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			$slug.'_dot_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%'],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->timeline_dot => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->timeline_dot.'.highlighted-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			$slug.'_dot_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_dot=> 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			$slug.'_dot_inner_color',
			[
				'label'     => __( 'Scroll Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->timeline_dot.'.highlighted-dot'=> 'background-color: {{VALUE}}',
				],
			]
		); 
		$this->add_responsive_control(
			$slug.'_dot_position',
			[
				'label'           => __( 'Posiition', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%'],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->timeline_dot => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->timeline_dot.'.highlighted-dot' => 'left:{{SIZE}}{{UNIT}};',  
				],
			]
		);
		$this->end_controls_section(); 
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$show_title = $settings['show_title'];
		$show_date = $settings['show_date'];
		$show_description = $settings['show_description'];
		$show_subtitle = $settings['show_subtitle'];

		$timeline_block = $settings['timeline_block'];

		$template_style = $settings['template_style'];

		if ($template_style == 'layout_1') {
			?>
			<div class="enn-timeline-items">
				<span class="timeline-line <?php echo esc_attr($this->timeline_line )?>"></span>
				<span class="timeline-inner-line <?php echo esc_attr($this->timeline_inner_line )?>"></span>
				<?php
				if (isset($timeline_block) && !empty($timeline_block)) { 

					foreach ($timeline_block as $key => $content_block)
					{
						if ($key === 4 ) { break; }
						$date_block = $content_block['card_date'];
						$title_block = $content_block['card_title'];
						$subtitle_block = $content_block['card_subtitle'];
						$desc_block = $content_block['card_description'];
						$link_block = $content_block['card_link']['url']; 
						$target = $content_block['card_link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $content_block['card_link']['nofollow'] ? ' rel="nofollow"' : '';
						?>
						<div class="enn-timeline-item">
							<div class="timeline-dot <?php echo esc_attr($this->timeline_dot )?>"></div>
							<?php
							if ( $show_date === 'yes' ) {
								?>
									<div class="timeline-date <?php echo esc_attr($this->timeline_card_date_class )?>">
										<span><?php echo esc_html($date_block); ?></span>
									</div>
								<?php
							}
							?>
							<div class="enn-timeline-content <?php echo esc_attr($this->timeline_card_class )?>">
							<?php
							if ( $show_subtitle === 'yes' ) {
								?>
									<div class="enn-subtitle <?php echo esc_attr($this->timeline_card_subtitle_class )?>">
										<span><?php echo esc_html($subtitle_block) ?></span>
									</div>
								<?php
								}
							?>
							<?php
							if ( $show_title === 'yes' ) {
								?>
									<div class="heading">
										<h3 class="title <?php echo esc_attr($this->timeline_card_heading_class )?>">
										<a href="<?php echo esc_url($link_block) ?>" <?php echo $target ?> <?php echo $nofollow ?>><?php echo esc_html($title_block) ?></a></h3>
									</div>
								<?php
							}
							?>
							<?php
							if ( $show_description === 'yes' ) {
								?>
									<div class="description <?php echo esc_attr($this->timeline_card_description_class )?>">
										<span><?php echo esc_html($desc_block); ?></span>
									</div>
								<?php
							}
							?>
							</div>
						</div>
						<?php
					} 
				}
				?>
			</div>
			<?php
		}
	}
}