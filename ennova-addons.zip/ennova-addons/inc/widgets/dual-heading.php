<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

class ENNOVADualHeading extends \Elementor\Widget_Base {

	private $heading_card_class = 'ennova-heading-card';
	private $heading_card_inner_class = 'ennova-heading-inner-card';

	public function get_name() {
		return 'ennova-heading';
	}

	public function get_title() {
		return __( 'Dual Color Heading ', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-animated-headline';
	}

	public function get_style_depends() {
		return [
			'',
		];
	}

	public function get_script_depends() {
		return [
			'ennova-widget-js',
		];
	}

	public function get_keywords() {
		return ['heading',
				'dual heading', 
				'creative', 
				'dual',
				'creative heading',
				'title',
				'color',
				'dual color heading',
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_dual_heading_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1', 'layout_2'],
                ],
			]
		);

		$this->add_control(
			'before_title', [
				'label' => __( 'Prefix Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Dual' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'primary_title', [
				'label' => __( 'Highlight Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Color' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'after_title', [
				'label' => __( 'Suffix Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Heading' , 'ennova-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'card_link',
			[
				'label' => __( 'Link', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ennova-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
            'heading_html_tag',
            [
                'label'       => esc_html__( 'Html Tag', 'ennova-addons' ),
                'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'h3',
                'options'     => [
                    'h1' => esc_html__( 'H1', 'ennova-addons' ),
                    'h2' => esc_html__( 'H2', 'ennova-addons' ),
                    'h3' => esc_html__( 'H3', 'ennova-addons' ),
                    'h4' => esc_html__( 'H4', 'ennova-addons' ),
                    'h5' => esc_html__( 'H5', 'ennova-addons' ),
                    'h6' => esc_html__( 'H6', 'ennova-addons' ),
                    'div' => esc_html__( 'Div', 'ennova-addons' ),
                    'span' => esc_html__( 'span', 'ennova-addons' ),
                ],
            ]
        );
		
		$this->add_responsive_control(
			'card_heading_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'-webkit-left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'-webkit-center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'-webkit-right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class.' .title' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'show_heading',
			[
				'label' => __( 'Show Heading', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subtext_settings',
			[
				'label' => __( 'Subtext', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'card_subtext',
			[
				'label' => esc_html__( 'Subtext', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Aenean ut turpis blandit eros convallis congue sit amet a libero. Mauris sed tempor felis. Nunc nisi massa, imperdiet ac metus quis, pharetra pulvinar sapien', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Type your subtext here', 'ennova-addons' ),
			]
		);

		$this->add_responsive_control(
			'card_subtext_alignment',
			[
				'label'     => __( 'Alignment', 'ennova-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'-webkit-left' => [
						'title' => __( 'Left', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'-webkit-center' => [
						'title' => __( 'Center', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'-webkit-right' => [
						'title' => __( 'Right', 'ennova-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class.' .text' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'show_subtext',
			[
				'label' => __( 'Show Subtext', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);

		//STYLE
		$this->start_controls_section(
			'heading_settings',
			[
				'label' => __( 'Dual Heading Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->heading_card_class => 'background-color: {{VALUE}}',
				],
			]
		);

		create_border_control(
			$this,
			[
				'name'     => 'card_border_type',
				'label'    => 'Border Type',
				'selector' => '{{WRAPPER}} .'.$this->heading_card_class,
			]
		);

		create_border_radius_control(
			$this,
			[
				'key'       => 'card_border_radius',
				'label'     => 'Border Radius',
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => 'card_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->heading_card_class,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'main_settings',
			[
				'label' => __( 'Color & Typography Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_title_heading',
			[
				'label' => esc_html__( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'card_title_color',
			[
				'label'     => __( 'Highlight Text', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->heading_card_class.' .title span' => 'color: {{VALUE}}',
				],
				'condition' => [
					'template_style!'    => ['layout_1'],
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_title_gradient_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Highlight type', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->heading_card_class.' .title span',
				'condition' => [
					'template_style'    => ['layout_1'],
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'card_title_gradient_bg_color',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'label'     => __( 'Background Color', 'ennova-addons' ),
						'default' => 'classic',
					],
				],
				'selector'  => '{{WRAPPER}} .'.$this->heading_card_class.' .title span',
				'condition' => [
					'template_style'    => ['layout_2'],
				]
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_title_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->heading_card_class.' .title span',
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => 'card_title_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class.' .title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'template_style'    => ['layout_2'],
				]
			]
		);

		$this->add_control(
			'card_before_after_heading',
			[
				'label' => esc_html__( 'Prefix & Suffix Text', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'card_before_after_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->heading_card_class.' .title a' => 'color: {{VALUE}}',
				],	
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => 'card_before_after_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->heading_card_class.' .title a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subtext_style_settings',
			[
				'label' => __( 'Subtext Settings', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_subtext' =>  'yes',
				]
			]
		);

		$slug = 'dual_heading_subtext';

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text p' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h1' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h2' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h3' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h4' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h5' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text h6' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->heading_card_class.' .text pre' => 'color: {{VALUE}}',
				],
			]
		);
		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '
				{{WRAPPER}}  .'.$this->heading_card_class.' .text p,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h1,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h2,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h3,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h4,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h5,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text h6,
				{{WRAPPER}}  .'.$this->heading_card_class.' .text pre',
			]
		);
		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->heading_card_class.' .text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .'.$this->heading_card_class.' .text pre' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				], 
			]
		);

		$this->end_controls_section();

	}



	protected function render() {

		$settings = $this->get_settings_for_display();

		$template_style = $settings['template_style'];
		
		$title = $settings['primary_title'];
		$before_title = $settings['before_title'];
		$after_title = $settings['after_title'];
		$heading_html_tag = $settings['heading_html_tag'];
		$link = $settings['card_link']['url'];
		$target = $settings['card_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['card_link']['nofollow'] ? ' rel="nofollow"' : '';
		$show_heading = $settings['show_heading'];

		$subtext = $settings['card_subtext'];
		$show_subtext = $settings['show_subtext'];

		$template_path = ENNOVA_PATH . 'inc/templates/dual-heading/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
		}
	}
}