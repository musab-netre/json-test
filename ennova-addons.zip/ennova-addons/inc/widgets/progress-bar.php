<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found
namespace EnnovaAddons;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use Elementor\this;
use Elementor\Utils;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

class ENNOVAProgressBar extends \Elementor\Widget_Base {

	private $progress_main_class = 'ennova-progress-items';
	private $progress_class = 'ennova-progress';
	private $progress_bar_class = 'ennova-progress-bar';
	private $progress_title_class = 'ennova-progress-title';
	private $progress_counter_class = 'ennova-progress-percentage';

	public function get_name() {
		return 'ennova-progress-bar';
	}

	public function get_title() {
		return __( 'Progress Bar', 'ennova-addons' );
	}

	public function get_categories() {
		return [ 'wc-element' ];
	}

	public function get_icon() {
		return 'enn-icon eicon-skill-bar';
	}

	public function get_style_depends() {
		return [
            '',
		];
	}

	public function get_script_depends() {
		return [
			'',
		];
	}

	public function get_keywords() {
		return [
			'progress bar',
			'bar', 
			'skills',
			'enn',
			'enn progress',
			'ennova addons',
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'ennova-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'template_style',
			[
				'label'       => esc_html__( 'Template Style', 'ennova-addons' ),
				'placeholder' => esc_html__( 'Choose Template from Here', 'ennova-addons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'layout_1',
				'options'     => [
					'layout_1'      => esc_html__( 'Layout 1', 'ennova-addons' ),
					'layout_2'      => esc_html__( 'Layout 2', 'ennova-addons' ),
					'layout_3'      => esc_html__( 'Layout 3 (Pro)', 'ennova-addons' ),
					'layout_4'      => esc_html__( 'Layout 4 (Pro)', 'ennova-addons' ),
					'layout_5'      => esc_html__( 'Layout 5 (Pro)', 'ennova-addons' ),
				],
			]
		);

		$this->add_control(
			'ennova_progress_bar_pro_notice',
			[
				'raw' => 'Only Available in <a href="https://wpennova.com/" target="_blank">Pro Version!</a>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'ennova-pro-notice',
				'condition' => [
                    'template_style!' => ['layout_1', 'layout_2'],
                ],
			]
		);

		$this->add_control(
			'progress_title', [
				'label' => __( 'Title', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Title',
			]
		);
		
		$this->add_control(
			'progress_percentage',
			[
				'label' => esc_html__( 'Counter Value', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
						'min' => 0,
						'max' => 100,
				],
				'default' => [
					'size' => 70,
				],
			]
		);
		
		$this->add_control(
			'progress_suffix', [
				'label' => __( 'Counter Suffix', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '%',
			]
		);

		$this->add_control(
			'show_percentage',
			[
				'label' => __( 'Show Counter', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ennova-addons' ),
				'label_off' => __( 'Hide', 'ennova-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'progress_animation_duration',
			[
				'label' => __( 'Animation Duration', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>',
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 0,
				'step' => .1,
				'classes' => 'ennova-pro-popup-notice',
			]
		);	

		$this->add_control(
			'progress_animation_delay',
			[
				'label' => __( 'Animation Delay', 'ennova-addons' ) .' <i class="eicon-pro-icon"></i>',
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 0,
				'step' => .1,
				'classes' => 'ennova-pro-popup-notice',
			]
		);

		$this->end_controls_section();

		ennova_pro_promotion_controls($this);

		$this->start_controls_section(
			'progress_background',
			[
				'label' => __( 'Wrapper', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'progress';

		$this->add_responsive_control(
			$slug.'_width',
			[
				'label'           => __( 'Width', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px', '%' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => '',
					'unit' => '%',
				],
				'tablet_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default'  => [
					'size' => '',
					'unit' => '%',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->progress_class => 'width: {{SIZE}}{{UNIT}};',
				],
			],
		);

		$this->add_responsive_control(
			$slug.'_height',
			[
				'label'           => __( 'Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->progress_class => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			$slug.'_bg_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_class => 'background-color: {{VALUE}}', 
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'progress_bar',
			[
				'label' => __( 'Progress Line', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'progress_bar';

		$this->add_responsive_control(
			$slug.'_height',
			[
				'label'           => __( 'Height', 'ennova-addons' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' =>  '',
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' =>  '',
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .'.$this->progress_bar_class => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_bar_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .'.$this->progress_bar_class.'::after' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			$slug.'_after',
			[
				'label' => esc_html__( 'After', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'template_style' => ['layout_1']
				],
			]
		);

		$this->add_control(
			$slug.'_after_size',
			[
				'label' => esc_html__( 'Size', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 6,
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_bar_class.'::after' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_1']
				],
			]
		);
		
		$this->add_control(
			$slug.'_after_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_bar_class.'::after' => 'background-color: {{VALUE}}', 
				],
				'condition' => [
					'template_style' => ['layout_1']
				],
			]
		);

		create_box_shadow_control(
			$this,
			[
				'key'      => $slug.'_box_shadow',
				'label'    => 'Box Shadow',
				'selector' => '{{WRAPPER}}  .'.$this->progress_bar_class.'::after',
				'condition' => [
					'template_style' => ['layout_1']
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'progress_bar_title',
			[
				'label' => __( 'Title', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'progress_bar_title_tabs' );

		$slug = 'progress_bar_title';

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->progress_title_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->progress_title_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_margin',
				'label'     => 'Margin',
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_title_class => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'progress_bar_counter',
			[
				'label' => __( 'Counter', 'ennova-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$slug = 'progress_bar_counter';

		$this->add_control(
			$slug.'_background_color',
			[
				'label'     => __( 'Background Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->progress_counter_class => 'background-color: {{VALUE}}',
					'{{WRAPPER}}  .'.$this->progress_counter_class.'::after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'template_style' => ['layout_2']
				],
			]
		);

		$this->add_control(
			$slug.'_color',
			[
				'label'     => __( 'Color', 'ennova-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .'.$this->progress_counter_class => 'color: {{VALUE}}',
				],
			]
		);

		create_typography_control(
			$this,
			[
				'name'     => $slug.'_typography',
				'label'    => 'Typography',
				'selector' => '{{WRAPPER}}  .'.$this->progress_counter_class,
			]
		);

		create_dimensions_control(
			$this,
			[
				'key'       => $slug.'_padding',
				'label'     => 'Padding',
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_counter_class => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_2']
				],
			]
		);

		$this->add_control(
			'progress_bar_counter_cart',
			[
				'label' => esc_html__( 'Cart', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'template_style' => ['layout_2']
				],
			]
		);

		$this->add_control(
			'progress_bar_counter_cart_size',
			[
				'label' => esc_html__( 'Size', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 6,
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_counter_class.'::after' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'template_style' => ['layout_2']
				],
			]
		);

		$this->add_control(
			'progress_bar_counter_spacing',
			[
				'label' => esc_html__( 'Spacing', 'ennova-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .'.$this->progress_counter_class => 'top: -{{SIZE}}{{UNIT}};',
				],
			]
		);
	$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$title = $settings['progress_title'];
		$counter = $settings['progress_percentage']['size'];
		$counter_suffix = $settings['progress_suffix'];

		$show_percentage = $settings['show_percentage'];
		$animation_duration = $settings['progress_animation_duration'];
		$animation_delay = $settings['progress_animation_delay'];

		$template_style = $settings['template_style'];

		$template_path = ENNOVA_PATH . 'inc/templates/progress-bar/';

		switch ($template_style) {
			case 'layout_1':
				require $template_path. 'layout-1.php';
				break;
			case 'layout_2':
				require $template_path. 'layout-2.php';
				break;
		}
	}
}